/*
 * Copyright (c) 2010 .SE (The Internet Infrastructure Foundation)
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER
 * IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN
 * IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*****************************************************************************
 BotanRNG.h

 Botan random number generator class
 *****************************************************************************/

#ifndef _SOFTHSM_V2_BOTANRNG_H
#define _SOFTHSM_V2_BOTANRNG_H

#include "config.h"
#include "ByteString.h"
#include "RNG.h"

#include "botan/rng.h"

class BotanRNG : public RNG
{
public:
	// Base constructor
	BotanRNG();

	// Destructor
	virtual ~BotanRNG();

	// Generate random data
	virtual bool generateRandom(ByteString& data, const size_t len);

	// Seed the random pool
	virtual void seed(ByteString& seedData);

	// Get RNG
	Botan::RandomNumberGenerator* getRNG();

private:
	// The RNG
	Botan::RandomNumberGenerator* rng;
};

#endif // !_SOFTHSM_V2_BOTANRNG_H

