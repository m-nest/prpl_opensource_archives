/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
** SPDX-FileCopyrightText: Copyright (c) 2025 Inango
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <syslog.h>
#include <string.h>
#include <stdlib.h>
#include <amxc/amxc.h>
#include <amxp/amxp.h>
#include <amxd/amxd_object.h>
#include <amxb/amxb.h>
#include "config.h"
#include "amxmisc.h"
#include "amxrdr.h"
#include "amxpcp.h"
#include "amxpmp.h"

static amxb_bus_ctx_t* bus_ctx = NULL;
static bool state_add_rdr = false;
static bool last_pcp_status = false;
static bool initialized = false;

int init_redirect(void) {
    int r = -1;

    if(init_amx() == 0) {
        bus_ctx = get_amx_bus_ctx("PCP.");
        if(bus_ctx != NULL) {
            r = 0;
        }
    }
    return r;
}

void shutdown_redirect(void) {
    shutdown_amx();
    bus_ctx = NULL;
    return;
}

static void delete_previous_mappings(bool use_pcp) {
    if(use_pcp) {
        delete_all_port_mapping_entries(bus_ctx);
    } else {
        delete_all_pcp_entries(bus_ctx);
    }
}

static void initialize_portmappings(bool use_pcp) {
    if(initialized) {
        if(last_pcp_status != use_pcp) {
            delete_previous_mappings(use_pcp);
            use_pcp = last_pcp_status;
        }
    } else {
        delete_previous_mappings(use_pcp);
        initialized = true;
    }
}

static bool is_dslite(amxc_string_t** output_pcp_server) {
    amxc_var_t ret;
    amxc_var_t* pcp_servers = NULL;
    const char* pcp_server = NULL;
    bool use_pcp = false;

    amxc_var_init(&ret);

    amxb_get(get_amx_bus_ctx("DSLite."), "DSLite.InterfaceSetting.[Status == \"Enabled\"].", 0, &ret, 1);
    if(GETP_ARG(&ret, "0.0.") != NULL) {
        amxb_get(get_amx_bus_ctx("PCP."), "PCP.Client.[UPnPIWF.Status == \"Enabled\"].Server.[Status == \"Enabled\"].", 0, &ret, 1);
        if(GETP_ARG(&ret, "0.0.") == NULL) {
            syslog(LOG_WARNING, "Failed to get the PCP Server object");
            goto exit;
        }
        pcp_servers = GETP_ARG(&ret, "0.");
    }

    if(pcp_servers != NULL) {
        pcp_server = amxc_var_key(GETI_ARG(pcp_servers, 0));
        if(pcp_server == NULL) {
            syslog(LOG_WARNING, "Failed to get the PCP Server path");
            goto exit;
        }
        amxc_string_setf(*output_pcp_server, "%s", pcp_server);
        if(amxc_string_text_length(*output_pcp_server) == 0) {
            syslog(LOG_WARNING, "PCP Server is empty.");
            goto exit;
        }
        use_pcp = true;
    }
exit:
    initialize_portmappings(use_pcp);
    amxc_var_clean(&ret);
    return use_pcp;
}

int add_redirect_rule2(const char* ifname, const char* rhost,
                       unsigned short eport, const char* iaddr, unsigned short iport,
                       int proto, const char* desc, unsigned int timestamp) {
    int r = -1;
    amxc_string_t* pcp_server = 0;

    amxc_string_new(&pcp_server, 0);

    if(is_dslite(&pcp_server)) {
        r = add_pcp_rule(get_amx_bus_ctx("PCP."), ifname, rhost, eport, iaddr, iport, proto, desc, timestamp, amxc_string_get(pcp_server, 0));
    } else {
        r = add_pm_rule(get_amx_bus_ctx("NAT."), ifname, rhost, eport, iaddr, iport, proto, desc, timestamp);
    }
    if(r == 0) {
        state_add_rdr = true;
    }

    amxc_string_delete(&pcp_server);
    return r;
}

/* get_redirect_rule()
 * return value : 0 success (found)
 * -1 = error or rule not found */
int get_redirect_rule(const char* ifname, unsigned short eport, int proto,
                      char* iaddr, int iaddrlen, unsigned short* iport,
                      char* desc, int desclen,
                      char* rhost, int rhostlen,
                      unsigned int* timestamp,
                      u_int64_t* packets, u_int64_t* bytes) {
    int r = -1;
    amxc_string_t* pcp_server = 0;

    amxc_string_new(&pcp_server, 0);

    if(is_dslite(&pcp_server)) {
        r = get_redirect_rule_pcp(bus_ctx, ifname, eport, proto, iaddr, iaddrlen, iport, desc, desclen, rhost, rhostlen, timestamp, packets, bytes, amxc_string_get(pcp_server, 0));
    } else {
        r = get_redirect_rule_pm(bus_ctx, ifname, eport, proto, iaddr, iaddrlen, iport, desc, desclen, rhost, rhostlen, timestamp, packets, bytes);
    }

    amxc_string_delete(&pcp_server);
    return r;
}

int get_redirect_rule_by_index(int index,
                               char* ifname, unsigned short* eport,
                               char* iaddr, int iaddrlen, unsigned short* iport,
                               int* proto, char* desc, int desclen,
                               char* rhost, int rhostlen,
                               unsigned int* timestamp,
                               u_int64_t* packets, u_int64_t* bytes,
                               u_int8_t* is_upnp_rule) {
    int r = -1;
    amxc_string_t* pcp_server = 0;

    amxc_string_new(&pcp_server, 0);

    if(is_dslite(&pcp_server)) {
        r = get_redirect_rule_by_index_pcp(bus_ctx, index, ifname, eport, iaddr, iaddrlen, iport, proto, desc, desclen, rhost, rhostlen, timestamp, packets, bytes, amxc_string_get(pcp_server, 0));
    } else {
        r = get_redirect_rule_by_index_pm(bus_ctx, index, ifname, eport, iaddr, iaddrlen, iport, proto, desc, desclen, rhost, rhostlen, timestamp, packets, bytes, is_upnp_rule);
    }

    amxc_string_delete(&pcp_server);
    return r;
}

int delete_redirect_rule(const char* ifname, unsigned short eport, int proto) {
    int r = -1;
    amxc_string_t* pcp_server = 0;

    amxc_string_new(&pcp_server, 0);

    if(is_dslite(&pcp_server)) {
        r = delete_redirect_rule_pcp(bus_ctx, ifname, eport, proto, amxc_string_get(pcp_server, 0));
    } else {
        r = delete_redirect_rule_pm(bus_ctx, ifname, eport, proto);
    }

    amxc_string_delete(&pcp_server);
    return r;
}

int add_filter_rule2(const char* ifname, const char* rhost,
                     const char* iaddr, unsigned short eport, unsigned short iport,
                     int proto, const char* desc) {
    int r = -1;
    (void) ifname;
    (void) rhost;
    (void) iaddr;
    (void) eport;
    (void) iport;
    (void) proto;
    (void) desc;
    if(state_add_rdr) {
        r = 0;
        state_add_rdr = false;
    } else {
        //Add filter rule with amx
    }
    syslog(LOG_WARNING, "add_filter_rule2: %d", r);
    return r;
}

int delete_filter_rule(const char* ifname, unsigned short eport, int proto) {
    (void) ifname;
    (void) eport;
    (void) proto;
    syslog(LOG_WARNING, "delete_filter_rule: not implemented");
    return 0;
}

unsigned short*
get_portmappings_in_range(unsigned short startport, unsigned short endport,
                          int proto, unsigned int* number) {
    unsigned short* r = NULL;
    amxc_string_t* pcp_server = 0;

    amxc_string_new(&pcp_server, 0);

    if(is_dslite(&pcp_server)) {
        r = get_portmappings_in_range_pcp(bus_ctx, startport, endport, proto, number, amxc_string_get(pcp_server, 0));
    } else {
        r = get_portmappings_in_range_pm(bus_ctx, startport, endport, proto, number);
    }

    amxc_string_delete(&pcp_server);
    return r;
}

int update_portmapping(const char* ifname, unsigned short eport, int proto,
                       unsigned short iport, const char* desc,
                       unsigned int timestamp) {
    int r = -1;
    amxc_string_t* pcp_server = 0;

    amxc_string_new(&pcp_server, 0);

    if(is_dslite(&pcp_server)) {
        r = update_portmapping_pcp(bus_ctx, ifname, eport, proto, iport, desc, timestamp, amxc_string_get(pcp_server, 0));
    } else {
        r = update_portmapping_pm(bus_ctx, ifname, eport, proto, iport, desc, timestamp);
    }

    amxc_string_delete(&pcp_server);
    return r;
}

int update_portmapping_desc_timestamp(const char* ifname,
                                      unsigned short eport, int proto,
                                      const char* desc, unsigned int timestamp) {
    int r = -1;
    amxc_string_t* pcp_server = 0;

    amxc_string_new(&pcp_server, 0);

    if(is_dslite(&pcp_server)) {
        r = update_portmapping_desc_timestamp_pcp(bus_ctx, ifname, eport, proto, desc, timestamp, amxc_string_get(pcp_server, 0));
    } else {
        r = update_portmapping_desc_timestamp_pm(bus_ctx, ifname, eport, proto, desc, timestamp);
    }

    amxc_string_delete(&pcp_server);
    return r;
}

int delete_redirect_and_filter_rules(unsigned short eport, int proto) {
    int r = 0;

    r += delete_redirect_rule(NULL, eport, proto);
    syslog(LOG_WARNING, "delete_redirect_and_filter_rules: %d", r);
    return r;
}

bool is_redirect_rule_with_other_origin(unsigned short eport, int proto) {
    bool r = false;

    amxc_var_t ret;
    amxc_string_t rule;
    amxc_var_t* obj;

    amxc_var_init(&ret);

    amxc_string_init(&rule, 0);
    amxc_string_appendf(&rule, "NAT.PortMapping.[Protocol == \"%s\" && ExternalPort == %hu && Origin != \"UPnP\"].", proto_itoa(proto), eport);

    amxb_get(bus_ctx, amxc_string_get(&rule, 0), 0, &ret, 1);

    obj = GETP_ARG(&ret, "0.0.");
    r = (obj != NULL);

    amxc_var_clean(&ret);
    amxc_string_clean(&rule);

    syslog(LOG_WARNING, "%s(proto='%s', port=%hu) -> %d", __func__, proto_itoa(proto), eport, r);
    return r;
}
