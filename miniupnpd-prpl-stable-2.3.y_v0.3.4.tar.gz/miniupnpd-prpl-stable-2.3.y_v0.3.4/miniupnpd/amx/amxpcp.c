/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
** SPDX-FileCopyrightText: Copyright (c) 2025 Inango
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <syslog.h>
#include <string.h>
#include <stdlib.h>
#include "amxpcp.h"
#include "amxrdr.h"

time_t upnp_time(void);

int add_pcp_rule(amxb_bus_ctx_t* bus_ctx, const char* ifname, const char* rhost,
                 unsigned short eport, const char* iaddr, unsigned short iport,
                 int proto, const char* desc, unsigned int timestamp, const char* pcp_server) {
    int r = -1;
    int rv = -1;
    amxc_var_t rule;
    amxc_var_t ret;
    amxc_string_t path_inbound;
    unsigned int lease_duration;
    uint32_t nb_try = 0;

    (void) ifname;
    lease_duration = (timestamp > 0) ? timestamp - upnp_time() : 0;
    amxc_var_init(&rule);
    amxc_var_init(&ret);
    amxc_string_init(&path_inbound, 0);
    amxc_var_set_type(&rule, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(bool, &rule, "Enable", true);
    amxc_var_add_key(cstring_t, &rule, "Origin", "UPnP_IWF");
    amxc_var_add_key(uint32_t, &rule, "Lifetime", lease_duration);
    amxc_var_add_key(cstring_t, &rule, "SuggestedExternalIPAddress", rhost);
    amxc_var_add_key(uint32_t, &rule, "SuggestedExternalPort", eport);
    amxc_var_add_key(uint32_t, &rule, "InternalPort", iport);
    amxc_var_add_key(int32_t, &rule, "ProtocolNumber", proto);
    amxc_var_add_key(cstring_t, &rule, "ThirdPartyAddress", iaddr);
    amxc_var_add_key(cstring_t, &rule, "Description", desc);

    amxc_string_setf(&path_inbound, "%sInboundMapping.", pcp_server);

    rv = amxb_add(bus_ctx, amxc_string_get(&path_inbound, 0), 0, NULL, &rule, &ret, 1);
    if((rv == AMXB_STATUS_OK) && (GETP_ARG(&ret, "0.path") != NULL)) {
        r = 0;
        do {
            syslog(LOG_DEBUG, "Check if InboundMapping is enabled");
            r = amxb_get(bus_ctx, GETP_CHAR(&ret, "0.path"), 0, &rule, 0);
            if((r != 0)) {
                r = -1;
                break;
            }
        } while(strcmp(GETP_CHAR(&rule, "0.0.Status"), "Disabled") == 0 && ++nb_try < MAX_NB_TRY && usleep(100));
    }

    amxc_var_clean(&rule);
    amxc_var_clean(&ret);
    amxc_string_clean(&path_inbound);
    syslog(LOG_WARNING, "redirecting port %hu to %s:%hu for %s: %d (using PCP)", eport, iaddr, iport, desc, r);
    return r;
}

/* get_redirect_rule() for PCP
 * return value : 0 success (found)
 * -1 = error or rule not found */
int get_redirect_rule_pcp(amxb_bus_ctx_t* bus_ctx, const char* ifname, unsigned short eport, int proto,
                          char* iaddr, int iaddrlen, unsigned short* iport,
                          char* desc, int desclen,
                          char* rhost, int rhostlen,
                          unsigned int* timestamp,
                          u_int64_t* packets, u_int64_t* bytes, const char* pcp_server) {
    int r = -1;
    amxc_var_t ret;
    amxc_var_t* tmp;
    amxc_string_t rule;
    amxc_string_t rule_name;
    amxc_string_t path_inbound;

    (void) ifname;
    (void) packets;
    (void) bytes;
    amxc_var_init(&ret);
    amxc_string_init(&rule, 0);
    amxc_string_init(&rule_name, 0);
    amxc_string_init(&path_inbound, 0);

    amxc_string_appendf(&rule, "%sInboundMapping.[ProtocolNumber == %d && SuggestedExternalPort == %hu && Origin == \"UPnP_IWF\"].", pcp_server, proto, eport);
    amxb_get(bus_ctx, amxc_string_get(&rule, 0), 0, &ret, 1);
    tmp = GETP_ARG(&ret, "0.0.");
    if(tmp != NULL) {
        amxc_var_log(tmp);
        r = 0;
        *iport = (uint16_t) GET_UINT32(tmp, "InternalPort");
        if(iaddr) {
            strncpy(iaddr, GET_CHAR(tmp, "ThirdPartyAddress"), iaddrlen);
        }
        if(desc) {
            strncpy(desc, GET_CHAR(tmp, "Description"), desclen);
        }
        if(timestamp) {
            *timestamp = GET_UINT32(tmp, "Lifetime");
        }
        if(rhost) {
            strncpy(rhost, GET_CHAR(tmp, "SuggestedExternalIPAddress"), rhostlen);
        }
    }
    amxc_var_clean(&ret);
    amxc_string_clean(&rule);
    syslog(LOG_WARNING, "get_redirect_rule: %d (using PCP)", r);
    return r;
}

/* get_redirect_rule_by_index() for PCP
 * return value : 0 success (found)
 * -1 = error or rule not found */
int get_redirect_rule_by_index_pcp(amxb_bus_ctx_t* bus_ctx, int index,
                                   char* ifname, unsigned short* eport,
                                   char* iaddr, int iaddrlen, unsigned short* iport,
                                   int* proto, char* desc, int desclen,
                                   char* rhost, int rhostlen,
                                   unsigned int* timestamp,
                                   u_int64_t* packets, u_int64_t* bytes, const char* pcp_server) {
    int rv = -1;
    int i = 0;
    amxc_var_t ret;
    amxc_string_t rule;

    (void) ifname;
    (void) packets;
    (void) bytes;
    amxc_var_init(&ret);
    amxc_string_init(&rule, 0);
    amxc_string_appendf(&rule, "%sInboundMapping.[Origin == \"UPnP_IWF\"].", pcp_server);
    amxb_get(bus_ctx, amxc_string_get(&rule, 0), 0, &ret, 1);
    amxc_var_for_each(r, GETP_ARG(&ret, "0.")) {
        if(index == i) {
            rv = 0;
            *iport = (uint16_t) GET_UINT32(r, "InternalPort");
            *eport = (uint16_t) GET_UINT32(r, "SuggestedExternalPort");
            *proto = GET_INT32(r, "ProtocolNumber");
            if(iaddr) {
                strncpy(iaddr, GET_CHAR(r, "ThirdPartyAddress"), iaddrlen);
            }
            if(desc) {
                strncpy(desc, GET_CHAR(r, "Description"), desclen);
            }
            if(timestamp) {
                *timestamp = GET_UINT32(r, "Lifetime");
            }
            if(rhost) {
                strncpy(rhost, GET_CHAR(r, "SuggestedExternalIPAddress"), rhostlen);
            }
            break;
        }
        ++i;
    }
    amxc_string_clean(&rule);
    amxc_var_clean(&ret);
    syslog(LOG_INFO, "get_redirect_rule_by_index: %d (using PCP)", rv);
    return rv;
}

/* delete_redirect_rule() for PCP
* return value : 0 success (found)
* -1 = error or rule not found */
int delete_redirect_rule_pcp(amxb_bus_ctx_t* bus_ctx, const char* ifname, unsigned short eport,
                             int proto, const char* pcp_server) {
    int r = -1;
    amxc_string_t rule;
    amxc_var_t ret;
    const char* alias;

    (void) ifname;
    amxc_var_init(&ret);
    amxc_string_init(&rule, 0);
    amxc_string_appendf(&rule, "%sInboundMapping.[ProtocolNumber == %d && SuggestedExternalPort == %hu && Origin == \"UPnP_IWF\"].", pcp_server, proto, eport);
    amxb_del(bus_ctx, amxc_string_get(&rule, 0), 0, NULL, &ret, 1);
    alias = GETI_CHAR(&ret, 0);
    if(alias && (alias[0] != '\0')) {
        r = 0;
    }
    amxc_string_clean(&rule);
    amxc_var_clean(&ret);
    syslog(LOG_WARNING, "delete_redirect_rule: %d (using PCP)", r);
    return r;
}

unsigned short*
get_portmappings_in_range_pcp(amxb_bus_ctx_t* bus_ctx, unsigned short startport, unsigned short endport,
                              int proto, unsigned int* number, const char* pcp_server) {
    unsigned short* array = NULL;
    unsigned short* tmp;
    unsigned int capacity = 0;
    unsigned short eport;
    amxc_var_t rules;
    amxc_string_t rule;

    *number = 0;
    amxc_var_init(&rules);
    amxc_string_init(&rule, 0);
    amxc_string_appendf(&rule, "%sInboundMapping.[Origin == \"UPnP_IWF\"].", pcp_server);
    amxb_get(bus_ctx, amxc_string_get(&rule, 0), 0, &rules, 1);
    amxc_var_for_each(r, GETP_ARG(&rules, "0.")) {
        eport = GET_UINT32(r, "SuggestedExternalPort");
        if((proto == GET_INT32(r, "ProtocolNumber")) &&
           (eport >= startport) && (eport <= endport)) {
            if(*number >= capacity) {
                capacity += 128;
                tmp = realloc(array, capacity * sizeof(*array));
                if(!tmp) {
                    syslog(LOG_ERR, "get_portmappings_in_range() : realloc(%u) error",
                           (unsigned) sizeof(unsigned short) * capacity);
                    *number = 0;
                    free(array);
                    array = NULL;
                    break;
                }
                array = tmp;
            }
            array[*number] = eport;
            ++(*number);
        }
    }
    amxc_var_clean(&rules);
    amxc_string_clean(&rule);
    syslog(LOG_WARNING, "get_portmappings_in_range: %d (using PCP)", *number);
    return array;
}

int update_portmapping_pcp(amxb_bus_ctx_t* bus_ctx, const char* ifname, unsigned short eport, int proto,
                           unsigned short iport, const char* desc,
                           unsigned int timestamp, const char* pcp_server) {
    int r = -1;
    amxc_var_t rule;
    amxc_var_t ret;
    amxc_string_t rule_path;
    unsigned int lease_duration;

    (void) ifname;
    amxc_var_init(&ret);
    amxc_string_init(&rule_path, 0);
    amxc_string_appendf(&rule_path, "%sInboundMapping.[ProtocolNumber == %d && SuggestedExternalPort == %hu && Origin == \"UPnP_IWF\"].", pcp_server, proto, eport);
    lease_duration = (timestamp > 0) ? timestamp - upnp_time() : 0;
    amxc_var_init(&rule);
    amxc_var_init(&ret);
    amxc_var_set_type(&rule, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(uint16_t, &rule, "InternalPort", iport);
    amxc_var_add_key(uint32_t, &rule, "Lifetime", lease_duration);
    amxc_var_add_key(cstring_t, &rule, "Description", desc);
    amxb_set(bus_ctx, amxc_string_get(&rule_path, 0), &rule, &ret, 1);
    if(GETP_ARG(&ret, "0.0.") != NULL) {
        r = 0;
    }
    amxc_string_clean(&rule_path);
    amxc_var_clean(&rule);
    amxc_var_clean(&ret);
    syslog(LOG_ERR, "update_portmapping: %d (using PCP)", r);
    return r;
}

int update_portmapping_desc_timestamp_pcp(amxb_bus_ctx_t* bus_ctx, const char* ifname,
                                          unsigned short eport, int proto,
                                          const char* desc, unsigned int timestamp, const char* pcp_server) {
    int r = -1;
    amxc_var_t rule;
    amxc_var_t ret;
    amxc_string_t rule_path;
    unsigned int lease_duration;

    (void) ifname;
    amxc_var_init(&ret);
    amxc_string_init(&rule_path, 0);
    amxc_string_appendf(&rule_path, "%sInboundMapping.[ProtocolNumber == %d && SuggestedExternalPort == %hu && Origin == \"UPnP_IWF\"].", pcp_server, proto, eport);
    lease_duration = (timestamp > 0) ? timestamp - upnp_time() : 0;
    amxc_var_init(&rule);
    amxc_var_init(&ret);
    amxc_var_set_type(&rule, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(uint32_t, &rule, "Lifetime", lease_duration);
    amxc_var_add_key(cstring_t, &rule, "Description", desc);
    amxb_set(bus_ctx, amxc_string_get(&rule_path, 0), &rule, &ret, 1);
    if(GETP_ARG(&ret, "0.0.") != NULL) {
        r = 0;
    }
    amxc_string_clean(&rule_path);
    amxc_var_clean(&rule);
    amxc_var_clean(&ret);
    syslog(LOG_ERR, "update_portmapping_desc_timestamp: %d (using PCP)", r);
    return r;
}

void delete_all_pcp_entries(amxb_bus_ctx_t* bus_ctx) {
    amxc_var_t ret;
    amxc_var_t ret_amxb_del;
    amxc_var_t* mappings;
    amxc_string_t key_index;
    amxc_string_t object_string;
    int index = 0;

    amxc_var_init(&ret);
    amxc_var_init(&ret_amxb_del);
    amxc_string_init(&key_index, 0);
    amxc_string_init(&object_string, 0);

    amxb_get(bus_ctx, "PCP.Client.*.Server.*.InboundMapping.[Origin == \"UPnP_IWF\"].", 0, &ret, 1);
    mappings = GETP_ARG(&ret, "0.");
    if(mappings == NULL) {
        syslog(LOG_DEBUG, "There is no InboundMapping instance");
        goto exit;
    }

    amxc_var_for_each(pm_var, mappings) {
        int rv = -1;
        int pos = 0;
        amxc_string_setf(&key_index, "%s", amxc_var_key(pm_var));
        amxc_string_setf(&object_string, "%s", amxc_var_key(pm_var));
        pos = amxc_string_search(&key_index, "InboundMapping.", 0);
        amxc_string_remove_at(&key_index, 0, pos);
        amxc_string_replace(&key_index, "InboundMapping.", "", UINT32_MAX);
        amxc_string_replace(&key_index, ".", "", UINT32_MAX);
        amxc_string_remove_at(&object_string, pos, UINT32_MAX);
        amxc_string_appendf(&object_string, "InboundMapping.");

        if(STRING_EMPTY(amxc_string_get(&key_index, 0))) {
            syslog(LOG_ERR, "Failed to extract the index from %s", amxc_var_key(pm_var));
            goto exit;
        }
        index = atoi(amxc_string_get(&key_index, 0));
        if(index <= 0) {
            syslog(LOG_ERR, "Integer index from %s is not valid.", amxc_var_key(pm_var));
            goto exit;
        }
        if(STRING_EMPTY(amxc_string_get(&object_string, 0))) {
            syslog(LOG_ERR, "PCP extracted from %s object is empty", amxc_var_key(pm_var));
            goto exit;
        }

        rv = amxb_del(bus_ctx, amxc_string_get(&object_string, 0), index, NULL, &ret_amxb_del, 1);
        if((rv != 0) || STRING_EMPTY(GETI_CHAR(&ret_amxb_del, 0))) {
            syslog(LOG_ERR, "Failed to delete %s", amxc_var_key(pm_var));
            goto exit;
        }
    }

exit:
    amxc_var_clean(&ret);
    amxc_var_clean(&ret_amxb_del);
    amxc_string_clean(&key_index);
    amxc_string_clean(&object_string);
}
