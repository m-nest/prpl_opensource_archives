/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
** SPDX-FileCopyrightText: Copyright (c) 2025 Inango
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#ifndef AMXMISC_H_INCLUDED
#define AMXMISC_H_INCLUDED

#include <amxc/amxc.h>
#include <amxp/amxp.h>
#include <amxd/amxd_object.h>
#include <amxb/amxb.h>

#define NAT_OBJECT_PATH "NAT."

void shutdown_amx(void);

/**
 * @brief Initializes the AMX bus context
 */
int init_amx(void);
amxb_bus_ctx_t* get_amx_bus_ctx(const char* object);
void refresh_firewall_flags(void);
int get_mac_from_ip(const char*, char*);
int are_addresses_from_same_host(const char*, const char*);
int amx_is_wan_up(void);
int amx_is_wan_ppp(void);

/**
 * @brief Gets the file descriptor for AMX bus ctx
 * for given object.
 *
 * @param object The path to the object to get ctx for
 */
int get_amx_bus_ctx_fd(const char* object);

/**
 * @brief Gets the file descriptor for AMX signal events.
 */
int get_amxp_signal_fd(void);

/**
 * @brief Exchanges the value of upnp_notify_needed flag.
 */
bool exchange_upnp_notify_needed(bool needed);

/**
 * @brief Reads the bus events for given object context.
 * Should be called when the bus fd is readable.
 *
 * @param object The path to the object to read events from.
 */
void handle_bus_ctx_events(const char* object);

/**
 * @brief Adds a subscription for changes in
 * "NAT.PortMappingNumberOfEntries" parameter.
 *
 * This subscription is used to notify the UPnP subscribers
 * that total number of port mappings has changed.
 *
 * @param bus_ctx The AMX bus context.
 * @return 0 on success, error code on failure.
 */
int amx_add_portmapping_sub(amxb_bus_ctx_t* bus_ctx);

/**
 * @brief Deletes the subscription for changes in
 * "NAT.PortMappingNumberOfEntries" parameter
 *
 * @param bus_ctx The AMX bus context.
 * @return 0 on success, error code on failure.
 */
int amx_del_portmapping_sub(amxb_bus_ctx_t* bus_ctx);



int ext_is_dslite(void);
void get_dslite_external_ip(char*);
#endif

