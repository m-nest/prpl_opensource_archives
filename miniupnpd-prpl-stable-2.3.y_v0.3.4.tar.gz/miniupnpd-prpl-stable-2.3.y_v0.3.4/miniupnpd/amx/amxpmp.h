/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
** SPDX-FileCopyrightText: Copyright (c) 2025 Inango
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#ifndef AMXPORTMAPPING_H_INCLUDED
#define AMXPORTMAPPING_H_INCLUDED

#include <amxc/amxc.h>
#include <amxp/amxp.h>
#include <amxd/amxd_object.h>
#include <amxb/amxb.h>

#define PM_ALIAS_BASENAME "PortMapping-"
#define PM_ALIAS_STATIC_SUFFIX "-static"
#define UUID_LEN 36

int add_pm_rule(amxb_bus_ctx_t* bus_ctx, const char* ifname, const char* rhost,
                unsigned short eport, const char* iaddr, unsigned short iport,
                int proto, const char* desc, unsigned int timestamp);

int get_redirect_rule_pm(amxb_bus_ctx_t* bus_ctx, const char* ifname, unsigned short eport, int proto,
                         char* iaddr, int iaddrlen, unsigned short* iport,
                         char* desc, int desclen,
                         char* rhost, int rhostlen,
                         unsigned int* timestamp,
                         u_int64_t* packets, u_int64_t* bytes);

/**
 * @brief Get any redirect rule by index, regardless of its origin.
 * This function retrieves a port mapping rule by its index, allowing iteration
 * over all rules, including those not created over UPnP.
 *
 * @returns 0 on success, -1 on unexpected error, -2 if rule with
 * specified index is not found
 */
int get_redirect_rule_by_index_pm(amxb_bus_ctx_t* bus_ctx, int index,
                                  char* ifname, unsigned short* eport,
                                  char* iaddr, int iaddrlen, unsigned short* iport,
                                  int* proto, char* desc, int desclen,
                                  char* rhost, int rhostlen,
                                  unsigned int* timestamp,
                                  u_int64_t* packets, u_int64_t* bytes,
                                  u_int8_t* is_upnp_rule);

int delete_redirect_rule_pm(amxb_bus_ctx_t* bus_ctx, const char* ifname, unsigned short eport,
                            int proto);

unsigned short*
get_portmappings_in_range_pm(amxb_bus_ctx_t* bus_ctx, unsigned short startport, unsigned short endport,
                             int proto, unsigned int* number);

int update_portmapping_pm(amxb_bus_ctx_t* bus_ctx, const char* ifname, unsigned short eport, int proto,
                          unsigned short iport, const char* desc,
                          unsigned int timestamp);

int update_portmapping_desc_timestamp_pm(amxb_bus_ctx_t* bus_ctx, const char* ifname,
                                         unsigned short eport, int proto,
                                         const char* desc, unsigned int timestamp);

void delete_all_port_mapping_entries(amxb_bus_ctx_t* bus_ctx);

const char* proto_itoa(int proto);

/**
 * @brief Marks the current rule as static or not.
 * @param is_static 1 if the rule is static, 0 otherwise.
 */
void mark_current_rule_as_static(int is_static);

/**
 * @brief Checks if the current rule is static.
 * @return 1 if the current rule is static, 0 otherwise.
 */
int is_current_rule_static(void);

#endif

