/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
** SPDX-FileCopyrightText: Copyright (c) 2025 Inango
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <syslog.h>
#include <string.h>
#include <stdlib.h>
#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include <amxd/amxd_object.h>
#include <amxb/amxb.h>
#include "config.h"
#include "../upnpglobalvars.h"
#include "amxmisc.h"
#include "upnputils.h"

static amxb_bus_ctx_t* bus_ctx = NULL;
static const char* pinhole_prefix = "cpe-Pinhole-";

int init_pinhole(void) {
    int r = -1;

    if(init_amx() == 0) {
        bus_ctx = get_amx_bus_ctx("Firewall.");
        if(bus_ctx != NULL) {
            r = 0;
        }
    }
    return r;
}

void shutdown_pinhole(void) {
    shutdown_amx();
    bus_ctx = NULL;
    return;
}

int find_pinhole(UNUSED const char* ifname,
                 const char* rem_host, unsigned short rem_port,
                 const char* int_client, unsigned short int_port,
                 int proto,
                 char* desc, int desc_len, UNUSED unsigned int* timestamp) {
    int rv = -1;
    amxc_string_t expr;
    amxc_var_t ret;

    amxc_var_init(&ret);
    amxc_string_init(&expr, 0);
    amxc_string_setf(&expr, "Firewall.Pinhole.[Protocol=='%d'", proto);
    if((rem_host != NULL) && (rem_host[0] != '\0')) {
        amxc_string_appendf(&expr, " && SourcePrefixes=='%s'", rem_host);
    }
    amxc_string_appendf(&expr, " && SourcePort==%d", rem_port);
    if((int_client != NULL) && (int_client[0] != '\0')) {
        amxc_string_appendf(&expr, " && DestIP=='%s'", int_client);
    }
    amxc_string_appendf(&expr, " && DestPort==%d", int_port);
    amxc_string_appendf(&expr, "].");
    rv = amxb_get(bus_ctx, amxc_string_get(&expr, 0), 0, &ret, 1);
    if((GETP_ARG(&ret, "0.0.") != NULL) && (strlen(GETP_CHAR(&ret, "0.0.Alias")) > strlen(pinhole_prefix))) {
        rv = atoi(GETP_CHAR(&ret, "0.0.Alias") + strlen(pinhole_prefix));
        if(desc != NULL) {
            strncpy(desc, GETP_CHAR(&ret, "0.0.Description"), desc_len);
        }
        if(rv == 0) {
            rv = -1;
        }
    } else {
        rv = -1;
    }
    amxc_string_clean(&expr);
    amxc_var_clean(&ret);
    return rv;
}

int add_pinhole(UNUSED const char* ifname,
                const char* rem_host, unsigned short rem_port,
                const char* int_client, unsigned short int_port,
                int proto, const char* desc, unsigned int timestamp) {
    int rv = -1;
    amxc_var_t args;
    amxc_var_t ret;
    amxc_string_t tmp;

    amxc_var_init(&args);
    amxc_var_init(&ret);
    amxc_string_init(&tmp, 0);
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);

    syslog(LOG_NOTICE, "Interface open for upnp pinhole %s", ip_interface);

    amxc_var_add_key(cstring_t, &args, "alias", "");
    amxc_var_add_key(cstring_t, &args, "origin", "UPnP");
    amxc_var_add_key(cstring_t, &args, "interface", ip_interface);
    amxc_string_setf(&tmp, "%hu", rem_port);
    amxc_var_add_key(cstring_t, &args, "sourcePort", amxc_string_get(&tmp, 0));
    amxc_string_setf(&tmp, "%hu", int_port);
    amxc_var_add_key(cstring_t, &args, "destinationPort", amxc_string_get(&tmp, 0));
    amxc_var_add_key(cstring_t, &args, "internalClient", int_client);
    amxc_var_add_key(cstring_t, &args, "sourcePrefix", rem_host);
    amxc_var_add_key(bool, &args, "enable", true);
    amxc_var_add_key(cstring_t, &args, "description", desc);
    amxc_var_add_key(uint32_t, &args, "leaseDuration", timestamp - upnp_time());
    amxc_string_setf(&tmp, "%d", proto);
    amxc_var_add_key(cstring_t, &args, "protocol", amxc_string_get(&tmp, 0));
    rv = amxb_call(bus_ctx, "Firewall.", "setPinhole", &args, &ret, 1);
    if((GETP_ARG(&ret, "0.Alias") != NULL) && (strlen(GETP_CHAR(&ret, "0.Alias")) > strlen(pinhole_prefix))) {
        rv = atoi(GETP_CHAR(&ret, "0.Alias") + strlen(pinhole_prefix));
        if(rv == 0) {
            rv = -1;
        }
    } else {
        syslog(LOG_WARNING, "%s: setPinhole failed (%d) [%s]:%d -> [%s]:%d ", "add_pinhole(amx)", rv, rem_host, rem_port, int_client, int_port);
        rv = -1;
    }
    syslog(LOG_NOTICE, "%s: setPinhole (%d) [%s]:%d -> [%s]:%d ", "add_pinhole(amx)", rv, rem_host, rem_port, int_client, int_port);
    amxc_var_clean(&args);
    amxc_var_clean(&ret);
    return rv;
}

int delete_pinhole(uint16_t uid) {
    int rv = -1;
    amxc_string_t alias;
    amxc_var_t args;
    amxc_var_t ret;

    amxc_string_init(&alias, 0);
    amxc_var_init(&args);
    amxc_var_init(&ret);
    amxc_string_setf(&alias, "%s%u", pinhole_prefix, uid);
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &args, "alias", amxc_string_get(&alias, 0));
    rv = amxb_call(bus_ctx, "Firewall.", "deletePinhole", &args, &ret, 1);
    syslog(LOG_WARNING, "%s: (%d)", "delete_pinhole(amx)", rv);
    amxc_var_clean(&ret);
    amxc_var_clean(&args);
    amxc_string_clean(&alias);
    return rv;
}

int
get_pinhole_info(unsigned short uid,
                 char* rem_host, int rem_hostlen, unsigned short* rem_port,
                 char* int_client, int int_clientlen,
                 unsigned short* int_port,
                 int* proto, char* desc, int desclen,
                 unsigned int* timestamp,
                 u_int64_t* packets, u_int64_t* bytes) {
    int rv = -1;
    amxc_string_t alias;
    amxc_var_t args;
    amxc_var_t ret;

    amxc_string_init(&alias, 0);
    amxc_var_init(&args);
    amxc_var_init(&ret);
    amxc_string_setf(&alias, "%s%u", pinhole_prefix, uid);
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &args, "alias", amxc_string_get(&alias, 0));
    rv = amxb_call(bus_ctx, "Firewall.", "getPinhole", &args, &ret, 1);
    if(GETP_ARG(&ret, "0.0.") != NULL) {
        if(rem_host != NULL) {
            strncpy(rem_host, GETP_CHAR(&ret, "0.0.SourcePrefixes"), rem_hostlen);
        }
        if(rem_port != NULL) {
            *rem_port = (uint16_t) GETP_UINT32(&ret, "0.0.SourcePort");
        }
        if(int_client != NULL) {

            strncpy(int_client, GETP_CHAR(&ret, "0.0.DestIP"), int_clientlen);
        }
        if(int_port != NULL) {
            *int_port = (uint16_t) GETP_UINT32(&ret, "0.0.DestPort");
        }
        if(proto != NULL) {
            *proto = amxc_var_dyncast(int32_t, GETP_ARG(&ret, "0.0.Protocol"));
        }
        if(desc != NULL) {
            strncpy(desc, GETP_CHAR(&ret, "0.0.Description"), desclen);
        }
        if(timestamp != NULL) {
            *timestamp = 0;
        }
        if(packets != NULL) {
            *packets = 0;
        }
        if(bytes != NULL) {
            *bytes = 0;
        }
    }
    amxc_var_clean(&ret);
    amxc_var_clean(&args);
    amxc_string_clean(&alias);
    return rv;
}

int get_pinhole_uid_by_index(int index) {
    return (index);
}

int
update_pinhole(unsigned short uid, unsigned int timestamp) {
    int rv = -1;
    amxc_var_t args;
    amxc_var_t ret;
    amxc_string_t tmp;

    if(get_pinhole_info(uid, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, NULL) != 0) {
        return -2; /* Not found */
    }
    amxc_var_init(&args);
    amxc_var_init(&ret);
    amxc_string_init(&tmp, 0);
    amxc_string_setf(&tmp, "%s%hd", pinhole_prefix, uid);
    amxc_var_set_type(&args, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &args, "alias", amxc_string_get(&tmp, 0));
    amxc_var_add_key(cstring_t, &args, "origin", "UPnP");
    amxc_var_add_key(uint32_t, &args, "leaseDuration", timestamp - upnp_time());
    rv = amxb_call(bus_ctx, "Firewall.", "updatePinhole", &args, &ret, 1);
    if(rv == 0) {
        amxc_var_log(&ret);
        syslog(LOG_NOTICE, "%s: updatePinhole (%d)", "update_pinhole(amx)", rv);
    } else {
        syslog(LOG_WARNING, "%s: updatePinhole failed (%d)", "update_pinhole(amx)", rv);
    }
    amxc_var_clean(&args);
    amxc_var_clean(&ret);
    amxc_string_clean(&tmp);
    return rv;
}