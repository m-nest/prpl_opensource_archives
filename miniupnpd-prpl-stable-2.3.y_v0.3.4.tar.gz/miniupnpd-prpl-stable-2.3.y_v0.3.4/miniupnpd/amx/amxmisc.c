/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
** SPDX-FileCopyrightText: Copyright (c) 2025 Inango
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <amxc/amxc_variant.h>
#include <netinet/in.h>
#include <string.h>
#include <syslog.h>
#include <amxc/amxc.h>
#include <amxc/amxc_macros.h>
#include <amxp/amxp.h>
#include <amxd/amxd_object.h>
#include <amxd/amxd_path.h>
#include <amxb/amxb.h>
#include <netmodel/client.h>
#include <pthread.h>
#include <stdatomic.h>
#include "config.h"
#include "../upnpglobalvars.h"
#include "amxmisc.h"

#define FIREWALL_OBJECT_PATH "Device.Firewall."
#define FIREWALL_ENABLE_PATH "Device.Firewall.Enable"
#define FIREWALL_CONFIG_PATH "Device.Firewall.Config"
#define FIREWALL_POLICYLEVEL_PATH "Device.Firewall.PolicyLevel"
#define FIREWALL_ADVANCEDLEVEL_PATH "Device.Firewall.AdvancedLevel"
#define FIREWALL_LEVEL_HIGH_PATH "Firewall.Level.High"
#define MAX_PATH_LEN 256
#define MAX_FW_VALUE_LEN 256
#define MAX_PATH_LEN 256

atomic_bool upnp_notify_needed = false;

/**
 * @brief Get a string from the bus.
 *
 * Gets a string parameter from the bus.
 *
 * @param param_path Full path to the parameter to get.
 * @param ret_param_value A buffer of MAX_PATH_LEN bytes to write the parameter's value into.
 * @return Status indicator: 0 - success, -1 - error.
 */
static int get_string_param_from_bus(const char* param_path, char* ret_param_value) {
    char path[MAX_PATH_LEN];
    char* param_name = NULL;
    char* last_dot_ptr = NULL;
    int obj_path_len = 0;
    int rv = -1;
    amxc_var_t obj;
    const char* param_value = NULL;

    last_dot_ptr = strrchr(param_path, '.');
    obj_path_len = last_dot_ptr - param_path + 1;
    strncpy(path, param_path, obj_path_len);
    path[obj_path_len + 1] = '\0';

    if(!get_amx_bus_ctx(path)) {
        init_amx();
    }

    amxc_var_init(&obj);

    rv = amxb_get(get_amx_bus_ctx(path), param_path, 0, &obj, 1);
    when_failed_status(rv, exit, syslog(LOG_ERR, "Couldn't get value of %s (%d))", param_path, rv));

    if(amxc_var_type_of(&obj) != AMXC_VAR_ID_LIST) {
        syslog(LOG_ERR, "Couldn't get value of %s: type of returned object is not list", param_path);
        goto exit;
    }

    param_name = last_dot_ptr + 1;
    snprintf(path, MAX_PATH_LEN, "0.0.%s", param_name);
    param_value = GETP_CHAR(&obj, path);
    when_null_status(param_value, exit, syslog(LOG_ERR, "Couldn't get value of %s: got null string", param_path));

    strncpy(ret_param_value, param_value, MAX_PATH_LEN);
    rv = 0;
exit:
    amxc_var_clean(&obj);
    return rv;
}

/**
 * @brief Get the current required state of FirewallEnabled
 *
 * Gets firewall status.
 *
 * @param enabled A bool buffer to write the result into.
 * @return Status indicator: 0 - success, -1 - error.
 */
static int get_firewall_enabled(bool* enabled) {
    int rv = -1;
    amxc_var_t firewall_obj;

    if(!get_amx_bus_ctx(FIREWALL_OBJECT_PATH)) {
        init_amx();
    }
    amxc_var_init(&firewall_obj);

    rv = amxb_get(get_amx_bus_ctx(FIREWALL_OBJECT_PATH), FIREWALL_ENABLE_PATH, 0, &firewall_obj, 1);
    when_failed_status(rv, exit, syslog(LOG_ERR, "Couldn't get Firewall data (%d))", rv));

    *enabled = GETP_BOOL(&firewall_obj, "0.0.Enable");
    rv = 0;
exit:
    amxc_var_clean(&firewall_obj);
    return rv;
}

/**
 * @brief Get the current required state of InboundPinholeAllowed
 *
 * Gets firewall policy level and determined InboundPinholeAllowed status depending on it.
 *
 * @param allowed A bool buffer to write the result into.
 * @return Status indicator: 0 - success, -1 - error.
 */
static int get_inbound_pinhole_allowed(bool* allowed) {
    char firewall_config[MAX_FW_VALUE_LEN];
    char level[MAX_FW_VALUE_LEN];
    int rv = -1;

    rv = get_string_param_from_bus(FIREWALL_CONFIG_PATH, firewall_config);
    when_failed(rv, exit);

    if(strncmp(firewall_config, "High", MAX_FW_VALUE_LEN) == 0) {
        *allowed = false;
        rv = 0;
        goto exit;
    }

    if(strncmp(firewall_config, "Policy", MAX_FW_VALUE_LEN) == 0) {
        rv = get_string_param_from_bus(FIREWALL_POLICYLEVEL_PATH, level);
        when_failed(rv, exit);

        if(strncmp(level, FIREWALL_LEVEL_HIGH_PATH, MAX_FW_VALUE_LEN) == 0) {
            *allowed = false;
        } else {
            *allowed = true;
        }

        rv = 0;
        goto exit;
    }

    if(strncmp(firewall_config, "Advanced", MAX_FW_VALUE_LEN) == 0) {
        rv = get_string_param_from_bus(FIREWALL_ADVANCEDLEVEL_PATH, level);
        when_failed(rv, exit);

        if(strncmp(level, FIREWALL_LEVEL_HIGH_PATH, MAX_FW_VALUE_LEN) == 0) {
            *allowed = false;
        } else {
            *allowed = true;
        }

        rv = 0;
        goto exit;
    }

    *allowed = true;
    rv = 0;
exit:
    return rv;
}

static void init_loglevel(void) {
    amxc_var_t ret;
    amxc_var_t arg;
    uint32_t level = 200;

    amxc_var_init(&arg);
    amxc_var_init(&ret);
    amxc_var_set_type(&arg, AMXC_VAR_ID_HTABLE);
    amxb_call(get_amx_bus_ctx("UPnP."), "UPnP.", "list_trace_zones", &arg, &ret, 1);
    if(amxc_var_type_of(&ret) != AMXC_VAR_ID_NULL) {
        level = GETP_UINT32(&ret, "0.upnp");
    }
    if(level >= 500) {
        setlogmask(LOG_UPTO(LOG_DEBUG));
    } else if(level >= 400) {
        setlogmask(LOG_UPTO(LOG_INFO));
    } else if(level >= 300) {
        setlogmask(LOG_UPTO(LOG_NOTICE));
    } else {
        setlogmask(LOG_UPTO(LOG_WARNING));
    }
    amxc_var_clean(&ret);
    amxc_var_clean(&arg);
}

/**
 * @brief Get the current state of the UPnP notification needed flag
 * and set it to the new value.
 *
 * This function atomically exchanges the value of the `upnp_notify_needed`
 * flag. Used to check if a UPnP notification is needed and set it to a new value.
 *
 * @param needed The new value to set the `upnp_notify_needed` flag to.
 * @return The current value of the `upnp_notify_needed` flag before the exchange.
 */
bool exchange_upnp_notify_needed(bool needed) {
    return atomic_exchange(&upnp_notify_needed, needed);
}

/**
 * @brief Callback function for port mapping entries change event.
 *
 * This function is called when the number of port mappings
 * changes in the bus. It creates a notification
 * to inform the subscribers about the change.
 */
static void portmapping_entries_changed(UNUSED const char* const sig_name,
                                        UNUSED const amxc_var_t* const data,
                                        UNUSED void* const priv) {
    /* Raise a flag to indicate that a UPnP notification is needed.
     * Notification will be processed in the main loop */
    atomic_fetch_add(&system_update_id, 1);
    exchange_upnp_notify_needed(true);
    syslog(LOG_INFO, "Port mapping entries changed, notification needed");
}

int amx_add_portmapping_sub(amxb_bus_ctx_t* bus_ctx) {
    int res = amxb_subscribe(bus_ctx, NAT_OBJECT_PATH,
                             "(notification == 'dm:object-changed') && \
                                (contains('parameters.PortMappingNumberOfEntries'))",
                             portmapping_entries_changed, NULL);
    if(res != 0) {
        syslog(LOG_ERR,
               "Failed to subscribe to object-changed event for "
               "'%s' object: res '%d'",
               NAT_OBJECT_PATH, res);
        return res;
    }
    syslog(LOG_INFO, "Subscribed to portmapping notifications");
    return res;
}

int amx_del_portmapping_sub(amxb_bus_ctx_t* bus_ctx) {
    int res = amxb_unsubscribe(bus_ctx, NAT_OBJECT_PATH,
                               portmapping_entries_changed, NULL);
    if(res != 0) {
        syslog(LOG_ERR,
               "Failed to unsubscribe from object-changed event for "
               "'%s' object: res '%d'",
               NAT_OBJECT_PATH, res);
        return res;
    }

    syslog(LOG_INFO, "Unsubscribed from portmapping notifications");
    return res;
}

int init_amx(void) {
    int r = -1;
    amxc_var_t csv_list;


    if(get_amx_bus_ctx("UPnP.") != NULL) {
        r = 0;
    } else {
        amxc_var_init(&csv_list);
        amxc_var_set_csv_string_t(&csv_list, amx_backend_urls);
        amxc_var_cast(&csv_list, AMXC_VAR_ID_LIST);
        amxc_var_for_each(backend, &csv_list) {
            if((r = amxb_be_load(amxc_var_constcast(cstring_t, backend))) != 0) {
                syslog(LOG_WARNING, "Couldn't open backend %s (%d)", amxc_var_constcast(cstring_t, backend), r);
            }
        }

        amxc_var_set_csv_string_t(&csv_list, amx_sock_urls);
        amxc_var_cast(&csv_list, AMXC_VAR_ID_LIST);
        amxc_var_for_each(sock, &csv_list) {
            amxb_bus_ctx_t* tmp = NULL;
            if((r = amxb_connect(&tmp, amxc_var_constcast(cstring_t, sock))) != 0) {
                syslog(LOG_WARNING, "Couldn't open sock %s (%d)", amxc_var_constcast(cstring_t, sock), r);
            }
        }

        amxc_var_clean(&csv_list);

        netmodel_initialize();
        init_loglevel();

        r = amx_add_portmapping_sub(get_amx_bus_ctx(NAT_OBJECT_PATH));
        if (r != 0) {
            syslog(LOG_ERR, "Failed to add portmapping subscription: %d", r);
            return r;
        }
    }
    return r;
}

void shutdown_amx(void) {
    netmodel_cleanup();
    amx_del_portmapping_sub(get_amx_bus_ctx(NAT_OBJECT_PATH));
    amxb_be_remove_all();
    return;
}

amxb_bus_ctx_t* get_amx_bus_ctx(const char* object) {
    amxb_bus_ctx_t* bus = NULL;

    if((bus = amxb_be_who_has(object)) == NULL) {
        syslog(LOG_WARNING, "Bus for %s isn't found", object);
    }
    return bus;
}

int get_amx_bus_ctx_fd(const char* object) {
    if(get_amx_bus_ctx(object) == NULL) {
        int r = init_amx();
        if(r != 0) {
            return -1;
        }
    }
    return amxb_get_fd(get_amx_bus_ctx(object));
}

int get_amxp_signal_fd(void) {
    return amxp_signal_fd();
}

void handle_bus_ctx_events(const char* object) {
    int result = amxb_read(get_amx_bus_ctx(object));
    if (result < 0) {
        syslog(LOG_ERR, "Error reading from bus: %d\n", result);
    }
}

/**
 * @brief Refreshes firewall-related flags (FirewallEnabled and InboundPinholeAllowed)
 *
 * Refreshes firewall-related flags (FirewallEnabled and InboundPinholeAllowed)
 * in global runtime_flags.
 *
 */
void refresh_firewall_flags(void) {
#ifdef ENABLE_IPV6
    int ret;
    bool firewall_enabled;
    bool inbound_pinhole_allowed;

    ret = get_firewall_enabled(&firewall_enabled);
    if(ret != 0) {
        syslog(LOG_ERR, "Failed to get firewall status");
        firewall_enabled = false;
    }

    if(firewall_enabled) {
        CLEARFLAG(IPV6FCFWDISABLEDMASK);
    } else {
        SETFLAG(IPV6FCFWDISABLEDMASK);
    }

    ret = get_inbound_pinhole_allowed(&inbound_pinhole_allowed);
    if(ret != 0) {
        syslog(LOG_ERR, "Failed to get inbound pinhole permission status");
        inbound_pinhole_allowed = false;
    }

    if(inbound_pinhole_allowed) {
        CLEARFLAG(IPV6FCINBOUNDDISALLOWEDMASK);
    } else {
        SETFLAG(IPV6FCINBOUNDDISALLOWEDMASK);
    }
#endif
}

static int get_host_from_address(const char* addr, amxc_var_t* ret) {
    int rv = -1;
    amxc_string_t tmp;

    amxc_string_init(&tmp, 0);
    amxc_string_setf(&tmp, "Hosts.Host.*.IPv4Address.[IPAddress=='%s'].", addr);
    when_failed(amxb_get(get_amx_bus_ctx("Hosts."), amxc_string_get(&tmp, 0), 0, ret, 0), exit);
    if(GETP_ARG(ret, "0.0.") == NULL) {
        amxc_string_setf(&tmp, "Hosts.Host.*.IPv6Address.[IPAddress=='%s'].", addr);
        when_failed(amxb_get(get_amx_bus_ctx("Hosts."), amxc_string_get(&tmp, 0), 0, ret, 0), exit);
        if(GETP_ARG(ret, "0.0.") != NULL) {
            rv = 0;
        }
    } else {
        rv = 0;
    }
exit:
    amxc_string_clean(&tmp);
    return rv;
}

/**
 * @brief Get MAC address of a device by it's IP address.
 *
 * Takes an IP address of a device and returns it's MAC address.
 *
 * @param addr The IP address (IPv4 or IPv6) of the device to get the MAC address of.
 * @param ret_macaddr Preallocated buffer of at least MAC_ADDR_STR_LEN bytes, into which
 * the MAC address of the device will be written.
 * @return -1 for error while retrieving the MAC address, 0 for success.
 */
int get_mac_from_ip(const char* addr, char* ret_macaddr) {
    char line[256];
    char ip[16];
    char hw_type[16];
    char flags[16];
    char mac[18];
    char mask[16];
    char device[16];
    FILE* f;

    f = fopen("/proc/net/arp", "r");
    if(f == NULL) {
        return -1;
    }

    // skip header line
    if(fgets(line, sizeof(line), f) == NULL) {
        fclose(f);
        return -1;
    }

    // find the line for addr and read it's mac field into ret_macaddr
    while(fgets(line, sizeof(line), f)) {
        if(sscanf(line, "%15s %15s %15s %17s %15s %15s",
                  ip, hw_type, flags, mac, mask, device) == 6) {
            if(strncmp(ip, addr, INET6_ADDRSTRLEN) == 0) {
                strncpy(ret_macaddr, mac, MAC_ADDR_STR_LEN);
                fclose(f);
                return 0;
            }
        }
    }

    fclose(f);
    return -1;
}

int are_addresses_from_same_host(const char* addr_a, const char* addr_b) {
    int rv = 0;
    amxc_var_t ret_a;
    amxc_var_t ret_b;
    const char* host_a;
    const char* host_b;

    if(get_amx_bus_ctx("UPnP.") == NULL) {
        init_amx();
    }
    amxc_var_init(&ret_a);
    amxc_var_init(&ret_b);
    when_true_status(strcmp(addr_a, addr_b) == 0, exit, rv = 1);
    when_failed(get_host_from_address(addr_a, &ret_a), exit);
    when_failed(get_host_from_address(addr_b, &ret_b), exit);
    host_a = amxc_var_key(GETP_ARG(&ret_a, "0.0."));
    host_b = amxc_var_key(GETP_ARG(&ret_b, "0.0."));
    when_str_empty(host_a, exit);
    when_str_empty(host_b, exit);
    when_null(strstr(host_a, "IPv"), exit);
    if(strncmp(host_a, host_b, (strstr(host_a, "IP") - host_a)) == 0) {
        syslog(LOG_DEBUG, "Addresses are from the same host %s, %s", addr_a, addr_b);
        rv = 1;
    } else {
        syslog(LOG_DEBUG, "Addresses aren't from the same host %s, %s", addr_a, addr_b);
    }
exit:
    amxc_var_clean(&ret_a);
    amxc_var_clean(&ret_b);
    return rv;
}

int amx_is_wan_up(void) {
    int rv = -1;
    amxc_var_t ret;
    amxc_var_t wan_obj;
    amxc_string_t wan_ip_path;
    amxd_path_t path;

    if(get_amx_bus_ctx("UPnP.") == NULL) {
        init_amx();
    }
    amxc_var_init(&ret);
    amxc_var_init(&wan_obj);
    amxc_string_init(&wan_ip_path, 0);
    amxd_path_init(&path, "Device.Logical.Interface.[Alias=='wan'].X_PRPLWARE-COM_WAN.");
    rv = amxb_resolve(get_amx_bus_ctx("Device.Logical."), &path, &ret);
    when_failed_status(rv, exit, syslog(LOG_ERR, "Couldn't resolve Device.Logical.Interface.[Alias=='wan'].X_PRPLWARE-COM_WAN. to a fix path (%d) bus_ctx: %p", rv, get_amx_bus_ctx("Device.Logical.")));
    when_false(amxc_var_type_of(&ret) != AMXC_VAR_ID_NULL, exit);
    rv = amxb_get(get_amx_bus_ctx("Device.Logical."), GETI_CHAR(&ret, 0), 0, &wan_obj, 1);
    when_failed_status(rv, exit, syslog(LOG_ERR, "Couldn't get Logical interface %s data (%d))", GETI_CHAR(&ret, 0), rv));
    rv = -1;
    amxc_string_setf(&wan_ip_path, "0.'%s'.IPv4Address", GETI_CHAR(&ret, 0));
    if(strcmp(GETP_CHAR(&wan_obj, amxc_string_get(&wan_ip_path, 0)), "") != 0) {
        rv = 0;
    }
    amxc_string_setf(&wan_ip_path, "0.'%s'.IPv6Address", GETI_CHAR(&ret, 0));
    if(strcmp(GETP_CHAR(&wan_obj, amxc_string_get(&wan_ip_path, 0)), "") != 0) {
        rv = 0;
    }
exit:
    syslog(LOG_INFO, "amx_is_wan_up: %d (%s)", rv, GETI_CHAR(&ret, 0));
    amxc_string_clean(&wan_ip_path);
    amxc_var_clean(&ret);
    amxc_var_clean(&wan_obj);
    amxd_path_clean(&path);
    return rv;
}

int amx_is_wan_ppp(void) {
    bool ppp = false;

    if(get_amx_bus_ctx("UPnP.") == NULL) {
        init_amx();
    }
    ppp = netmodel_hasFlag(ip_interface, "ppp", "", "down");
    return ppp;
}

/**
 * @brief Checks if DSLite is enabled on the device.
 *
 * This function queries the AMX bus to determine if the DSLite interface
 * is currently enabled. It searches for the interface setting with the
 * status 'Enabled'. If found, it returns 1 indicating DSLite is enabled,
 * otherwise returns 0.
 *
 * @return int
 * - 1 if DSLite is enabled.
 * - 0 if DSLite is not enabled or if an error occurs during the check.
 *
 * @note This function logs errors and debug information using syslog.
 */
int ext_is_dslite(void) {
    int rv = 0;
    amxc_var_t ret;

    amxc_var_init(&ret);
    rv = amxb_get(get_amx_bus_ctx("DSLite."), "DSLite.InterfaceSetting.[Status=='Enabled'].", 0, &ret, 1);
    if(rv != 0) {
        syslog(LOG_ERR, "Couldn't search for a valid DSLite interface assuming it's not (%d)", rv);
        rv = 0;
        goto exit;
    }
    if(GETP_ARG(&ret, "0.0.") != NULL) {
        rv = 1;
    }
exit:
    syslog(LOG_DEBUG, "ext_is_dslite: %d", rv);
    amxc_var_clean(&ret);
    return rv;
}

 /**
 * @brief Retrieves the external IP address used for DSLite.
 *
 * This function queries the PCP (Port Control Protocol) client to obtain the
 * external IP address assigned for DSLite. If the PCP client is enabled and
 * the server status is 'Enabled', it copies the external IP address into
 * the provided buffer. If the retrieval fails or the PCP client is not enabled,
 * it sets the external IP address string to an empty string.
 *
 * @param ext_ip_addr A pointer to a character buffer where the external IP address
 *                    will be stored. The buffer must be at least INET_ADDRSTRLEN bytes long.
 *
 * @note The function uses `strncpy` to copy the IP address and ensures null-termination.
 */
void get_dslite_external_ip(char* ext_ip_addr) {
    int rv = 0;
    amxc_var_t ret;

    amxc_var_init(&ret);
    rv = amxb_get(get_amx_bus_ctx("PCP."), "PCP.Client.[Status=='Enabled'].Server.[Status=='Enabled']", 0, &ret, 1);
    if((rv == 0) && (GETP_ARG(&ret, "0.0.") != NULL)) {
        strncpy(ext_ip_addr, GETP_CHAR(&ret, "0.0.ExternalIPAddress"), INET_ADDRSTRLEN);
    } else {
        strcpy(ext_ip_addr, "");
    }
    amxc_var_clean(&ret);
}
