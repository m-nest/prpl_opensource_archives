/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2023 SoftAtHome
** SPDX-FileCopyrightText: Copyright (c) 2025 Inango
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/

#include <syslog.h>
#include <string.h>
#include <stdlib.h>
#include "../macros.h"
#include "../upnpevents.h"
#include "../upnpglobalvars.h"
#include "amxpmp.h"
#include "amxrdr.h"

time_t upnp_time(void);

int current_rule_is_static = false;

void mark_current_rule_as_static(int is_static) {
    current_rule_is_static = is_static;
}

int is_current_rule_static(void) {
    return current_rule_is_static;
}

/**
 * @brief Generates a Alias field for PortMapping instance
 * To ensure uniqueness, the alias is generated with a UUID.
 *
 * @return A newly allocated string containing the alias
 * The caller is responsible for freeing the returned string.
 */
static char* generate_alias_for_pm() {
    int fd = -1;
    char uuid_str[UUID_LEN + 1] = {0};
    char* alias = NULL;
    size_t alias_len = 0;

    // Generate a UUID
    fd = open("/proc/sys/kernel/random/uuid", O_RDONLY);
    if(fd < 0) {
        syslog(LOG_ERR,
               "generate_alias_for_pm: failed to open "
               "/proc/sys/kernel/random/uuid");
        return NULL;
    }

    if(read(fd, uuid_str, UUID_LEN) <= 0) {
        syslog(LOG_ERR,
               "generate_alias_for_pm: failed to read UUID from "
               "/proc/sys/kernel/random/uuid");
        close(fd);
        return NULL;
    }
    uuid_str[UUID_LEN] = '\0';
    close(fd);

    /* Allocate memory for the final alias
     * Alias template: "PortMapping-<uuid_str>-static" */
    alias_len = strlen(PM_ALIAS_BASENAME) + strlen(uuid_str) +
                strlen(PM_ALIAS_STATIC_SUFFIX) + 1;
    alias = (char*)malloc(alias_len);
    if(!alias) {
        syslog(LOG_ERR,
               "generate_alias_for_pm: failed to allocate memory for alias");
        return NULL;
    }

    // Format the alias
    snprintf(alias, alias_len, "%s%s%s", PM_ALIAS_BASENAME, uuid_str,
             PM_ALIAS_STATIC_SUFFIX);
    return alias;
}

const char* proto_itoa(int proto) {
    const char* protocol;
    switch(proto) {
    case IPPROTO_UDP:
        protocol = "UDP";
        break;
    case IPPROTO_TCP:
        protocol = "TCP";
        break;
#ifdef IPPROTO_UDPLITE
    case IPPROTO_UDPLITE:
        protocol = "UDPLITE";
        break;
#endif /* IPPROTO_UDPLITE */
    default:
        protocol = "*UNKNOWN*";
    }
    return protocol;
}

/* proto_atoi()
 * convert the string "UDP" or "TCP" to IPPROTO_UDP and IPPROTO_UDP */
static int proto_atoi(const char* protocol) {
    int proto = IPPROTO_TCP;
    if(strcasecmp(protocol, "UDP") == 0) {
        proto = IPPROTO_UDP;
    }
#ifdef IPPROTO_UDPLITE
    else if(strcasecmp(protocol, "UDPLITE") == 0) {
        proto = IPPROTO_UDPLITE;
    }
#endif /* IPPROTO_UDPLITE */
    return proto;
}

int add_pm_rule(amxb_bus_ctx_t* bus_ctx, const char* ifname, const char* rhost,
                unsigned short eport, const char* iaddr, unsigned short iport,
                int proto, const char* desc, unsigned int timestamp) {
    int r = -1;
    int rv = -1;
    amxc_var_t rule;
    amxc_var_t ret;
    unsigned int lease_duration;
    uint32_t nb_try = 0;

    (void) ifname;
    lease_duration = (timestamp > 0) ? timestamp - upnp_time() : 0;
    amxc_var_init(&rule);
    amxc_var_init(&ret);
    amxc_var_set_type(&rule, AMXC_VAR_ID_HTABLE);

    syslog(LOG_NOTICE, "Interface open for upnp pinhole %s", ip_interface);

    amxc_var_add_key(bool, &rule, "Enable", true);
    amxc_var_add_key(cstring_t, &rule, "Origin", "UPnP");
    amxc_var_add_key(cstring_t, &rule, "Interface", ip_interface);
    amxc_var_add_key(cstring_t, &rule, "RemoteHost", rhost);
    amxc_var_add_key(cstring_t, &rule, "InternalClient", iaddr);
    amxc_var_add_key(uint16_t, &rule, "ExternalPort", eport);
    amxc_var_add_key(uint16_t, &rule, "InternalPort", iport);
    amxc_var_add_key(cstring_t, &rule, "Protocol", proto_itoa(proto));
    amxc_var_add_key(uint32_t, &rule, "LeaseDuration", lease_duration);
    amxc_var_add_key(uint32_t, &rule, "InactivityTimeout", (uint32_t) ruleset_timeout);
    amxc_var_add_key(cstring_t, &rule, "Description", desc);

    /* If the current rule is static, we generate an alias that
     * contains the '-static' suffix.
     * This alias is used to identify the rule as static for Get actions */
    if(is_current_rule_static()) {
        char* alias = generate_alias_for_pm();
        if(!alias) {
            syslog(
                LOG_ERR,
                "add_pm_rule: failed to generate alias for PortMapping rule");
            goto exit;
        }
        syslog(LOG_INFO, "add_pm_rule: generated alias: %s", alias);
        amxc_var_add_key(cstring_t, &rule, "Alias", alias);
        free(alias);
    }

    rv = amxb_add(bus_ctx, "NAT.PortMapping.", 0, NULL, &rule, &ret, 1);
    if((rv == AMXB_STATUS_OK) && (GETP_ARG(&ret, "0.path") != NULL)) {
        r = 0;
        do {
            syslog(LOG_DEBUG, "Check if PortMapping is enabled");
            r = amxb_get(bus_ctx, GETP_CHAR(&ret, "0.path"), 0, &rule, 0);
            if((r != 0)) {
                r = -1;
                break;
            }
        } while(strcmp(GETP_CHAR(&rule, "0.0.Status"), "Disabled") == 0 && ++nb_try < MAX_NB_TRY && usleep(100));
    }

exit:
    amxc_var_clean(&rule);
    amxc_var_clean(&ret);
    syslog(LOG_WARNING, "redirecting port %hu to %s:%hu protocol %s for %s: %d (%d)", eport, iaddr, iport, proto_itoa(proto), desc, r, rv);
    return r;
}

/* get_redirect_rule() for PortMapping
 * return value : 0 success (found)
 * -1 = error or rule not found */
int get_redirect_rule_pm(amxb_bus_ctx_t* bus_ctx,
                         const char* ifname, unsigned short eport, int proto,
                         char* iaddr, int iaddrlen, unsigned short* iport,
                         char* desc, int desclen,
                         char* rhost, int rhostlen,
                         unsigned int* timestamp,
                         u_int64_t* packets, u_int64_t* bytes) {
    int r = -1;
    amxc_var_t ret;
    amxc_var_t* tmp;
    amxc_string_t rule;

    (void) ifname;
    (packets) ? *packets = 0 : (void) packets;
    (bytes) ? *bytes = 0 : (void) bytes;
    amxc_var_init(&ret);
    amxc_string_init(&rule, 0);
    amxc_string_appendf(&rule, "NAT.PortMapping.[Protocol == \"%s\" && ExternalPort == %hu && Origin == \"UPnP\"].", proto_itoa(proto), eport);
    amxb_get(bus_ctx, amxc_string_get(&rule, 0), 0, &ret, 1);
    tmp = GETP_ARG(&ret, "0.0.");
    if(tmp != NULL) {
        int remaining_lease_time = GET_UINT32(tmp, "RemainingLeaseTime");
        r = 0;
        *iport = (uint16_t) GET_UINT32(tmp, "InternalPort");
        if(iaddr) {
            strncpy(iaddr, GET_CHAR(tmp, "InternalClient"), iaddrlen);
        }
        if(desc) {
            strncpy(desc, GET_CHAR(tmp, "Description"), desclen);
        }
        if(timestamp) {
            /* If Alias parameter contains the '-static' suffix,
             * it indicates that the rule was created with LeaseDuration=0,
             * so we need to return LeaseDuration=0, even if this is not
             * the real value of the lease duration */
            const char* alias = GET_CHAR(tmp, "Alias");
            if (alias && (strlen(alias) > strlen(PM_ALIAS_STATIC_SUFFIX)) &&
                (strcmp(alias + strlen(alias) - strlen(PM_ALIAS_STATIC_SUFFIX),
                        PM_ALIAS_STATIC_SUFFIX) == 0)) {
                syslog(LOG_INFO,
                       "get_redirect_rule_pm: find static rule, "
                       "setting timestamp to 0");
                *timestamp = 0;
            } else {
                *timestamp = upnp_time() + remaining_lease_time;
            }
        }
        if(rhost) {
            strncpy(rhost, GET_CHAR(tmp, "RemoteHost"), rhostlen);
        }
    }
    amxc_var_clean(&ret);
    amxc_string_clean(&rule);
    syslog(LOG_WARNING, "get_redirect_rule: %d", r);
    return r;
}

int get_redirect_rule_by_index_pm(amxb_bus_ctx_t* bus_ctx, int index,
                                      char* ifname, unsigned short* eport,
                                      char* iaddr, int iaddrlen,
                                      unsigned short* iport, int* proto,
                                      char* desc, int desclen, char* rhost,
                                      int rhostlen, unsigned int* timestamp,
                                      u_int64_t* packets, u_int64_t* bytes,
                                      u_int8_t* is_upnp_rule) {
    int rv = -1;
    const char* origin = NULL;
    int remaining_lease_time = 0;
    uint32_t size = 0;
    amxc_var_t ret;
    amxc_array_t* rule_paths;
    const amxc_htable_t* htable_rules;
    amxc_htable_it_t* hit;
    amxc_var_t* rule;
    amxc_string_t search_path;

    (void)ifname;
    (packets) ? * packets = 0 : (void)packets;
    (bytes) ? * bytes = 0 : (void)bytes;
    (is_upnp_rule) ? * is_upnp_rule = 0 : (void)is_upnp_rule;
    amxc_var_init(&ret);
    amxc_string_init(&search_path, 0);

    amxc_string_appendf(&search_path, "NAT.PortMapping.*.");
    rv = amxb_get(bus_ctx, amxc_string_get(&search_path, 0), 0, &ret, 1);
    if(rv != 0) {
        syslog(LOG_ERR,
               "get_redirect_rule_by_index_pm: failed to get PortMapping "
               "entries");
        rv = -1;
        goto exit;
    }

    htable_rules = amxc_var_constcast(amxc_htable_t, GETP_ARG(&ret, "0."));
    /* We need to sort retrieved keys, because htable iteration is not ordered */
    rule_paths = amxc_htable_get_sorted_keys(htable_rules);
    size = amxc_array_size(rule_paths);
    if(size == 0 || index >= size) {
        syslog(
            LOG_WARNING,
            "get_redirect_rule_by_index_pm: rule with index %d not found",
            index);
        rv = -2;
        goto exit;
    }

    hit = amxc_htable_get(
        htable_rules, (const char*)amxc_array_get_data_at(rule_paths, index));
    rule = amxc_var_from_htable_it(hit);
    if(!rule) {
        syslog(LOG_ERR,
               "get_redirect_rule_by_index_pm: failed to get PortMapping "
               "entry at index %d",
               index);
        rv = -1;
        goto exit;
    }

    origin = GET_CHAR(rule, "Origin");
    if(!origin) {
        syslog(
            LOG_ERR,
            "get_redirect_rule_by_index_pm: failed to get Origin parameter"
            " from PortMapping entry at index %d",
            index);
        rv = -1;
        goto exit;
    }
    if(strcmp(origin, "UPnP") == 0) {
        if(is_upnp_rule) {
            *is_upnp_rule = 1;
        }
    }

    remaining_lease_time = GET_UINT32(rule, "RemainingLeaseTime");
    *iport = (uint16_t)GET_UINT32(rule, "InternalPort");
    *eport = (uint16_t)GET_UINT32(rule, "ExternalPort");
    *proto = proto_atoi(GET_CHAR(rule, "Protocol"));
    if(iaddr) {
        strncpy(iaddr, GET_CHAR(rule, "InternalClient"), iaddrlen);
    }
    if(desc) {
        strncpy(desc, GET_CHAR(rule, "Description"), desclen);
    }
    if(timestamp) {
        /* If Alias parameter contains the '-static' suffix,
         * it indicates that the rule was created with LeaseDuration=0,
         * so we need to return LeaseDuration=0, even if this is not
         * the real value of the lease duration */
        const char* alias = GET_CHAR(rule, "Alias");
        if(alias && (strlen(alias) > strlen(PM_ALIAS_STATIC_SUFFIX)) &&
           (strcmp(alias + strlen(alias) - strlen(PM_ALIAS_STATIC_SUFFIX),
                   PM_ALIAS_STATIC_SUFFIX) == 0)) {
            syslog(LOG_INFO,
                   "get_redirect_rule_by_index_pm: find static rule, "
                   "setting timestamp to 0");
            *timestamp = 0;
        } else {
            *timestamp = upnp_time() + remaining_lease_time;
        }
    }
    if(rhost) {
        strncpy(rhost, GET_CHAR(rule, "RemoteHost"), rhostlen);
    }

    rv = 0;
exit:
    amxc_array_delete(&rule_paths, NULL);
    amxc_string_clean(&search_path);
    amxc_var_clean(&ret);
    syslog(LOG_INFO, "get_redirect_rule_by_index_pm: %d", rv);
    return rv;
}

/* delete_redirect_rule() for PMP
* return value : 0 success (found)
* -1 = unexpected error,
* -2 = rule is not found
* -3 = no authority to delete rule */
int delete_redirect_rule_pm(amxb_bus_ctx_t* bus_ctx, const char* ifname, unsigned short eport, int proto) {
    int r = -1;
    amxc_string_t rule;
    amxc_var_t ret;
    amxc_var_t *entry;
    const char* origin;
    const char* alias;

    (void) ifname;
    amxc_var_init(&ret);
    amxc_string_init(&rule, 0);

    // First we need to check if the rule exists, if not,
    // we return error code -2
    amxc_string_setf(&rule,
                     "NAT.PortMapping.[Protocol == \"%s\" &&"
                     "ExternalPort == %hu].",
                     proto_itoa(proto), eport);
    amxb_get(bus_ctx, amxc_string_get(&rule, 0), 0, &ret, 1);
    entry = amxc_var_get_first(GETP_ARG(&ret, "0."));
    if (!entry) {
        syslog(LOG_ERR,
               "delete_redirect_rule_pm: no entry found"
               " for port '%hu' and protocol '%s'",
               eport, proto_itoa(proto));
        r = -2;
        goto exit;
    }

    /* Now we check the origin of the rule, we can only delete rules that
     * were created by us and its origin is "UPnP".
     * If origin is not "UPnP", we return error code -3
     * to indicate that we have no authority to delete this rule */
    origin = GET_CHAR(entry, "Origin");
    if (!origin) {
        syslog(LOG_ERR,
               "delete_redirect_rule_pm: failed to get Origin parameter"
               " from PortMapping entry for port '%hu' and protocol '%s'",
               eport, proto_itoa(proto));
        r = -1;
        goto exit;
    }
    if (strcmp(origin, "UPnP") != 0) {
        syslog(LOG_ERR,
               "delete_redirect_rule_pm: Origin is not 'UPnP' for"
               " port '%hu' and protocol '%s', have no authority to delete",
               eport, proto_itoa(proto));
        r = -3;
        goto exit;
    }

    amxb_del(bus_ctx, amxc_string_get(&rule, 0), 0, NULL, &ret, 1);
    alias = GETI_CHAR(&ret, 0);
    if(alias && (alias[0] != '\0')) {
        r = 0;
    }
exit:
    amxc_string_clean(&rule);
    amxc_var_clean(&ret);
    syslog(LOG_WARNING, "delete_redirect_rule: %d", r);
    return r;
}

unsigned short*
get_portmappings_in_range_pm(amxb_bus_ctx_t* bus_ctx, unsigned short startport, unsigned short endport,
                             int proto, unsigned int* number) {
    unsigned short* array = NULL;
    unsigned short* tmp;
    unsigned int capacity = 0;
    unsigned short eport;
    amxc_var_t rules;
    amxc_string_t rule;

    *number = 0;
    amxc_var_init(&rules);
    amxc_string_init(&rule, 0);
    amxc_string_appendf(&rule, "NAT.PortMapping.[Origin == \"UPnP\"].");
    amxb_get(bus_ctx, amxc_string_get(&rule, 0), 0, &rules, 1);
    amxc_var_for_each(r, GETP_ARG(&rules, "0.")) {
        eport = GET_UINT32(r, "ExternalPort");
        if((proto == proto_atoi(GET_CHAR(r, "Protocol"))) &&
           (eport >= startport) && (eport <= endport)) {
            if(*number >= capacity) {
                capacity += 128;
                tmp = realloc(array, capacity * sizeof(*array));
                if(!tmp) {
                    syslog(LOG_ERR, "get_portmappings_in_range() : realloc(%u) error",
                           (unsigned) sizeof(unsigned short) * capacity);
                    *number = 0;
                    free(array);
                    array = NULL;
                    break;
                }
                array = tmp;
            }
            array[*number] = eport;
            ++(*number);
        }
    }
    amxc_var_clean(&rules);
    amxc_string_clean(&rule);
    syslog(LOG_WARNING, "get_portmappings_in_range: %d", *number);
    return array;
}

int update_portmapping_pm(amxb_bus_ctx_t* bus_ctx, const char* ifname, unsigned short eport, int proto,
                          unsigned short iport, const char* desc,
                          unsigned int timestamp) {
    int r = -1;
    amxc_var_t rule;
    amxc_var_t ret;
    unsigned int lease_duration;

    (void) ifname;
    amxc_var_init(&ret);
    lease_duration = (timestamp > 0) ? timestamp - upnp_time() : 0;
    amxc_var_init(&rule);
    amxc_var_init(&ret);
    amxc_var_set_type(&rule, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &rule, "protocol", proto_itoa(proto));
    amxc_var_add_key(cstring_t, &rule, "origin", "UPnP");
    amxc_var_add_key(uint16_t, &rule, "externalPort", eport);
    amxc_var_add_key(uint16_t, &rule, "internalPort", iport);
    amxc_var_add_key(uint32_t, &rule, "leaseDuration", lease_duration);
    amxc_var_add_key(cstring_t, &rule, "description", desc);
    r = amxb_call(bus_ctx, "NAT.", "updatePortMapping", &rule, &ret, 1);
    amxc_var_clean(&rule);
    amxc_var_clean(&ret);
    syslog(LOG_ERR, "update_portmapping: %d", r);
    return r;
}

int update_portmapping_desc_timestamp_pm(amxb_bus_ctx_t* bus_ctx, const char* ifname,
                                         unsigned short eport, int proto,
                                         const char* desc, unsigned int timestamp) {
    int r = -1;
    amxc_var_t rule;
    amxc_var_t ret;
    unsigned int lease_duration;

    (void) ifname;
    amxc_var_init(&ret);
    lease_duration = (timestamp > 0) ? timestamp - upnp_time() : 0;
    amxc_var_init(&rule);
    amxc_var_init(&ret);
    amxc_var_set_type(&rule, AMXC_VAR_ID_HTABLE);
    amxc_var_add_key(cstring_t, &rule, "protocol", proto_itoa(proto));
    amxc_var_add_key(cstring_t, &rule, "origin", "UPnP");
    amxc_var_add_key(uint16_t, &rule, "externalPort", eport);
    amxc_var_add_key(uint32_t, &rule, "leaseDuration", lease_duration);
    amxc_var_add_key(cstring_t, &rule, "description", desc);
    r = amxb_call(bus_ctx, "NAT.", "updatePortMapping", &rule, &ret, 1);
    amxc_var_clean(&rule);
    amxc_var_clean(&ret);
    syslog(LOG_ERR, "update_portmapping_desc_timestamp: %d", r);
    return r;
}

void delete_all_port_mapping_entries(amxb_bus_ctx_t* bus_ctx) {
    amxc_var_t ret;
    amxc_var_t ret_amxb_del;
    amxc_var_t* mappings;
    amxc_string_t key_index;
    int index = 0;

    amxc_var_init(&ret);
    amxc_var_init(&ret_amxb_del);
    amxc_string_init(&key_index, 0);

    amxb_get(bus_ctx, "NAT.PortMapping.[Origin == \"UPnP\"].", 0, &ret, 1);
    mappings = GETP_ARG(&ret, "0.");
    if(mappings == NULL) {
        syslog(LOG_DEBUG, "There is no PortMapping instance");
        goto exit;
    }

    amxc_var_for_each(pm_var, mappings) {
        int rv = -1;
        amxc_string_setf(&key_index, "%s", amxc_var_key(pm_var));
        amxc_string_replace(&key_index, "NAT.PortMapping.", "", UINT32_MAX);
        amxc_string_replace(&key_index, ".", "", UINT32_MAX);
        if(STRING_EMPTY(amxc_string_get(&key_index, 0))) {
            syslog(LOG_ERR, "Failed to extract the index from %s", amxc_var_key(pm_var));
            goto exit;
        }
        index = atoi(amxc_string_get(&key_index, 0));
        if(index <= 0) {
            syslog(LOG_ERR, "Integer index from %s is not valid.", amxc_var_key(pm_var));
            goto exit;
        }

        rv = amxb_del(bus_ctx, "NAT.PortMapping.", index, NULL, &ret_amxb_del, 1);
        if((rv != 0) || STRING_EMPTY(GETI_CHAR(&ret_amxb_del, 0))) {
            syslog(LOG_ERR, "Failed to delete %s (%d)", amxc_var_key(pm_var), rv);
            goto exit;
        }
    }

exit:
    amxc_var_clean(&ret);
    amxc_var_clean(&ret_amxb_del);
    amxc_string_clean(&key_index);
}
