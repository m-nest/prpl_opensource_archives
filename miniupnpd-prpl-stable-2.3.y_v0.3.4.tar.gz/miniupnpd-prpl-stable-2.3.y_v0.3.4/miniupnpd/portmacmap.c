/****************************************************************************
**
** SPDX-License-Identifier: BSD-2-Clause-Patent
**
** SPDX-FileCopyrightText: Copyright (c) 2025 Inango
**
** Redistribution and use in source and binary forms, with or
** without modification, are permitted provided that the following
** conditions are met:
**
** 1. Redistributions of source code must retain the above copyright
** notice, this list of conditions and the following disclaimer.
**
** 2. Redistributions in binary form must reproduce the above
** copyright notice, this list of conditions and the following
** disclaimer in the documentation and/or other materials provided
** with the distribution.
**
** Subject to the terms and conditions of this license, each
** copyright holder and contributor hereby grants to those receiving
** rights under this license a perpetual, worldwide, non-exclusive,
** no-charge, royalty-free, irrevocable (except for failure to
** satisfy the conditions of this license) patent license to make,
** have made, use, offer to sell, sell, import, and otherwise
** transfer this software, where such license applies only to those
** patent claims, already acquired or hereafter acquired, licensable
** by such copyright holder or contributor that are necessarily
** infringed by:
**
** (a) their Contribution(s) (the licensed copyrights of copyright
** holders and non-copyrightable additions of contributors, in
** source or binary form) alone; or
**
** (b) combination of their Contribution(s) with the work of
** authorship to which such Contribution(s) was added by such
** copyright holder or contributor, if, at the time the Contribution
** is added, such addition causes such combination to be necessarily
** infringed. The patent license shall not apply to any other
** combinations which include the Contribution.
**
** Except as expressly stated above, no rights or licenses from any
** copyright holder or contributor is granted under this license,
** whether expressly, by implication, estoppel or otherwise.
**
** DISCLAIMER
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
** CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
** INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
** MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
** DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR
** CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
** USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
** AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
** LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
** ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
****************************************************************************/
#include "portmacmap.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

static struct port_mac_tuple* port_mac_map = NULL;

/**
 * @brief Cleans up expired mappings.
 *
 * Goes over all current mappings and cleans up expired ones.
 *
 */
static void port_mac_map_cleanup_expired()
{
	struct port_mac_tuple* pmm = port_mac_map;
	struct port_mac_tuple* tmp = NULL;
	struct port_mac_tuple* prv = NULL;
	time_t curr_time = time(NULL);

	while(pmm != NULL) {
		if(curr_time > pmm->creation_time + pmm->lifetime) {
			if(prv == NULL) {
				port_mac_map = port_mac_map->next;
				free(pmm);
				pmm = port_mac_map;
			} else {
				prv->next = pmm->next;
				free(pmm);
				pmm = prv->next;
			}
			continue;
		} else {
			prv = pmm;
			pmm = pmm->next;
		}
	}
}

/**
 * @brief Add a PORT->MAC pair to the map.
 *
 * Add a PORT->MAC pair to the map, replacing in case a pair with this PORT
 * already exists.
 *
 * @param port The key at which to insert the pair (port).
 * @param mac The MAC address to insert at the key.
 * @param lifetime The lifetime of the mapping, after which it will be deleted.
 */
void port_mac_map_add(unsigned short port, const char* mac,
                      unsigned int lifetime)
{
	struct port_mac_tuple pmt;
	struct port_mac_tuple* pmm;

	port_mac_map_cleanup_expired();

	pmt.creation_time = time(NULL);
	pmt.lifetime = lifetime;
	pmt.port = port;
	strncpy(pmt.mac, mac, MAC_ADDR_STR_LEN);
	pmt.next = NULL;

	if(port_mac_map == NULL) {
		port_mac_map = malloc(sizeof(struct port_mac_tuple));
		memcpy(port_mac_map, &pmt, sizeof(struct port_mac_tuple));
		return;
	}

	pmm = port_mac_map;
	while(pmm->next != NULL) {
		if(pmm->next->port == port) {
			pmt.next = pmm->next->next;
			memcpy(pmm->next, &pmt, sizeof(struct port_mac_tuple));
			return;
		}

		pmm = pmm->next;
	}

	pmm->next = malloc(sizeof(struct port_mac_tuple));
	memcpy(pmm->next, &pmt, sizeof(struct port_mac_tuple));
	return;
}

/**
 * @brief Delete a PORT->MAC pair from the map.
 *
 * Delete a PORT->MAC pair from the map using the PORT as the key.
 * No error will be printed in case the pair already doesn't exist.
 *
 * @param port The key of the PORT->MAC pair to delete.
 */
void port_mac_map_delete(unsigned short port)
{
	struct port_mac_tuple* pmt;
	struct port_mac_tuple* tmp;

	port_mac_map_cleanup_expired();

	if(port_mac_map == NULL) {
		return;
	}

	if(port_mac_map->port == port) {
		tmp = port_mac_map;
		port_mac_map = tmp->next;
		free(tmp);
		return;
	}

	pmt = port_mac_map;
	while(pmt->next != NULL) {
		if(pmt->next->port == port) {
			tmp = pmt->next;
			pmt->next = tmp->next;
			free(tmp);
			return;
		}

		pmt = pmt->next;
	}
}

/**
 * @brief Get MAC by PORT from the map.
 *
 * Get a MAC address previously inserted into the map using the corresponding
 * PORT. Note that mappings with expired lifetimes will not be returned and will
 * instead be cleaned up in this function. Also note that the returned string
 * must be freed by the caller.
 *
 * @param port The key by which to get the MAC address from the map.
 * @param ret_mac A buffer of at least MAC_ADDR_STR_LEN+1 for the MAC to be written to.
 */
int port_mac_map_get_active(unsigned short port, char* ret_mac)
{
	struct port_mac_tuple* pmt;

	port_mac_map_cleanup_expired();

	if(port_mac_map == NULL) {
		return -1;
	}

	pmt = port_mac_map;
	while(pmt != NULL) {
		if(pmt->port == port) {
			strncpy(ret_mac, pmt->mac, MAC_ADDR_STR_LEN+1);
			return 0;
		}

		pmt = pmt->next;
	}

	return -1;
}
