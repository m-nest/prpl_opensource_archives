/* A Bison parser, made by GNU Bison 3.8.2.  */

/* Bison implementation for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2021 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output, and Bison version.  */
#define YYBISON 30802

/* Bison version string.  */
#define YYBISON_VERSION "3.8.2"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 1

/* Push parsers.  */
#define YYPUSH 0

/* Pull parsers.  */
#define YYPULL 1

/* Substitute the type names.  */
#define YYSTYPE         REWRITE_EXPR_STYPE
#define YYLTYPE         REWRITE_EXPR_LTYPE
/* Substitute the variable and function names.  */
#define yyparse         rewrite_expr_parse
#define yylex           rewrite_expr_lex
#define yyerror         rewrite_expr_error
#define yydebug         rewrite_expr_debug
#define yynerrs         rewrite_expr_nerrs


# ifndef YY_CAST
#  ifdef __cplusplus
#   define YY_CAST(Type, Val) static_cast<Type> (Val)
#   define YY_REINTERPRET_CAST(Type, Val) reinterpret_cast<Type> (Val)
#  else
#   define YY_CAST(Type, Val) ((Type) (Val))
#   define YY_REINTERPRET_CAST(Type, Val) ((Type) (Val))
#  endif
# endif
# ifndef YY_NULLPTR
#  if defined __cplusplus
#   if 201103L <= __cplusplus
#    define YY_NULLPTR nullptr
#   else
#    define YY_NULLPTR 0
#   endif
#  else
#   define YY_NULLPTR ((void*)0)
#  endif
# endif

/* Use api.header.include to #include this header
   instead of duplicating it here.  */
#ifndef YY_REWRITE_EXPR_LIB_REWRITE_REWRITE_EXPR_GRAMMAR_H_INCLUDED
# define YY_REWRITE_EXPR_LIB_REWRITE_REWRITE_EXPR_GRAMMAR_H_INCLUDED
/* Debug traces.  */
#ifndef REWRITE_EXPR_DEBUG
# if defined YYDEBUG
#if YYDEBUG
#   define REWRITE_EXPR_DEBUG 1
#  else
#   define REWRITE_EXPR_DEBUG 0
#  endif
# else /* ! defined YYDEBUG */
#  define REWRITE_EXPR_DEBUG 0
# endif /* ! defined YYDEBUG */
#endif  /* ! defined REWRITE_EXPR_DEBUG */
#if REWRITE_EXPR_DEBUG
extern int rewrite_expr_debug;
#endif
/* "%code requires" blocks.  */
#line 25 "lib/rewrite/rewrite-expr-grammar.y"


#include "rewrite/rewrite-expr-parser.h"


#line 125 "lib/rewrite/rewrite-expr-grammar.c"

/* Token kinds.  */
#ifndef REWRITE_EXPR_TOKENTYPE
# define REWRITE_EXPR_TOKENTYPE
  enum rewrite_expr_tokentype
  {
    REWRITE_EXPR_EMPTY = -2,
    REWRITE_EXPR_EOF = 0,          /* "end of file"  */
    REWRITE_EXPR_error = 256,      /* error  */
    REWRITE_EXPR_UNDEF = 10531,    /* "invalid token"  */
    LL_CONTEXT_ROOT = 1,           /* LL_CONTEXT_ROOT  */
    LL_CONTEXT_DESTINATION = 2,    /* LL_CONTEXT_DESTINATION  */
    LL_CONTEXT_SOURCE = 3,         /* LL_CONTEXT_SOURCE  */
    LL_CONTEXT_PARSER = 4,         /* LL_CONTEXT_PARSER  */
    LL_CONTEXT_REWRITE = 5,        /* LL_CONTEXT_REWRITE  */
    LL_CONTEXT_FILTER = 6,         /* LL_CONTEXT_FILTER  */
    LL_CONTEXT_LOG = 7,            /* LL_CONTEXT_LOG  */
    LL_CONTEXT_BLOCK_DEF = 8,      /* LL_CONTEXT_BLOCK_DEF  */
    LL_CONTEXT_BLOCK_REF = 9,      /* LL_CONTEXT_BLOCK_REF  */
    LL_CONTEXT_BLOCK_CONTENT = 10, /* LL_CONTEXT_BLOCK_CONTENT  */
    LL_CONTEXT_BLOCK_ARG = 11,     /* LL_CONTEXT_BLOCK_ARG  */
    LL_CONTEXT_PRAGMA = 12,        /* LL_CONTEXT_PRAGMA  */
    LL_CONTEXT_FORMAT = 13,        /* LL_CONTEXT_FORMAT  */
    LL_CONTEXT_TEMPLATE_FUNC = 14, /* LL_CONTEXT_TEMPLATE_FUNC  */
    LL_CONTEXT_INNER_DEST = 15,    /* LL_CONTEXT_INNER_DEST  */
    LL_CONTEXT_INNER_SRC = 16,     /* LL_CONTEXT_INNER_SRC  */
    LL_CONTEXT_CLIENT_PROTO = 17,  /* LL_CONTEXT_CLIENT_PROTO  */
    LL_CONTEXT_SERVER_PROTO = 18,  /* LL_CONTEXT_SERVER_PROTO  */
    LL_CONTEXT_OPTIONS = 19,       /* LL_CONTEXT_OPTIONS  */
    LL_CONTEXT_CONFIG = 20,        /* LL_CONTEXT_CONFIG  */
    LL_CONTEXT_TEMPLATE_REF = 21,  /* LL_CONTEXT_TEMPLATE_REF  */
    LL_CONTEXT_FILTERX = 22,       /* LL_CONTEXT_FILTERX  */
    LL_CONTEXT_FILTERX_FUNC = 23,  /* LL_CONTEXT_FILTERX_FUNC  */
    LL_CONTEXT_FILTERX_ENUM = 24,  /* LL_CONTEXT_FILTERX_ENUM  */
    LL_CONTEXT_MAX = 25,           /* LL_CONTEXT_MAX  */
    KW_ASSIGN = 9000,              /* KW_ASSIGN  */
    KW_OR = 9001,                  /* KW_OR  */
    KW_AND = 9002,                 /* KW_AND  */
    KW_STR_EQ = 9003,              /* KW_STR_EQ  */
    KW_STR_NE = 9004,              /* KW_STR_NE  */
    KW_TA_EQ = 9005,               /* KW_TA_EQ  */
    KW_TA_NE = 9006,               /* KW_TA_NE  */
    KW_TAV_EQ = 9007,              /* KW_TAV_EQ  */
    KW_TAV_NE = 9008,              /* KW_TAV_NE  */
    KW_STR_LT = 9009,              /* KW_STR_LT  */
    KW_STR_LE = 9010,              /* KW_STR_LE  */
    KW_STR_GE = 9011,              /* KW_STR_GE  */
    KW_STR_GT = 9012,              /* KW_STR_GT  */
    KW_TA_LT = 9013,               /* KW_TA_LT  */
    KW_TA_LE = 9014,               /* KW_TA_LE  */
    KW_TA_GE = 9015,               /* KW_TA_GE  */
    KW_TA_GT = 9016,               /* KW_TA_GT  */
    KW_PLUS_ASSIGN = 9018,         /* KW_PLUS_ASSIGN  */
    KW_NOT = 9017,                 /* KW_NOT  */
    KW_SOURCE = 10000,             /* KW_SOURCE  */
    KW_FILTER = 10001,             /* KW_FILTER  */
    KW_PARSER = 10002,             /* KW_PARSER  */
    KW_DESTINATION = 10003,        /* KW_DESTINATION  */
    KW_LOG = 10004,                /* KW_LOG  */
    KW_OPTIONS = 10005,            /* KW_OPTIONS  */
    KW_INCLUDE = 10006,            /* KW_INCLUDE  */
    KW_BLOCK = 10007,              /* KW_BLOCK  */
    KW_JUNCTION = 10008,           /* KW_JUNCTION  */
    KW_CHANNEL = 10009,            /* KW_CHANNEL  */
    KW_IF = 10010,                 /* KW_IF  */
    KW_ELSE = 10011,               /* KW_ELSE  */
    KW_ELIF = 10012,               /* KW_ELIF  */
    KW_FILTERX = 10013,            /* KW_FILTERX  */
    KW_INTERNAL = 10020,           /* KW_INTERNAL  */
    KW_SYSLOG = 10060,             /* KW_SYSLOG  */
    KW_MARK_FREQ = 10071,          /* KW_MARK_FREQ  */
    KW_STATS_FREQ = 10072,         /* KW_STATS_FREQ  */
    KW_STATS_LEVEL = 10073,        /* KW_STATS_LEVEL  */
    KW_STATS_LIFETIME = 10074,     /* KW_STATS_LIFETIME  */
    KW_FLUSH_LINES = 10075,        /* KW_FLUSH_LINES  */
    KW_SUPPRESS = 10076,           /* KW_SUPPRESS  */
    KW_FLUSH_TIMEOUT = 10077,      /* KW_FLUSH_TIMEOUT  */
    KW_LOG_MSG_SIZE = 10078,       /* KW_LOG_MSG_SIZE  */
    KW_FILE_TEMPLATE = 10079,      /* KW_FILE_TEMPLATE  */
    KW_PROTO_TEMPLATE = 10080,     /* KW_PROTO_TEMPLATE  */
    KW_MARK_MODE = 10081,          /* KW_MARK_MODE  */
    KW_ENCODING = 10082,           /* KW_ENCODING  */
    KW_TYPE = 10083,               /* KW_TYPE  */
    KW_STATS_MAX_DYNAMIC = 10084,  /* KW_STATS_MAX_DYNAMIC  */
    KW_MIN_IW_SIZE_PER_READER = 10085, /* KW_MIN_IW_SIZE_PER_READER  */
    KW_WORKERS = 10086,            /* KW_WORKERS  */
    KW_BATCH_LINES = 10087,        /* KW_BATCH_LINES  */
    KW_BATCH_TIMEOUT = 10088,      /* KW_BATCH_TIMEOUT  */
    KW_TRIM_LARGE_MESSAGES = 10089, /* KW_TRIM_LARGE_MESSAGES  */
    KW_STATS = 10400,              /* KW_STATS  */
    KW_FREQ = 10401,               /* KW_FREQ  */
    KW_LEVEL = 10402,              /* KW_LEVEL  */
    KW_LIFETIME = 10403,           /* KW_LIFETIME  */
    KW_MAX_DYNAMIC = 10404,        /* KW_MAX_DYNAMIC  */
    KW_SYSLOG_STATS = 10405,       /* KW_SYSLOG_STATS  */
    KW_HEALTHCHECK_FREQ = 10406,   /* KW_HEALTHCHECK_FREQ  */
    KW_WORKER_PARTITION_KEY = 10407, /* KW_WORKER_PARTITION_KEY  */
    KW_CHAIN_HOSTNAMES = 10090,    /* KW_CHAIN_HOSTNAMES  */
    KW_NORMALIZE_HOSTNAMES = 10091, /* KW_NORMALIZE_HOSTNAMES  */
    KW_KEEP_HOSTNAME = 10092,      /* KW_KEEP_HOSTNAME  */
    KW_CHECK_HOSTNAME = 10093,     /* KW_CHECK_HOSTNAME  */
    KW_BAD_HOSTNAME = 10094,       /* KW_BAD_HOSTNAME  */
    KW_LOG_LEVEL = 10095,          /* KW_LOG_LEVEL  */
    KW_KEEP_TIMESTAMP = 10100,     /* KW_KEEP_TIMESTAMP  */
    KW_USE_DNS = 10110,            /* KW_USE_DNS  */
    KW_USE_FQDN = 10111,           /* KW_USE_FQDN  */
    KW_CUSTOM_DOMAIN = 10112,      /* KW_CUSTOM_DOMAIN  */
    KW_DNS_CACHE = 10120,          /* KW_DNS_CACHE  */
    KW_DNS_CACHE_SIZE = 10121,     /* KW_DNS_CACHE_SIZE  */
    KW_DNS_CACHE_EXPIRE = 10130,   /* KW_DNS_CACHE_EXPIRE  */
    KW_DNS_CACHE_EXPIRE_FAILED = 10131, /* KW_DNS_CACHE_EXPIRE_FAILED  */
    KW_DNS_CACHE_HOSTS = 10132,    /* KW_DNS_CACHE_HOSTS  */
    KW_PERSIST_ONLY = 10140,       /* KW_PERSIST_ONLY  */
    KW_USE_RCPTID = 10141,         /* KW_USE_RCPTID  */
    KW_USE_UNIQID = 10142,         /* KW_USE_UNIQID  */
    KW_TZ_CONVERT = 10150,         /* KW_TZ_CONVERT  */
    KW_TS_FORMAT = 10151,          /* KW_TS_FORMAT  */
    KW_FRAC_DIGITS = 10152,        /* KW_FRAC_DIGITS  */
    KW_LOG_FIFO_SIZE = 10160,      /* KW_LOG_FIFO_SIZE  */
    KW_LOG_FETCH_LIMIT = 10162,    /* KW_LOG_FETCH_LIMIT  */
    KW_LOG_IW_SIZE = 10163,        /* KW_LOG_IW_SIZE  */
    KW_LOG_PREFIX = 10164,         /* KW_LOG_PREFIX  */
    KW_PROGRAM_OVERRIDE = 10165,   /* KW_PROGRAM_OVERRIDE  */
    KW_HOST_OVERRIDE = 10166,      /* KW_HOST_OVERRIDE  */
    KW_THROTTLE = 10170,           /* KW_THROTTLE  */
    KW_THREADED = 10171,           /* KW_THREADED  */
    KW_PASS_UNIX_CREDENTIALS = 10180, /* KW_PASS_UNIX_CREDENTIALS  */
    KW_PERSIST_NAME = 10181,       /* KW_PERSIST_NAME  */
    KW_READ_OLD_RECORDS = 10182,   /* KW_READ_OLD_RECORDS  */
    KW_USE_SYSLOGNG_PID = 10183,   /* KW_USE_SYSLOGNG_PID  */
    KW_FLAGS = 10190,              /* KW_FLAGS  */
    KW_PAD_SIZE = 10200,           /* KW_PAD_SIZE  */
    KW_TIME_ZONE = 10201,          /* KW_TIME_ZONE  */
    KW_RECV_TIME_ZONE = 10202,     /* KW_RECV_TIME_ZONE  */
    KW_SEND_TIME_ZONE = 10203,     /* KW_SEND_TIME_ZONE  */
    KW_LOCAL_TIME_ZONE = 10204,    /* KW_LOCAL_TIME_ZONE  */
    KW_FORMAT = 10205,             /* KW_FORMAT  */
    KW_MULTI_LINE_MODE = 10206,    /* KW_MULTI_LINE_MODE  */
    KW_MULTI_LINE_PREFIX = 10207,  /* KW_MULTI_LINE_PREFIX  */
    KW_MULTI_LINE_GARBAGE = 10208, /* KW_MULTI_LINE_GARBAGE  */
    KW_TRUNCATE_SIZE = 10209,      /* KW_TRUNCATE_SIZE  */
    KW_TIME_REOPEN = 10210,        /* KW_TIME_REOPEN  */
    KW_TIME_REAP = 10211,          /* KW_TIME_REAP  */
    KW_TIME_SLEEP = 10212,         /* KW_TIME_SLEEP  */
    KW_PARTITIONS = 10213,         /* KW_PARTITIONS  */
    KW_PARTITION_KEY = 10214,      /* KW_PARTITION_KEY  */
    KW_PARALLELIZE = 10215,        /* KW_PARALLELIZE  */
    KW_TMPL_ESCAPE = 10220,        /* KW_TMPL_ESCAPE  */
    KW_OPTIONAL = 10230,           /* KW_OPTIONAL  */
    KW_CREATE_DIRS = 10240,        /* KW_CREATE_DIRS  */
    KW_OWNER = 10250,              /* KW_OWNER  */
    KW_GROUP = 10251,              /* KW_GROUP  */
    KW_PERM = 10252,               /* KW_PERM  */
    KW_DIR_OWNER = 10260,          /* KW_DIR_OWNER  */
    KW_DIR_GROUP = 10261,          /* KW_DIR_GROUP  */
    KW_DIR_PERM = 10262,           /* KW_DIR_PERM  */
    KW_TEMPLATE = 10270,           /* KW_TEMPLATE  */
    KW_TEMPLATE_ESCAPE = 10271,    /* KW_TEMPLATE_ESCAPE  */
    KW_TEMPLATE_FUNCTION = 10272,  /* KW_TEMPLATE_FUNCTION  */
    KW_DEFAULT_FACILITY = 10300,   /* KW_DEFAULT_FACILITY  */
    KW_DEFAULT_SEVERITY = 10301,   /* KW_DEFAULT_SEVERITY  */
    KW_SDATA_PREFIX = 10302,       /* KW_SDATA_PREFIX  */
    KW_PORT = 10323,               /* KW_PORT  */
    KW_USE_TIME_RECVD = 10340,     /* KW_USE_TIME_RECVD  */
    KW_FACILITY = 10350,           /* KW_FACILITY  */
    KW_SEVERITY = 10351,           /* KW_SEVERITY  */
    KW_HOST = 10352,               /* KW_HOST  */
    KW_MATCH = 10353,              /* KW_MATCH  */
    KW_MESSAGE = 10354,            /* KW_MESSAGE  */
    KW_NETMASK = 10355,            /* KW_NETMASK  */
    KW_TAGS = 10356,               /* KW_TAGS  */
    KW_NETMASK6 = 10357,           /* KW_NETMASK6  */
    KW_REWRITE = 10370,            /* KW_REWRITE  */
    KW_CONDITION = 10371,          /* KW_CONDITION  */
    KW_VALUE = 10372,              /* KW_VALUE  */
    KW_YES = 10380,                /* KW_YES  */
    KW_NO = 10381,                 /* KW_NO  */
    KW_AUTO = 10382,               /* KW_AUTO  */
    KW_IFDEF = 10410,              /* KW_IFDEF  */
    KW_ENDIF = 10411,              /* KW_ENDIF  */
    LL_DOTDOT = 10420,             /* LL_DOTDOT  */
    LL_DOTDOTDOT = 10421,          /* LL_DOTDOTDOT  */
    LL_PRAGMA = 10422,             /* LL_PRAGMA  */
    LL_EOL = 10423,                /* LL_EOL  */
    LL_ERROR = 10424,              /* LL_ERROR  */
    LL_ARROW = 10425,              /* LL_ARROW  */
    LL_IDENTIFIER = 10430,         /* LL_IDENTIFIER  */
    LL_NUMBER = 10431,             /* LL_NUMBER  */
    LL_FLOAT = 10432,              /* LL_FLOAT  */
    LL_STRING = 10433,             /* LL_STRING  */
    LL_TOKEN = 10434,              /* LL_TOKEN  */
    LL_BLOCK = 10435,              /* LL_BLOCK  */
    LL_PLUGIN = 10436,             /* LL_PLUGIN  */
    LL_TEMPLATE_REF = 10437,       /* LL_TEMPLATE_REF  */
    LL_MESSAGE_REF = 10438,        /* LL_MESSAGE_REF  */
    KW_VALUE_PAIRS = 10500,        /* KW_VALUE_PAIRS  */
    KW_EXCLUDE = 10502,            /* KW_EXCLUDE  */
    KW_PAIR = 10503,               /* KW_PAIR  */
    KW_KEY = 10504,                /* KW_KEY  */
    KW_SCOPE = 10505,              /* KW_SCOPE  */
    KW_SHIFT = 10506,              /* KW_SHIFT  */
    KW_SHIFT_LEVELS = 10507,       /* KW_SHIFT_LEVELS  */
    KW_REKEY = 10508,              /* KW_REKEY  */
    KW_ADD_PREFIX = 10509,         /* KW_ADD_PREFIX  */
    KW_REPLACE_PREFIX = 10510,     /* KW_REPLACE_PREFIX  */
    KW_CAST = 10511,               /* KW_CAST  */
    KW_UPPER = 10512,              /* KW_UPPER  */
    KW_LOWER = 10513,              /* KW_LOWER  */
    KW_INCLUDE_BYTES = 10514,      /* KW_INCLUDE_BYTES  */
    KW_ON_ERROR = 10520,           /* KW_ON_ERROR  */
    KW_RETRIES = 10521,            /* KW_RETRIES  */
    KW_FETCH_NO_DATA_DELAY = 10522, /* KW_FETCH_NO_DATA_DELAY  */
    KW_LABELS = 10530,             /* KW_LABELS  */
    KW_SET_TAG = 10532,            /* KW_SET_TAG  */
    KW_CLEAR_TAG = 10533,          /* KW_CLEAR_TAG  */
    KW_GROUP_SET = 10534,          /* KW_GROUP_SET  */
    KW_GROUP_UNSET = 10535,        /* KW_GROUP_UNSET  */
    KW_SET = 10536,                /* KW_SET  */
    KW_UNSET = 10537,              /* KW_UNSET  */
    KW_RENAME = 10538,             /* KW_RENAME  */
    KW_SUBST = 10539,              /* KW_SUBST  */
    KW_VALUES = 10540,             /* KW_VALUES  */
    KW_SET_SEVERITY = 10541,       /* KW_SET_SEVERITY  */
    KW_SET_FACILITY = 10542,       /* KW_SET_FACILITY  */
    KW_SET_PRI = 10543,            /* KW_SET_PRI  */
    KW_SET_MATCHES = 10544,        /* KW_SET_MATCHES  */
    KW_UNSET_MATCHES = 10545       /* KW_UNSET_MATCHES  */
  };
  typedef enum rewrite_expr_tokentype rewrite_expr_token_kind_t;
#endif
/* Token kinds.  */
#define REWRITE_EXPR_EMPTY -2
#define REWRITE_EXPR_EOF 0
#define REWRITE_EXPR_error 256
#define REWRITE_EXPR_UNDEF 10531
#define LL_CONTEXT_ROOT 1
#define LL_CONTEXT_DESTINATION 2
#define LL_CONTEXT_SOURCE 3
#define LL_CONTEXT_PARSER 4
#define LL_CONTEXT_REWRITE 5
#define LL_CONTEXT_FILTER 6
#define LL_CONTEXT_LOG 7
#define LL_CONTEXT_BLOCK_DEF 8
#define LL_CONTEXT_BLOCK_REF 9
#define LL_CONTEXT_BLOCK_CONTENT 10
#define LL_CONTEXT_BLOCK_ARG 11
#define LL_CONTEXT_PRAGMA 12
#define LL_CONTEXT_FORMAT 13
#define LL_CONTEXT_TEMPLATE_FUNC 14
#define LL_CONTEXT_INNER_DEST 15
#define LL_CONTEXT_INNER_SRC 16
#define LL_CONTEXT_CLIENT_PROTO 17
#define LL_CONTEXT_SERVER_PROTO 18
#define LL_CONTEXT_OPTIONS 19
#define LL_CONTEXT_CONFIG 20
#define LL_CONTEXT_TEMPLATE_REF 21
#define LL_CONTEXT_FILTERX 22
#define LL_CONTEXT_FILTERX_FUNC 23
#define LL_CONTEXT_FILTERX_ENUM 24
#define LL_CONTEXT_MAX 25
#define KW_ASSIGN 9000
#define KW_OR 9001
#define KW_AND 9002
#define KW_STR_EQ 9003
#define KW_STR_NE 9004
#define KW_TA_EQ 9005
#define KW_TA_NE 9006
#define KW_TAV_EQ 9007
#define KW_TAV_NE 9008
#define KW_STR_LT 9009
#define KW_STR_LE 9010
#define KW_STR_GE 9011
#define KW_STR_GT 9012
#define KW_TA_LT 9013
#define KW_TA_LE 9014
#define KW_TA_GE 9015
#define KW_TA_GT 9016
#define KW_PLUS_ASSIGN 9018
#define KW_NOT 9017
#define KW_SOURCE 10000
#define KW_FILTER 10001
#define KW_PARSER 10002
#define KW_DESTINATION 10003
#define KW_LOG 10004
#define KW_OPTIONS 10005
#define KW_INCLUDE 10006
#define KW_BLOCK 10007
#define KW_JUNCTION 10008
#define KW_CHANNEL 10009
#define KW_IF 10010
#define KW_ELSE 10011
#define KW_ELIF 10012
#define KW_FILTERX 10013
#define KW_INTERNAL 10020
#define KW_SYSLOG 10060
#define KW_MARK_FREQ 10071
#define KW_STATS_FREQ 10072
#define KW_STATS_LEVEL 10073
#define KW_STATS_LIFETIME 10074
#define KW_FLUSH_LINES 10075
#define KW_SUPPRESS 10076
#define KW_FLUSH_TIMEOUT 10077
#define KW_LOG_MSG_SIZE 10078
#define KW_FILE_TEMPLATE 10079
#define KW_PROTO_TEMPLATE 10080
#define KW_MARK_MODE 10081
#define KW_ENCODING 10082
#define KW_TYPE 10083
#define KW_STATS_MAX_DYNAMIC 10084
#define KW_MIN_IW_SIZE_PER_READER 10085
#define KW_WORKERS 10086
#define KW_BATCH_LINES 10087
#define KW_BATCH_TIMEOUT 10088
#define KW_TRIM_LARGE_MESSAGES 10089
#define KW_STATS 10400
#define KW_FREQ 10401
#define KW_LEVEL 10402
#define KW_LIFETIME 10403
#define KW_MAX_DYNAMIC 10404
#define KW_SYSLOG_STATS 10405
#define KW_HEALTHCHECK_FREQ 10406
#define KW_WORKER_PARTITION_KEY 10407
#define KW_CHAIN_HOSTNAMES 10090
#define KW_NORMALIZE_HOSTNAMES 10091
#define KW_KEEP_HOSTNAME 10092
#define KW_CHECK_HOSTNAME 10093
#define KW_BAD_HOSTNAME 10094
#define KW_LOG_LEVEL 10095
#define KW_KEEP_TIMESTAMP 10100
#define KW_USE_DNS 10110
#define KW_USE_FQDN 10111
#define KW_CUSTOM_DOMAIN 10112
#define KW_DNS_CACHE 10120
#define KW_DNS_CACHE_SIZE 10121
#define KW_DNS_CACHE_EXPIRE 10130
#define KW_DNS_CACHE_EXPIRE_FAILED 10131
#define KW_DNS_CACHE_HOSTS 10132
#define KW_PERSIST_ONLY 10140
#define KW_USE_RCPTID 10141
#define KW_USE_UNIQID 10142
#define KW_TZ_CONVERT 10150
#define KW_TS_FORMAT 10151
#define KW_FRAC_DIGITS 10152
#define KW_LOG_FIFO_SIZE 10160
#define KW_LOG_FETCH_LIMIT 10162
#define KW_LOG_IW_SIZE 10163
#define KW_LOG_PREFIX 10164
#define KW_PROGRAM_OVERRIDE 10165
#define KW_HOST_OVERRIDE 10166
#define KW_THROTTLE 10170
#define KW_THREADED 10171
#define KW_PASS_UNIX_CREDENTIALS 10180
#define KW_PERSIST_NAME 10181
#define KW_READ_OLD_RECORDS 10182
#define KW_USE_SYSLOGNG_PID 10183
#define KW_FLAGS 10190
#define KW_PAD_SIZE 10200
#define KW_TIME_ZONE 10201
#define KW_RECV_TIME_ZONE 10202
#define KW_SEND_TIME_ZONE 10203
#define KW_LOCAL_TIME_ZONE 10204
#define KW_FORMAT 10205
#define KW_MULTI_LINE_MODE 10206
#define KW_MULTI_LINE_PREFIX 10207
#define KW_MULTI_LINE_GARBAGE 10208
#define KW_TRUNCATE_SIZE 10209
#define KW_TIME_REOPEN 10210
#define KW_TIME_REAP 10211
#define KW_TIME_SLEEP 10212
#define KW_PARTITIONS 10213
#define KW_PARTITION_KEY 10214
#define KW_PARALLELIZE 10215
#define KW_TMPL_ESCAPE 10220
#define KW_OPTIONAL 10230
#define KW_CREATE_DIRS 10240
#define KW_OWNER 10250
#define KW_GROUP 10251
#define KW_PERM 10252
#define KW_DIR_OWNER 10260
#define KW_DIR_GROUP 10261
#define KW_DIR_PERM 10262
#define KW_TEMPLATE 10270
#define KW_TEMPLATE_ESCAPE 10271
#define KW_TEMPLATE_FUNCTION 10272
#define KW_DEFAULT_FACILITY 10300
#define KW_DEFAULT_SEVERITY 10301
#define KW_SDATA_PREFIX 10302
#define KW_PORT 10323
#define KW_USE_TIME_RECVD 10340
#define KW_FACILITY 10350
#define KW_SEVERITY 10351
#define KW_HOST 10352
#define KW_MATCH 10353
#define KW_MESSAGE 10354
#define KW_NETMASK 10355
#define KW_TAGS 10356
#define KW_NETMASK6 10357
#define KW_REWRITE 10370
#define KW_CONDITION 10371
#define KW_VALUE 10372
#define KW_YES 10380
#define KW_NO 10381
#define KW_AUTO 10382
#define KW_IFDEF 10410
#define KW_ENDIF 10411
#define LL_DOTDOT 10420
#define LL_DOTDOTDOT 10421
#define LL_PRAGMA 10422
#define LL_EOL 10423
#define LL_ERROR 10424
#define LL_ARROW 10425
#define LL_IDENTIFIER 10430
#define LL_NUMBER 10431
#define LL_FLOAT 10432
#define LL_STRING 10433
#define LL_TOKEN 10434
#define LL_BLOCK 10435
#define LL_PLUGIN 10436
#define LL_TEMPLATE_REF 10437
#define LL_MESSAGE_REF 10438
#define KW_VALUE_PAIRS 10500
#define KW_EXCLUDE 10502
#define KW_PAIR 10503
#define KW_KEY 10504
#define KW_SCOPE 10505
#define KW_SHIFT 10506
#define KW_SHIFT_LEVELS 10507
#define KW_REKEY 10508
#define KW_ADD_PREFIX 10509
#define KW_REPLACE_PREFIX 10510
#define KW_CAST 10511
#define KW_UPPER 10512
#define KW_LOWER 10513
#define KW_INCLUDE_BYTES 10514
#define KW_ON_ERROR 10520
#define KW_RETRIES 10521
#define KW_FETCH_NO_DATA_DELAY 10522
#define KW_LABELS 10530
#define KW_SET_TAG 10532
#define KW_CLEAR_TAG 10533
#define KW_GROUP_SET 10534
#define KW_GROUP_UNSET 10535
#define KW_SET 10536
#define KW_UNSET 10537
#define KW_RENAME 10538
#define KW_SUBST 10539
#define KW_VALUES 10540
#define KW_SET_SEVERITY 10541
#define KW_SET_FACILITY 10542
#define KW_SET_PRI 10543
#define KW_SET_MATCHES 10544
#define KW_UNSET_MATCHES 10545

/* Value type.  */
#if ! defined REWRITE_EXPR_STYPE && ! defined REWRITE_EXPR_STYPE_IS_DECLARED
typedef CFG_STYPE REWRITE_EXPR_STYPE;
# define REWRITE_EXPR_STYPE_IS_TRIVIAL 1
# define REWRITE_EXPR_STYPE_IS_DECLARED 1
#endif

/* Location type.  */
typedef CFG_LTYPE REWRITE_EXPR_LTYPE;




int rewrite_expr_parse (CfgLexer *lexer, LogExprNode **result, gpointer arg);


#endif /* !YY_REWRITE_EXPR_LIB_REWRITE_REWRITE_EXPR_GRAMMAR_H_INCLUDED  */
/* Symbol kind.  */
enum yysymbol_kind_t
{
  YYSYMBOL_YYEMPTY = -2,
  YYSYMBOL_YYEOF = 0,                      /* "end of file"  */
  YYSYMBOL_YYerror = 1,                    /* error  */
  YYSYMBOL_YYUNDEF = 2,                    /* "invalid token"  */
  YYSYMBOL_LL_CONTEXT_ROOT = 3,            /* LL_CONTEXT_ROOT  */
  YYSYMBOL_LL_CONTEXT_DESTINATION = 4,     /* LL_CONTEXT_DESTINATION  */
  YYSYMBOL_LL_CONTEXT_SOURCE = 5,          /* LL_CONTEXT_SOURCE  */
  YYSYMBOL_LL_CONTEXT_PARSER = 6,          /* LL_CONTEXT_PARSER  */
  YYSYMBOL_LL_CONTEXT_REWRITE = 7,         /* LL_CONTEXT_REWRITE  */
  YYSYMBOL_LL_CONTEXT_FILTER = 8,          /* LL_CONTEXT_FILTER  */
  YYSYMBOL_LL_CONTEXT_LOG = 9,             /* LL_CONTEXT_LOG  */
  YYSYMBOL_LL_CONTEXT_BLOCK_DEF = 10,      /* LL_CONTEXT_BLOCK_DEF  */
  YYSYMBOL_LL_CONTEXT_BLOCK_REF = 11,      /* LL_CONTEXT_BLOCK_REF  */
  YYSYMBOL_LL_CONTEXT_BLOCK_CONTENT = 12,  /* LL_CONTEXT_BLOCK_CONTENT  */
  YYSYMBOL_LL_CONTEXT_BLOCK_ARG = 13,      /* LL_CONTEXT_BLOCK_ARG  */
  YYSYMBOL_LL_CONTEXT_PRAGMA = 14,         /* LL_CONTEXT_PRAGMA  */
  YYSYMBOL_LL_CONTEXT_FORMAT = 15,         /* LL_CONTEXT_FORMAT  */
  YYSYMBOL_LL_CONTEXT_TEMPLATE_FUNC = 16,  /* LL_CONTEXT_TEMPLATE_FUNC  */
  YYSYMBOL_LL_CONTEXT_INNER_DEST = 17,     /* LL_CONTEXT_INNER_DEST  */
  YYSYMBOL_LL_CONTEXT_INNER_SRC = 18,      /* LL_CONTEXT_INNER_SRC  */
  YYSYMBOL_LL_CONTEXT_CLIENT_PROTO = 19,   /* LL_CONTEXT_CLIENT_PROTO  */
  YYSYMBOL_LL_CONTEXT_SERVER_PROTO = 20,   /* LL_CONTEXT_SERVER_PROTO  */
  YYSYMBOL_LL_CONTEXT_OPTIONS = 21,        /* LL_CONTEXT_OPTIONS  */
  YYSYMBOL_LL_CONTEXT_CONFIG = 22,         /* LL_CONTEXT_CONFIG  */
  YYSYMBOL_LL_CONTEXT_TEMPLATE_REF = 23,   /* LL_CONTEXT_TEMPLATE_REF  */
  YYSYMBOL_LL_CONTEXT_FILTERX = 24,        /* LL_CONTEXT_FILTERX  */
  YYSYMBOL_LL_CONTEXT_FILTERX_FUNC = 25,   /* LL_CONTEXT_FILTERX_FUNC  */
  YYSYMBOL_LL_CONTEXT_FILTERX_ENUM = 26,   /* LL_CONTEXT_FILTERX_ENUM  */
  YYSYMBOL_LL_CONTEXT_MAX = 27,            /* LL_CONTEXT_MAX  */
  YYSYMBOL_KW_ASSIGN = 28,                 /* KW_ASSIGN  */
  YYSYMBOL_KW_OR = 29,                     /* KW_OR  */
  YYSYMBOL_KW_AND = 30,                    /* KW_AND  */
  YYSYMBOL_KW_STR_EQ = 31,                 /* KW_STR_EQ  */
  YYSYMBOL_KW_STR_NE = 32,                 /* KW_STR_NE  */
  YYSYMBOL_KW_TA_EQ = 33,                  /* KW_TA_EQ  */
  YYSYMBOL_KW_TA_NE = 34,                  /* KW_TA_NE  */
  YYSYMBOL_KW_TAV_EQ = 35,                 /* KW_TAV_EQ  */
  YYSYMBOL_KW_TAV_NE = 36,                 /* KW_TAV_NE  */
  YYSYMBOL_KW_STR_LT = 37,                 /* KW_STR_LT  */
  YYSYMBOL_KW_STR_LE = 38,                 /* KW_STR_LE  */
  YYSYMBOL_KW_STR_GE = 39,                 /* KW_STR_GE  */
  YYSYMBOL_KW_STR_GT = 40,                 /* KW_STR_GT  */
  YYSYMBOL_KW_TA_LT = 41,                  /* KW_TA_LT  */
  YYSYMBOL_KW_TA_LE = 42,                  /* KW_TA_LE  */
  YYSYMBOL_KW_TA_GE = 43,                  /* KW_TA_GE  */
  YYSYMBOL_KW_TA_GT = 44,                  /* KW_TA_GT  */
  YYSYMBOL_KW_PLUS_ASSIGN = 45,            /* KW_PLUS_ASSIGN  */
  YYSYMBOL_46_ = 46,                       /* '+'  */
  YYSYMBOL_47_ = 47,                       /* '-'  */
  YYSYMBOL_48_ = 48,                       /* '*'  */
  YYSYMBOL_49_ = 49,                       /* '/'  */
  YYSYMBOL_50_ = 50,                       /* '.'  */
  YYSYMBOL_51_ = 51,                       /* '['  */
  YYSYMBOL_52_ = 52,                       /* ']'  */
  YYSYMBOL_KW_NOT = 53,                    /* KW_NOT  */
  YYSYMBOL_KW_SOURCE = 54,                 /* KW_SOURCE  */
  YYSYMBOL_KW_FILTER = 55,                 /* KW_FILTER  */
  YYSYMBOL_KW_PARSER = 56,                 /* KW_PARSER  */
  YYSYMBOL_KW_DESTINATION = 57,            /* KW_DESTINATION  */
  YYSYMBOL_KW_LOG = 58,                    /* KW_LOG  */
  YYSYMBOL_KW_OPTIONS = 59,                /* KW_OPTIONS  */
  YYSYMBOL_KW_INCLUDE = 60,                /* KW_INCLUDE  */
  YYSYMBOL_KW_BLOCK = 61,                  /* KW_BLOCK  */
  YYSYMBOL_KW_JUNCTION = 62,               /* KW_JUNCTION  */
  YYSYMBOL_KW_CHANNEL = 63,                /* KW_CHANNEL  */
  YYSYMBOL_KW_IF = 64,                     /* KW_IF  */
  YYSYMBOL_KW_ELSE = 65,                   /* KW_ELSE  */
  YYSYMBOL_KW_ELIF = 66,                   /* KW_ELIF  */
  YYSYMBOL_KW_FILTERX = 67,                /* KW_FILTERX  */
  YYSYMBOL_KW_INTERNAL = 68,               /* KW_INTERNAL  */
  YYSYMBOL_KW_SYSLOG = 69,                 /* KW_SYSLOG  */
  YYSYMBOL_KW_MARK_FREQ = 70,              /* KW_MARK_FREQ  */
  YYSYMBOL_KW_STATS_FREQ = 71,             /* KW_STATS_FREQ  */
  YYSYMBOL_KW_STATS_LEVEL = 72,            /* KW_STATS_LEVEL  */
  YYSYMBOL_KW_STATS_LIFETIME = 73,         /* KW_STATS_LIFETIME  */
  YYSYMBOL_KW_FLUSH_LINES = 74,            /* KW_FLUSH_LINES  */
  YYSYMBOL_KW_SUPPRESS = 75,               /* KW_SUPPRESS  */
  YYSYMBOL_KW_FLUSH_TIMEOUT = 76,          /* KW_FLUSH_TIMEOUT  */
  YYSYMBOL_KW_LOG_MSG_SIZE = 77,           /* KW_LOG_MSG_SIZE  */
  YYSYMBOL_KW_FILE_TEMPLATE = 78,          /* KW_FILE_TEMPLATE  */
  YYSYMBOL_KW_PROTO_TEMPLATE = 79,         /* KW_PROTO_TEMPLATE  */
  YYSYMBOL_KW_MARK_MODE = 80,              /* KW_MARK_MODE  */
  YYSYMBOL_KW_ENCODING = 81,               /* KW_ENCODING  */
  YYSYMBOL_KW_TYPE = 82,                   /* KW_TYPE  */
  YYSYMBOL_KW_STATS_MAX_DYNAMIC = 83,      /* KW_STATS_MAX_DYNAMIC  */
  YYSYMBOL_KW_MIN_IW_SIZE_PER_READER = 84, /* KW_MIN_IW_SIZE_PER_READER  */
  YYSYMBOL_KW_WORKERS = 85,                /* KW_WORKERS  */
  YYSYMBOL_KW_BATCH_LINES = 86,            /* KW_BATCH_LINES  */
  YYSYMBOL_KW_BATCH_TIMEOUT = 87,          /* KW_BATCH_TIMEOUT  */
  YYSYMBOL_KW_TRIM_LARGE_MESSAGES = 88,    /* KW_TRIM_LARGE_MESSAGES  */
  YYSYMBOL_KW_STATS = 89,                  /* KW_STATS  */
  YYSYMBOL_KW_FREQ = 90,                   /* KW_FREQ  */
  YYSYMBOL_KW_LEVEL = 91,                  /* KW_LEVEL  */
  YYSYMBOL_KW_LIFETIME = 92,               /* KW_LIFETIME  */
  YYSYMBOL_KW_MAX_DYNAMIC = 93,            /* KW_MAX_DYNAMIC  */
  YYSYMBOL_KW_SYSLOG_STATS = 94,           /* KW_SYSLOG_STATS  */
  YYSYMBOL_KW_HEALTHCHECK_FREQ = 95,       /* KW_HEALTHCHECK_FREQ  */
  YYSYMBOL_KW_WORKER_PARTITION_KEY = 96,   /* KW_WORKER_PARTITION_KEY  */
  YYSYMBOL_KW_CHAIN_HOSTNAMES = 97,        /* KW_CHAIN_HOSTNAMES  */
  YYSYMBOL_KW_NORMALIZE_HOSTNAMES = 98,    /* KW_NORMALIZE_HOSTNAMES  */
  YYSYMBOL_KW_KEEP_HOSTNAME = 99,          /* KW_KEEP_HOSTNAME  */
  YYSYMBOL_KW_CHECK_HOSTNAME = 100,        /* KW_CHECK_HOSTNAME  */
  YYSYMBOL_KW_BAD_HOSTNAME = 101,          /* KW_BAD_HOSTNAME  */
  YYSYMBOL_KW_LOG_LEVEL = 102,             /* KW_LOG_LEVEL  */
  YYSYMBOL_KW_KEEP_TIMESTAMP = 103,        /* KW_KEEP_TIMESTAMP  */
  YYSYMBOL_KW_USE_DNS = 104,               /* KW_USE_DNS  */
  YYSYMBOL_KW_USE_FQDN = 105,              /* KW_USE_FQDN  */
  YYSYMBOL_KW_CUSTOM_DOMAIN = 106,         /* KW_CUSTOM_DOMAIN  */
  YYSYMBOL_KW_DNS_CACHE = 107,             /* KW_DNS_CACHE  */
  YYSYMBOL_KW_DNS_CACHE_SIZE = 108,        /* KW_DNS_CACHE_SIZE  */
  YYSYMBOL_KW_DNS_CACHE_EXPIRE = 109,      /* KW_DNS_CACHE_EXPIRE  */
  YYSYMBOL_KW_DNS_CACHE_EXPIRE_FAILED = 110, /* KW_DNS_CACHE_EXPIRE_FAILED  */
  YYSYMBOL_KW_DNS_CACHE_HOSTS = 111,       /* KW_DNS_CACHE_HOSTS  */
  YYSYMBOL_KW_PERSIST_ONLY = 112,          /* KW_PERSIST_ONLY  */
  YYSYMBOL_KW_USE_RCPTID = 113,            /* KW_USE_RCPTID  */
  YYSYMBOL_KW_USE_UNIQID = 114,            /* KW_USE_UNIQID  */
  YYSYMBOL_KW_TZ_CONVERT = 115,            /* KW_TZ_CONVERT  */
  YYSYMBOL_KW_TS_FORMAT = 116,             /* KW_TS_FORMAT  */
  YYSYMBOL_KW_FRAC_DIGITS = 117,           /* KW_FRAC_DIGITS  */
  YYSYMBOL_KW_LOG_FIFO_SIZE = 118,         /* KW_LOG_FIFO_SIZE  */
  YYSYMBOL_KW_LOG_FETCH_LIMIT = 119,       /* KW_LOG_FETCH_LIMIT  */
  YYSYMBOL_KW_LOG_IW_SIZE = 120,           /* KW_LOG_IW_SIZE  */
  YYSYMBOL_KW_LOG_PREFIX = 121,            /* KW_LOG_PREFIX  */
  YYSYMBOL_KW_PROGRAM_OVERRIDE = 122,      /* KW_PROGRAM_OVERRIDE  */
  YYSYMBOL_KW_HOST_OVERRIDE = 123,         /* KW_HOST_OVERRIDE  */
  YYSYMBOL_KW_THROTTLE = 124,              /* KW_THROTTLE  */
  YYSYMBOL_KW_THREADED = 125,              /* KW_THREADED  */
  YYSYMBOL_KW_PASS_UNIX_CREDENTIALS = 126, /* KW_PASS_UNIX_CREDENTIALS  */
  YYSYMBOL_KW_PERSIST_NAME = 127,          /* KW_PERSIST_NAME  */
  YYSYMBOL_KW_READ_OLD_RECORDS = 128,      /* KW_READ_OLD_RECORDS  */
  YYSYMBOL_KW_USE_SYSLOGNG_PID = 129,      /* KW_USE_SYSLOGNG_PID  */
  YYSYMBOL_KW_FLAGS = 130,                 /* KW_FLAGS  */
  YYSYMBOL_KW_PAD_SIZE = 131,              /* KW_PAD_SIZE  */
  YYSYMBOL_KW_TIME_ZONE = 132,             /* KW_TIME_ZONE  */
  YYSYMBOL_KW_RECV_TIME_ZONE = 133,        /* KW_RECV_TIME_ZONE  */
  YYSYMBOL_KW_SEND_TIME_ZONE = 134,        /* KW_SEND_TIME_ZONE  */
  YYSYMBOL_KW_LOCAL_TIME_ZONE = 135,       /* KW_LOCAL_TIME_ZONE  */
  YYSYMBOL_KW_FORMAT = 136,                /* KW_FORMAT  */
  YYSYMBOL_KW_MULTI_LINE_MODE = 137,       /* KW_MULTI_LINE_MODE  */
  YYSYMBOL_KW_MULTI_LINE_PREFIX = 138,     /* KW_MULTI_LINE_PREFIX  */
  YYSYMBOL_KW_MULTI_LINE_GARBAGE = 139,    /* KW_MULTI_LINE_GARBAGE  */
  YYSYMBOL_KW_TRUNCATE_SIZE = 140,         /* KW_TRUNCATE_SIZE  */
  YYSYMBOL_KW_TIME_REOPEN = 141,           /* KW_TIME_REOPEN  */
  YYSYMBOL_KW_TIME_REAP = 142,             /* KW_TIME_REAP  */
  YYSYMBOL_KW_TIME_SLEEP = 143,            /* KW_TIME_SLEEP  */
  YYSYMBOL_KW_PARTITIONS = 144,            /* KW_PARTITIONS  */
  YYSYMBOL_KW_PARTITION_KEY = 145,         /* KW_PARTITION_KEY  */
  YYSYMBOL_KW_PARALLELIZE = 146,           /* KW_PARALLELIZE  */
  YYSYMBOL_KW_TMPL_ESCAPE = 147,           /* KW_TMPL_ESCAPE  */
  YYSYMBOL_KW_OPTIONAL = 148,              /* KW_OPTIONAL  */
  YYSYMBOL_KW_CREATE_DIRS = 149,           /* KW_CREATE_DIRS  */
  YYSYMBOL_KW_OWNER = 150,                 /* KW_OWNER  */
  YYSYMBOL_KW_GROUP = 151,                 /* KW_GROUP  */
  YYSYMBOL_KW_PERM = 152,                  /* KW_PERM  */
  YYSYMBOL_KW_DIR_OWNER = 153,             /* KW_DIR_OWNER  */
  YYSYMBOL_KW_DIR_GROUP = 154,             /* KW_DIR_GROUP  */
  YYSYMBOL_KW_DIR_PERM = 155,              /* KW_DIR_PERM  */
  YYSYMBOL_KW_TEMPLATE = 156,              /* KW_TEMPLATE  */
  YYSYMBOL_KW_TEMPLATE_ESCAPE = 157,       /* KW_TEMPLATE_ESCAPE  */
  YYSYMBOL_KW_TEMPLATE_FUNCTION = 158,     /* KW_TEMPLATE_FUNCTION  */
  YYSYMBOL_KW_DEFAULT_FACILITY = 159,      /* KW_DEFAULT_FACILITY  */
  YYSYMBOL_KW_DEFAULT_SEVERITY = 160,      /* KW_DEFAULT_SEVERITY  */
  YYSYMBOL_KW_SDATA_PREFIX = 161,          /* KW_SDATA_PREFIX  */
  YYSYMBOL_KW_PORT = 162,                  /* KW_PORT  */
  YYSYMBOL_KW_USE_TIME_RECVD = 163,        /* KW_USE_TIME_RECVD  */
  YYSYMBOL_KW_FACILITY = 164,              /* KW_FACILITY  */
  YYSYMBOL_KW_SEVERITY = 165,              /* KW_SEVERITY  */
  YYSYMBOL_KW_HOST = 166,                  /* KW_HOST  */
  YYSYMBOL_KW_MATCH = 167,                 /* KW_MATCH  */
  YYSYMBOL_KW_MESSAGE = 168,               /* KW_MESSAGE  */
  YYSYMBOL_KW_NETMASK = 169,               /* KW_NETMASK  */
  YYSYMBOL_KW_TAGS = 170,                  /* KW_TAGS  */
  YYSYMBOL_KW_NETMASK6 = 171,              /* KW_NETMASK6  */
  YYSYMBOL_KW_REWRITE = 172,               /* KW_REWRITE  */
  YYSYMBOL_KW_CONDITION = 173,             /* KW_CONDITION  */
  YYSYMBOL_KW_VALUE = 174,                 /* KW_VALUE  */
  YYSYMBOL_KW_YES = 175,                   /* KW_YES  */
  YYSYMBOL_KW_NO = 176,                    /* KW_NO  */
  YYSYMBOL_KW_AUTO = 177,                  /* KW_AUTO  */
  YYSYMBOL_KW_IFDEF = 178,                 /* KW_IFDEF  */
  YYSYMBOL_KW_ENDIF = 179,                 /* KW_ENDIF  */
  YYSYMBOL_LL_DOTDOT = 180,                /* LL_DOTDOT  */
  YYSYMBOL_LL_DOTDOTDOT = 181,             /* LL_DOTDOTDOT  */
  YYSYMBOL_LL_PRAGMA = 182,                /* LL_PRAGMA  */
  YYSYMBOL_LL_EOL = 183,                   /* LL_EOL  */
  YYSYMBOL_LL_ERROR = 184,                 /* LL_ERROR  */
  YYSYMBOL_LL_ARROW = 185,                 /* LL_ARROW  */
  YYSYMBOL_LL_IDENTIFIER = 186,            /* LL_IDENTIFIER  */
  YYSYMBOL_LL_NUMBER = 187,                /* LL_NUMBER  */
  YYSYMBOL_LL_FLOAT = 188,                 /* LL_FLOAT  */
  YYSYMBOL_LL_STRING = 189,                /* LL_STRING  */
  YYSYMBOL_LL_TOKEN = 190,                 /* LL_TOKEN  */
  YYSYMBOL_LL_BLOCK = 191,                 /* LL_BLOCK  */
  YYSYMBOL_LL_PLUGIN = 192,                /* LL_PLUGIN  */
  YYSYMBOL_LL_TEMPLATE_REF = 193,          /* LL_TEMPLATE_REF  */
  YYSYMBOL_LL_MESSAGE_REF = 194,           /* LL_MESSAGE_REF  */
  YYSYMBOL_KW_VALUE_PAIRS = 195,           /* KW_VALUE_PAIRS  */
  YYSYMBOL_KW_EXCLUDE = 196,               /* KW_EXCLUDE  */
  YYSYMBOL_KW_PAIR = 197,                  /* KW_PAIR  */
  YYSYMBOL_KW_KEY = 198,                   /* KW_KEY  */
  YYSYMBOL_KW_SCOPE = 199,                 /* KW_SCOPE  */
  YYSYMBOL_KW_SHIFT = 200,                 /* KW_SHIFT  */
  YYSYMBOL_KW_SHIFT_LEVELS = 201,          /* KW_SHIFT_LEVELS  */
  YYSYMBOL_KW_REKEY = 202,                 /* KW_REKEY  */
  YYSYMBOL_KW_ADD_PREFIX = 203,            /* KW_ADD_PREFIX  */
  YYSYMBOL_KW_REPLACE_PREFIX = 204,        /* KW_REPLACE_PREFIX  */
  YYSYMBOL_KW_CAST = 205,                  /* KW_CAST  */
  YYSYMBOL_KW_UPPER = 206,                 /* KW_UPPER  */
  YYSYMBOL_KW_LOWER = 207,                 /* KW_LOWER  */
  YYSYMBOL_KW_INCLUDE_BYTES = 208,         /* KW_INCLUDE_BYTES  */
  YYSYMBOL_KW_ON_ERROR = 209,              /* KW_ON_ERROR  */
  YYSYMBOL_KW_RETRIES = 210,               /* KW_RETRIES  */
  YYSYMBOL_KW_FETCH_NO_DATA_DELAY = 211,   /* KW_FETCH_NO_DATA_DELAY  */
  YYSYMBOL_KW_LABELS = 212,                /* KW_LABELS  */
  YYSYMBOL_KW_SET_TAG = 213,               /* KW_SET_TAG  */
  YYSYMBOL_KW_CLEAR_TAG = 214,             /* KW_CLEAR_TAG  */
  YYSYMBOL_KW_GROUP_SET = 215,             /* KW_GROUP_SET  */
  YYSYMBOL_KW_GROUP_UNSET = 216,           /* KW_GROUP_UNSET  */
  YYSYMBOL_KW_SET = 217,                   /* KW_SET  */
  YYSYMBOL_KW_UNSET = 218,                 /* KW_UNSET  */
  YYSYMBOL_KW_RENAME = 219,                /* KW_RENAME  */
  YYSYMBOL_KW_SUBST = 220,                 /* KW_SUBST  */
  YYSYMBOL_KW_VALUES = 221,                /* KW_VALUES  */
  YYSYMBOL_KW_SET_SEVERITY = 222,          /* KW_SET_SEVERITY  */
  YYSYMBOL_KW_SET_FACILITY = 223,          /* KW_SET_FACILITY  */
  YYSYMBOL_KW_SET_PRI = 224,               /* KW_SET_PRI  */
  YYSYMBOL_KW_SET_MATCHES = 225,           /* KW_SET_MATCHES  */
  YYSYMBOL_KW_UNSET_MATCHES = 226,         /* KW_UNSET_MATCHES  */
  YYSYMBOL_227_ = 227,                     /* '('  */
  YYSYMBOL_228_ = 228,                     /* ')'  */
  YYSYMBOL_229_ = 229,                     /* '{'  */
  YYSYMBOL_230_ = 230,                     /* '}'  */
  YYSYMBOL_231_ = 231,                     /* ';'  */
  YYSYMBOL_232_ = 232,                     /* ':'  */
  YYSYMBOL_YYACCEPT = 233,                 /* $accept  */
  YYSYMBOL_start = 234,                    /* start  */
  YYSYMBOL_rewrite_expr_list = 235,        /* rewrite_expr_list  */
  YYSYMBOL_rewrite_expr = 236,             /* rewrite_expr  */
  YYSYMBOL_237_1 = 237,                    /* $@1  */
  YYSYMBOL_238_2 = 238,                    /* $@2  */
  YYSYMBOL_239_3 = 239,                    /* $@3  */
  YYSYMBOL_240_4 = 240,                    /* $@4  */
  YYSYMBOL_241_5 = 241,                    /* $@5  */
  YYSYMBOL_242_6 = 242,                    /* $@6  */
  YYSYMBOL_243_7 = 243,                    /* $@7  */
  YYSYMBOL_244_8 = 244,                    /* $@8  */
  YYSYMBOL_245_9 = 245,                    /* $@9  */
  YYSYMBOL_246_10 = 246,                   /* $@10  */
  YYSYMBOL_247_11 = 247,                   /* $@11  */
  YYSYMBOL_248_12 = 248,                   /* $@12  */
  YYSYMBOL_249_13 = 249,                   /* $@13  */
  YYSYMBOL_rewrite_settag_opts = 250,      /* rewrite_settag_opts  */
  YYSYMBOL_rewrite_settag_opt = 251,       /* rewrite_settag_opt  */
  YYSYMBOL_rewrite_groupset_opts = 252,    /* rewrite_groupset_opts  */
  YYSYMBOL_rewrite_groupset_opt = 253,     /* rewrite_groupset_opt  */
  YYSYMBOL_rewrite_subst_opts = 254,       /* rewrite_subst_opts  */
  YYSYMBOL_rewrite_subst_opt = 255,        /* rewrite_subst_opt  */
  YYSYMBOL_256_14 = 256,                   /* $@14  */
  YYSYMBOL_rewrite_rename_opts = 257,      /* rewrite_rename_opts  */
  YYSYMBOL_rewrite_rename_opt = 258,       /* rewrite_rename_opt  */
  YYSYMBOL_rewrite_set_opts = 259,         /* rewrite_set_opts  */
  YYSYMBOL_rewrite_set_opt = 260,          /* rewrite_set_opt  */
  YYSYMBOL_rewrite_set_pri_opts = 261,     /* rewrite_set_pri_opts  */
  YYSYMBOL_rewrite_set_pri_opt = 262,      /* rewrite_set_pri_opt  */
  YYSYMBOL_rewrite_set_severity_opts = 263, /* rewrite_set_severity_opts  */
  YYSYMBOL_rewrite_set_severity_opt = 264, /* rewrite_set_severity_opt  */
  YYSYMBOL_rewrite_set_facility_opts = 265, /* rewrite_set_facility_opts  */
  YYSYMBOL_rewrite_set_facility_opt = 266, /* rewrite_set_facility_opt  */
  YYSYMBOL_rewrite_set_matches_opts = 267, /* rewrite_set_matches_opts  */
  YYSYMBOL_rewrite_set_matches_opt = 268,  /* rewrite_set_matches_opt  */
  YYSYMBOL_rewrite_unset_matches_opts = 269, /* rewrite_unset_matches_opts  */
  YYSYMBOL_rewrite_unset_matches_opt = 270, /* rewrite_unset_matches_opt  */
  YYSYMBOL_source_content = 271,           /* source_content  */
  YYSYMBOL_source_items = 272,             /* source_items  */
  YYSYMBOL_source_item = 273,              /* source_item  */
  YYSYMBOL_source_plugin = 274,            /* source_plugin  */
  YYSYMBOL_source_afinter = 275,           /* source_afinter  */
  YYSYMBOL_source_afinter_params = 276,    /* source_afinter_params  */
  YYSYMBOL_277_15 = 277,                   /* $@15  */
  YYSYMBOL_source_afinter_options = 278,   /* source_afinter_options  */
  YYSYMBOL_source_afinter_option = 279,    /* source_afinter_option  */
  YYSYMBOL_filter_content = 280,           /* filter_content  */
  YYSYMBOL_filterx_content = 281,          /* filterx_content  */
  YYSYMBOL_282_16 = 282,                   /* @16  */
  YYSYMBOL_parser_content = 283,           /* parser_content  */
  YYSYMBOL_rewrite_content = 284,          /* rewrite_content  */
  YYSYMBOL_dest_content = 285,             /* dest_content  */
  YYSYMBOL_dest_items = 286,               /* dest_items  */
  YYSYMBOL_dest_item = 287,                /* dest_item  */
  YYSYMBOL_dest_plugin = 288,              /* dest_plugin  */
  YYSYMBOL_log_items = 289,                /* log_items  */
  YYSYMBOL_log_item = 290,                 /* log_item  */
  YYSYMBOL_log_scheduler = 291,            /* log_scheduler  */
  YYSYMBOL_292_17 = 292,                   /* @17  */
  YYSYMBOL_log_scheduler_options = 293,    /* log_scheduler_options  */
  YYSYMBOL_log_scheduler_option = 294,     /* log_scheduler_option  */
  YYSYMBOL_log_junction = 295,             /* log_junction  */
  YYSYMBOL_log_last_junction = 296,        /* log_last_junction  */
  YYSYMBOL_log_forks = 297,                /* log_forks  */
  YYSYMBOL_log_fork = 298,                 /* log_fork  */
  YYSYMBOL_log_conditional = 299,          /* log_conditional  */
  YYSYMBOL_log_if = 300,                   /* log_if  */
  YYSYMBOL_log_content = 301,              /* log_content  */
  YYSYMBOL_log_flags = 302,                /* log_flags  */
  YYSYMBOL_log_flags_items = 303,          /* log_flags_items  */
  YYSYMBOL_template_content_inner = 304,   /* template_content_inner  */
  YYSYMBOL_type_hint = 305,                /* type_hint  */
  YYSYMBOL_template_content = 306,         /* template_content  */
  YYSYMBOL_307_18 = 307,                   /* @18  */
  YYSYMBOL_string = 308,                   /* string  */
  YYSYMBOL_yesno_strict = 309,             /* yesno_strict  */
  YYSYMBOL_yesno = 310,                    /* yesno  */
  YYSYMBOL_dnsmode = 311,                  /* dnsmode  */
  YYSYMBOL_nonnegative_integer64 = 312,    /* nonnegative_integer64  */
  YYSYMBOL_nonnegative_integer = 313,      /* nonnegative_integer  */
  YYSYMBOL_positive_integer64 = 314,       /* positive_integer64  */
  YYSYMBOL_positive_integer = 315,         /* positive_integer  */
  YYSYMBOL_string_or_number = 316,         /* string_or_number  */
  YYSYMBOL_optional_string = 317,          /* optional_string  */
  YYSYMBOL_normalized_flag = 318,          /* normalized_flag  */
  YYSYMBOL_string_list = 319,              /* string_list  */
  YYSYMBOL_string_list_build = 320,        /* string_list_build  */
  YYSYMBOL_semicolons = 321,               /* semicolons  */
  YYSYMBOL_source_option = 322,            /* source_option  */
  YYSYMBOL_323_21 = 323,                   /* $@21  */
  YYSYMBOL_host_resolve_option = 324,      /* host_resolve_option  */
  YYSYMBOL_template_option = 325,          /* template_option  */
  YYSYMBOL_matcher_option = 326,           /* matcher_option  */
  YYSYMBOL_matcher_flags = 327,            /* matcher_flags  */
  YYSYMBOL_rewrite_expr_opt = 328,         /* rewrite_expr_opt  */
  YYSYMBOL_rewrite_condition_opt = 329,    /* rewrite_condition_opt  */
  YYSYMBOL_330_31 = 330,                   /* $@31  */
  YYSYMBOL__destination_context_push = 331, /* _destination_context_push  */
  YYSYMBOL__destination_context_pop = 332, /* _destination_context_pop  */
  YYSYMBOL__source_context_push = 333,     /* _source_context_push  */
  YYSYMBOL__source_context_pop = 334,      /* _source_context_pop  */
  YYSYMBOL__filterx_context_push = 335,    /* _filterx_context_push  */
  YYSYMBOL__filterx_context_pop = 336      /* _filterx_context_pop  */
};
typedef enum yysymbol_kind_t yysymbol_kind_t;



/* Unqualified %code blocks.  */
#line 31 "lib/rewrite/rewrite-expr-grammar.y"


#include "rewrite/rewrite-set-tag.h"
#include "rewrite/rewrite-set.h"
#include "rewrite/rewrite-unset.h"
#include "rewrite/rewrite-rename.h"
#include "rewrite/rewrite-subst.h"
#include "rewrite/rewrite-groupset.h"
#include "rewrite/rewrite-set-matches.h"
#include "rewrite/rewrite-unset-matches.h"
#include "rewrite/rewrite-set-pri.h"
#include "rewrite/rewrite-set-severity.h"
#include "rewrite/rewrite-set-facility.h"
#include "filter/filter-expr.h"
#include "filter/filter-expr-parser.h"
#include "cfg-grammar-internal.h"
#include "syslog-names.h"
#include "plugin.h"

#include <string.h>

#line 71 "lib/rewrite/rewrite-expr-grammar.y"


#pragma GCC diagnostic ignored "-Wswitch-default"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"

#if (defined(__GNUC__) && __GNUC__ >= 6) || (defined(__clang__) && __clang_major__ >= 10)
#  pragma GCC diagnostic ignored "-Wmisleading-indentation"
#endif


# define YYLLOC_DEFAULT(Current, Rhs, N)                                \
  do {                                                                  \
    if (N)                                                              \
      {                                                                 \
        (Current).name         = YYRHSLOC(Rhs, 1).name;                 \
        (Current).first_line   = YYRHSLOC (Rhs, 1).first_line;          \
        (Current).first_column = YYRHSLOC (Rhs, 1).first_column;        \
        (Current).last_line    = YYRHSLOC (Rhs, N).last_line;           \
        (Current).last_column  = YYRHSLOC (Rhs, N).last_column;         \
      }                                                                 \
    else                                                                \
      {                                                                 \
        (Current).name         = YYRHSLOC(Rhs, 0).name;                 \
        (Current).first_line   = (Current).last_line   =                \
          YYRHSLOC (Rhs, 0).last_line;                                  \
        (Current).first_column = (Current).last_column =                \
          YYRHSLOC (Rhs, 0).last_column;                                \
      }                                                                 \
  } while (0)

#define CHECK_ERROR_WITHOUT_MESSAGE(val, token) do {                    \
    if (!(val))                                                         \
      {                                                                 \
        YYERROR;                                                        \
      }                                                                 \
  } while (0)

#define CHECK_ERROR(val, token, errorfmt, ...) do {                     \
    if (!(val))                                                         \
      {                                                                 \
        if (errorfmt)                                                   \
          {                                                             \
            gchar __buf[256];                                           \
            g_snprintf(__buf, sizeof(__buf), errorfmt, ## __VA_ARGS__); \
            yyerror(& (token), lexer, NULL, NULL, __buf);               \
          }                                                             \
        YYERROR;                                                        \
      }                                                                 \
  } while (0)

#define CHECK_ERROR_GERROR(val, token, error, errorfmt, ...) do {       \
    if (!(val))                                                         \
      {                                                                 \
        if (errorfmt)                                                   \
          {                                                             \
            gchar __buf[256];                                           \
            g_snprintf(__buf, sizeof(__buf), errorfmt ", error=%s", ## __VA_ARGS__, error->message); \
            yyerror(& (token), lexer, NULL, NULL, __buf);               \
          }                                                             \
        g_clear_error(&error);						\
        YYERROR;                                                        \
      }                                                                 \
  } while (0)

#define YYMAXDEPTH 20000



#line 1034 "lib/rewrite/rewrite-expr-grammar.c"

#ifdef short
# undef short
#endif

/* On compilers that do not define __PTRDIFF_MAX__ etc., make sure
   <limits.h> and (if available) <stdint.h> are included
   so that the code can choose integer types of a good width.  */

#ifndef __PTRDIFF_MAX__
# include <limits.h> /* INFRINGES ON USER NAME SPACE */
# if defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stdint.h> /* INFRINGES ON USER NAME SPACE */
#  define YY_STDINT_H
# endif
#endif

/* Narrow types that promote to a signed type and that can represent a
   signed or unsigned integer of at least N bits.  In tables they can
   save space and decrease cache pressure.  Promoting to a signed type
   helps avoid bugs in integer arithmetic.  */

#ifdef __INT_LEAST8_MAX__
typedef __INT_LEAST8_TYPE__ yytype_int8;
#elif defined YY_STDINT_H
typedef int_least8_t yytype_int8;
#else
typedef signed char yytype_int8;
#endif

#ifdef __INT_LEAST16_MAX__
typedef __INT_LEAST16_TYPE__ yytype_int16;
#elif defined YY_STDINT_H
typedef int_least16_t yytype_int16;
#else
typedef short yytype_int16;
#endif

/* Work around bug in HP-UX 11.23, which defines these macros
   incorrectly for preprocessor constants.  This workaround can likely
   be removed in 2023, as HPE has promised support for HP-UX 11.23
   (aka HP-UX 11i v2) only through the end of 2022; see Table 2 of
   <https://h20195.www2.hpe.com/V2/getpdf.aspx/4AA4-7673ENW.pdf>.  */
#ifdef __hpux
# undef UINT_LEAST8_MAX
# undef UINT_LEAST16_MAX
# define UINT_LEAST8_MAX 255
# define UINT_LEAST16_MAX 65535
#endif

#if defined __UINT_LEAST8_MAX__ && __UINT_LEAST8_MAX__ <= __INT_MAX__
typedef __UINT_LEAST8_TYPE__ yytype_uint8;
#elif (!defined __UINT_LEAST8_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST8_MAX <= INT_MAX)
typedef uint_least8_t yytype_uint8;
#elif !defined __UINT_LEAST8_MAX__ && UCHAR_MAX <= INT_MAX
typedef unsigned char yytype_uint8;
#else
typedef short yytype_uint8;
#endif

#if defined __UINT_LEAST16_MAX__ && __UINT_LEAST16_MAX__ <= __INT_MAX__
typedef __UINT_LEAST16_TYPE__ yytype_uint16;
#elif (!defined __UINT_LEAST16_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST16_MAX <= INT_MAX)
typedef uint_least16_t yytype_uint16;
#elif !defined __UINT_LEAST16_MAX__ && USHRT_MAX <= INT_MAX
typedef unsigned short yytype_uint16;
#else
typedef int yytype_uint16;
#endif

#ifndef YYPTRDIFF_T
# if defined __PTRDIFF_TYPE__ && defined __PTRDIFF_MAX__
#  define YYPTRDIFF_T __PTRDIFF_TYPE__
#  define YYPTRDIFF_MAXIMUM __PTRDIFF_MAX__
# elif defined PTRDIFF_MAX
#  ifndef ptrdiff_t
#   include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  endif
#  define YYPTRDIFF_T ptrdiff_t
#  define YYPTRDIFF_MAXIMUM PTRDIFF_MAX
# else
#  define YYPTRDIFF_T long
#  define YYPTRDIFF_MAXIMUM LONG_MAX
# endif
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned
# endif
#endif

#define YYSIZE_MAXIMUM                                  \
  YY_CAST (YYPTRDIFF_T,                                 \
           (YYPTRDIFF_MAXIMUM < YY_CAST (YYSIZE_T, -1)  \
            ? YYPTRDIFF_MAXIMUM                         \
            : YY_CAST (YYSIZE_T, -1)))

#define YYSIZEOF(X) YY_CAST (YYPTRDIFF_T, sizeof (X))


/* Stored state numbers (used for stacks). */
typedef yytype_int16 yy_state_t;

/* State numbers in computations.  */
typedef int yy_state_fast_t;

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(Msgid) dgettext ("bison-runtime", Msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(Msgid) Msgid
# endif
#endif


#ifndef YY_ATTRIBUTE_PURE
# if defined __GNUC__ && 2 < __GNUC__ + (96 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_PURE __attribute__ ((__pure__))
# else
#  define YY_ATTRIBUTE_PURE
# endif
#endif

#ifndef YY_ATTRIBUTE_UNUSED
# if defined __GNUC__ && 2 < __GNUC__ + (7 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_UNUSED __attribute__ ((__unused__))
# else
#  define YY_ATTRIBUTE_UNUSED
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YY_USE(E) ((void) (E))
#else
# define YY_USE(E) /* empty */
#endif

/* Suppress an incorrect diagnostic about yylval being uninitialized.  */
#if defined __GNUC__ && ! defined __ICC && 406 <= __GNUC__ * 100 + __GNUC_MINOR__
# if __GNUC__ * 100 + __GNUC_MINOR__ < 407
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")
# else
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")              \
    _Pragma ("GCC diagnostic ignored \"-Wmaybe-uninitialized\"")
# endif
# define YY_IGNORE_MAYBE_UNINITIALIZED_END      \
    _Pragma ("GCC diagnostic pop")
#else
# define YY_INITIAL_VALUE(Value) Value
#endif
#ifndef YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_END
#endif
#ifndef YY_INITIAL_VALUE
# define YY_INITIAL_VALUE(Value) /* Nothing. */
#endif

#if defined __cplusplus && defined __GNUC__ && ! defined __ICC && 6 <= __GNUC__
# define YY_IGNORE_USELESS_CAST_BEGIN                          \
    _Pragma ("GCC diagnostic push")                            \
    _Pragma ("GCC diagnostic ignored \"-Wuseless-cast\"")
# define YY_IGNORE_USELESS_CAST_END            \
    _Pragma ("GCC diagnostic pop")
#endif
#ifndef YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_END
#endif


#define YY_ASSERT(E) ((void) (0 && (E)))

#if 1

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined EXIT_SUCCESS
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
      /* Use EXIT_SUCCESS as a witness for stdlib.h.  */
#     ifndef EXIT_SUCCESS
#      define EXIT_SUCCESS 0
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's 'empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined EXIT_SUCCESS \
       && ! ((defined YYMALLOC || defined malloc) \
             && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef EXIT_SUCCESS
#    define EXIT_SUCCESS 0
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined EXIT_SUCCESS
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined EXIT_SUCCESS
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* 1 */

#if (! defined yyoverflow \
     && (! defined __cplusplus \
         || (defined REWRITE_EXPR_LTYPE_IS_TRIVIAL && REWRITE_EXPR_LTYPE_IS_TRIVIAL \
             && defined REWRITE_EXPR_STYPE_IS_TRIVIAL && REWRITE_EXPR_STYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yy_state_t yyss_alloc;
  YYSTYPE yyvs_alloc;
  YYLTYPE yyls_alloc;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (YYSIZEOF (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (YYSIZEOF (yy_state_t) + YYSIZEOF (YYSTYPE) \
             + YYSIZEOF (YYLTYPE)) \
      + 2 * YYSTACK_GAP_MAXIMUM)

# define YYCOPY_NEEDED 1

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack_alloc, Stack)                           \
    do                                                                  \
      {                                                                 \
        YYPTRDIFF_T yynewbytes;                                         \
        YYCOPY (&yyptr->Stack_alloc, Stack, yysize);                    \
        Stack = &yyptr->Stack_alloc;                                    \
        yynewbytes = yystacksize * YYSIZEOF (*Stack) + YYSTACK_GAP_MAXIMUM; \
        yyptr += yynewbytes / YYSIZEOF (*yyptr);                        \
      }                                                                 \
    while (0)

#endif

#if defined YYCOPY_NEEDED && YYCOPY_NEEDED
/* Copy COUNT objects from SRC to DST.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(Dst, Src, Count) \
      __builtin_memcpy (Dst, Src, YY_CAST (YYSIZE_T, (Count)) * sizeof (*(Src)))
#  else
#   define YYCOPY(Dst, Src, Count)              \
      do                                        \
        {                                       \
          YYPTRDIFF_T yyi;                      \
          for (yyi = 0; yyi < (Count); yyi++)   \
            (Dst)[yyi] = (Src)[yyi];            \
        }                                       \
      while (0)
#  endif
# endif
#endif /* !YYCOPY_NEEDED */

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  34
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   369

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  233
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  104
/* YYNRULES -- Number of rules.  */
#define YYNRULES  198
/* YYNSTATES -- Number of states.  */
#define YYNSTATES  419

/* YYMAXUTOK -- Last valid token kind.  */
#define YYMAXUTOK   10545


/* YYTRANSLATE(TOKEN-NUM) -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex, with out-of-bounds checking.  */
#define YYTRANSLATE(YYX)                                \
  (0 <= (YYX) && (YYX) <= YYMAXUTOK                     \
   ? YY_CAST (yysymbol_kind_t, yytranslate[YYX])        \
   : YYSYMBOL_YYUNDEF)

/* YYTRANSLATE[TOKEN-NUM] -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex.  */
static const yytype_uint8 yytranslate[] =
{
       0,     3,     4,     5,     6,     7,     8,     9,    10,    11,
      12,    13,    14,    15,    16,    17,    18,    19,    20,    21,
      22,    23,    24,    25,    26,    27,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     227,   228,    48,    46,     2,    47,    50,    49,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,   232,   231,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,    51,     2,    52,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,   229,     2,   230,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
      28,    29,    30,    31,    32,    33,    34,    35,    36,    37,
      38,    39,    40,    41,    42,    43,    44,    53,    45,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
      54,    55,    56,    57,    58,    59,    60,    61,    62,    63,
      64,    65,    66,    67,     2,     2,     2,     2,     2,     2,
      68,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
      69,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,    70,    71,    72,    73,    74,    75,    76,    77,    78,
      79,    80,    81,    82,    83,    84,    85,    86,    87,    88,
      97,    98,    99,   100,   101,   102,     2,     2,     2,     2,
     103,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     104,   105,   106,     2,     2,     2,     2,     2,     2,     2,
     107,   108,     2,     2,     2,     2,     2,     2,     2,     2,
     109,   110,   111,     2,     2,     2,     2,     2,     2,     2,
     112,   113,   114,     2,     2,     2,     2,     2,     2,     2,
     115,   116,   117,     2,     2,     2,     2,     2,     2,     2,
     118,     2,   119,   120,   121,   122,   123,     2,     2,     2,
     124,   125,     2,     2,     2,     2,     2,     2,     2,     2,
     126,   127,   128,   129,     2,     2,     2,     2,     2,     2,
     130,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     131,   132,   133,   134,   135,   136,   137,   138,   139,   140,
     141,   142,   143,   144,   145,   146,     2,     2,     2,     2,
     147,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     148,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     149,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     150,   151,   152,     2,     2,     2,     2,     2,     2,     2,
     153,   154,   155,     2,     2,     2,     2,     2,     2,     2,
     156,   157,   158,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     159,   160,   161,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,   162,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     163,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     164,   165,   166,   167,   168,   169,   170,   171,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     172,   173,   174,     2,     2,     2,     2,     2,     2,     2,
     175,   176,   177,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
      89,    90,    91,    92,    93,    94,    95,    96,     2,     2,
     178,   179,     2,     2,     2,     2,     2,     2,     2,     2,
     180,   181,   182,   183,   184,   185,     2,     2,     2,     2,
     186,   187,   188,   189,   190,   191,   192,   193,   194,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     195,     2,   196,   197,   198,   199,   200,   201,   202,   203,
     204,   205,   206,   207,   208,     2,     2,     2,     2,     2,
     209,   210,   211,     2,     2,     2,     2,     2,     2,     2,
     212,     2,   213,   214,   215,   216,   217,   218,   219,   220,
     221,   222,   223,   224,   225,   226
};

#if REWRITE_EXPR_DEBUG
/* YYRLINE[YYN] -- Source line where rule number YYN was defined.  */
static const yytype_int16 yyrline[] =
{
       0,   491,   491,   495,   496,   497,   502,   501,   514,   513,
     521,   520,   528,   527,   533,   532,   538,   537,   548,   547,
     554,   553,   560,   559,   566,   565,   571,   570,   576,   575,
     581,   580,   585,   604,   605,   609,   613,   614,   618,   622,
     626,   627,   631,   631,   632,   636,   637,   641,   645,   646,
     650,   651,   660,   661,   665,   669,   670,   674,   678,   679,
     683,   687,   688,   692,   696,   697,   701,   707,   711,   712,
     713,   717,   718,   722,   741,   745,   745,   753,   754,   758,
     759,   764,   774,   774,   785,   795,   804,   810,   811,   812,
     816,   820,   839,   840,   844,   845,   846,   847,   848,   849,
     850,   851,   852,   853,   854,   855,   856,   857,   862,   861,
     871,   872,   876,   880,   888,   900,   905,   906,   910,   919,
     931,   932,   940,   944,   948,   956,   967,   971,   972,   976,
     977,   983,   990,   999,  1007,  1015,  1026,  1026,  1048,  1049,
    1053,  1054,  1058,  1059,  1069,  1070,  1074,  1081,  1088,  1095,
    1124,  1125,  1126,  1130,  1131,  1157,  1161,  1165,  1166,  1170,
    1171,  1338,  1339,  1340,  1341,  1342,  1343,  1344,  1345,  1346,
    1347,  1348,  1348,  1384,  1385,  1386,  1387,  1459,  1460,  1461,
    1462,  1463,  1464,  1465,  1477,  1478,  1482,  1483,  1576,  1591,
    1592,  1597,  1596,  1628,  1629,  1630,  1631,  1638,  1639
};
#endif

/** Accessing symbol of state STATE.  */
#define YY_ACCESSING_SYMBOL(State) YY_CAST (yysymbol_kind_t, yystos[State])

#if 1
/* The user-facing name of the symbol whose (internal) number is
   YYSYMBOL.  No bounds checking.  */
static const char *yysymbol_name (yysymbol_kind_t yysymbol) YY_ATTRIBUTE_UNUSED;

/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "\"end of file\"", "error", "\"invalid token\"", "LL_CONTEXT_ROOT",
  "LL_CONTEXT_DESTINATION", "LL_CONTEXT_SOURCE", "LL_CONTEXT_PARSER",
  "LL_CONTEXT_REWRITE", "LL_CONTEXT_FILTER", "LL_CONTEXT_LOG",
  "LL_CONTEXT_BLOCK_DEF", "LL_CONTEXT_BLOCK_REF",
  "LL_CONTEXT_BLOCK_CONTENT", "LL_CONTEXT_BLOCK_ARG", "LL_CONTEXT_PRAGMA",
  "LL_CONTEXT_FORMAT", "LL_CONTEXT_TEMPLATE_FUNC", "LL_CONTEXT_INNER_DEST",
  "LL_CONTEXT_INNER_SRC", "LL_CONTEXT_CLIENT_PROTO",
  "LL_CONTEXT_SERVER_PROTO", "LL_CONTEXT_OPTIONS", "LL_CONTEXT_CONFIG",
  "LL_CONTEXT_TEMPLATE_REF", "LL_CONTEXT_FILTERX",
  "LL_CONTEXT_FILTERX_FUNC", "LL_CONTEXT_FILTERX_ENUM", "LL_CONTEXT_MAX",
  "KW_ASSIGN", "KW_OR", "KW_AND", "KW_STR_EQ", "KW_STR_NE", "KW_TA_EQ",
  "KW_TA_NE", "KW_TAV_EQ", "KW_TAV_NE", "KW_STR_LT", "KW_STR_LE",
  "KW_STR_GE", "KW_STR_GT", "KW_TA_LT", "KW_TA_LE", "KW_TA_GE", "KW_TA_GT",
  "KW_PLUS_ASSIGN", "'+'", "'-'", "'*'", "'/'", "'.'", "'['", "']'",
  "KW_NOT", "KW_SOURCE", "KW_FILTER", "KW_PARSER", "KW_DESTINATION",
  "KW_LOG", "KW_OPTIONS", "KW_INCLUDE", "KW_BLOCK", "KW_JUNCTION",
  "KW_CHANNEL", "KW_IF", "KW_ELSE", "KW_ELIF", "KW_FILTERX", "KW_INTERNAL",
  "KW_SYSLOG", "KW_MARK_FREQ", "KW_STATS_FREQ", "KW_STATS_LEVEL",
  "KW_STATS_LIFETIME", "KW_FLUSH_LINES", "KW_SUPPRESS", "KW_FLUSH_TIMEOUT",
  "KW_LOG_MSG_SIZE", "KW_FILE_TEMPLATE", "KW_PROTO_TEMPLATE",
  "KW_MARK_MODE", "KW_ENCODING", "KW_TYPE", "KW_STATS_MAX_DYNAMIC",
  "KW_MIN_IW_SIZE_PER_READER", "KW_WORKERS", "KW_BATCH_LINES",
  "KW_BATCH_TIMEOUT", "KW_TRIM_LARGE_MESSAGES", "KW_STATS", "KW_FREQ",
  "KW_LEVEL", "KW_LIFETIME", "KW_MAX_DYNAMIC", "KW_SYSLOG_STATS",
  "KW_HEALTHCHECK_FREQ", "KW_WORKER_PARTITION_KEY", "KW_CHAIN_HOSTNAMES",
  "KW_NORMALIZE_HOSTNAMES", "KW_KEEP_HOSTNAME", "KW_CHECK_HOSTNAME",
  "KW_BAD_HOSTNAME", "KW_LOG_LEVEL", "KW_KEEP_TIMESTAMP", "KW_USE_DNS",
  "KW_USE_FQDN", "KW_CUSTOM_DOMAIN", "KW_DNS_CACHE", "KW_DNS_CACHE_SIZE",
  "KW_DNS_CACHE_EXPIRE", "KW_DNS_CACHE_EXPIRE_FAILED",
  "KW_DNS_CACHE_HOSTS", "KW_PERSIST_ONLY", "KW_USE_RCPTID",
  "KW_USE_UNIQID", "KW_TZ_CONVERT", "KW_TS_FORMAT", "KW_FRAC_DIGITS",
  "KW_LOG_FIFO_SIZE", "KW_LOG_FETCH_LIMIT", "KW_LOG_IW_SIZE",
  "KW_LOG_PREFIX", "KW_PROGRAM_OVERRIDE", "KW_HOST_OVERRIDE",
  "KW_THROTTLE", "KW_THREADED", "KW_PASS_UNIX_CREDENTIALS",
  "KW_PERSIST_NAME", "KW_READ_OLD_RECORDS", "KW_USE_SYSLOGNG_PID",
  "KW_FLAGS", "KW_PAD_SIZE", "KW_TIME_ZONE", "KW_RECV_TIME_ZONE",
  "KW_SEND_TIME_ZONE", "KW_LOCAL_TIME_ZONE", "KW_FORMAT",
  "KW_MULTI_LINE_MODE", "KW_MULTI_LINE_PREFIX", "KW_MULTI_LINE_GARBAGE",
  "KW_TRUNCATE_SIZE", "KW_TIME_REOPEN", "KW_TIME_REAP", "KW_TIME_SLEEP",
  "KW_PARTITIONS", "KW_PARTITION_KEY", "KW_PARALLELIZE", "KW_TMPL_ESCAPE",
  "KW_OPTIONAL", "KW_CREATE_DIRS", "KW_OWNER", "KW_GROUP", "KW_PERM",
  "KW_DIR_OWNER", "KW_DIR_GROUP", "KW_DIR_PERM", "KW_TEMPLATE",
  "KW_TEMPLATE_ESCAPE", "KW_TEMPLATE_FUNCTION", "KW_DEFAULT_FACILITY",
  "KW_DEFAULT_SEVERITY", "KW_SDATA_PREFIX", "KW_PORT", "KW_USE_TIME_RECVD",
  "KW_FACILITY", "KW_SEVERITY", "KW_HOST", "KW_MATCH", "KW_MESSAGE",
  "KW_NETMASK", "KW_TAGS", "KW_NETMASK6", "KW_REWRITE", "KW_CONDITION",
  "KW_VALUE", "KW_YES", "KW_NO", "KW_AUTO", "KW_IFDEF", "KW_ENDIF",
  "LL_DOTDOT", "LL_DOTDOTDOT", "LL_PRAGMA", "LL_EOL", "LL_ERROR",
  "LL_ARROW", "LL_IDENTIFIER", "LL_NUMBER", "LL_FLOAT", "LL_STRING",
  "LL_TOKEN", "LL_BLOCK", "LL_PLUGIN", "LL_TEMPLATE_REF", "LL_MESSAGE_REF",
  "KW_VALUE_PAIRS", "KW_EXCLUDE", "KW_PAIR", "KW_KEY", "KW_SCOPE",
  "KW_SHIFT", "KW_SHIFT_LEVELS", "KW_REKEY", "KW_ADD_PREFIX",
  "KW_REPLACE_PREFIX", "KW_CAST", "KW_UPPER", "KW_LOWER",
  "KW_INCLUDE_BYTES", "KW_ON_ERROR", "KW_RETRIES",
  "KW_FETCH_NO_DATA_DELAY", "KW_LABELS", "KW_SET_TAG", "KW_CLEAR_TAG",
  "KW_GROUP_SET", "KW_GROUP_UNSET", "KW_SET", "KW_UNSET", "KW_RENAME",
  "KW_SUBST", "KW_VALUES", "KW_SET_SEVERITY", "KW_SET_FACILITY",
  "KW_SET_PRI", "KW_SET_MATCHES", "KW_UNSET_MATCHES", "'('", "')'", "'{'",
  "'}'", "';'", "':'", "$accept", "start", "rewrite_expr_list",
  "rewrite_expr", "$@1", "$@2", "$@3", "$@4", "$@5", "$@6", "$@7", "$@8",
  "$@9", "$@10", "$@11", "$@12", "$@13", "rewrite_settag_opts",
  "rewrite_settag_opt", "rewrite_groupset_opts", "rewrite_groupset_opt",
  "rewrite_subst_opts", "rewrite_subst_opt", "$@14", "rewrite_rename_opts",
  "rewrite_rename_opt", "rewrite_set_opts", "rewrite_set_opt",
  "rewrite_set_pri_opts", "rewrite_set_pri_opt",
  "rewrite_set_severity_opts", "rewrite_set_severity_opt",
  "rewrite_set_facility_opts", "rewrite_set_facility_opt",
  "rewrite_set_matches_opts", "rewrite_set_matches_opt",
  "rewrite_unset_matches_opts", "rewrite_unset_matches_opt",
  "source_content", "source_items", "source_item", "source_plugin",
  "source_afinter", "source_afinter_params", "$@15",
  "source_afinter_options", "source_afinter_option", "filter_content",
  "filterx_content", "@16", "parser_content", "rewrite_content",
  "dest_content", "dest_items", "dest_item", "dest_plugin", "log_items",
  "log_item", "log_scheduler", "@17", "log_scheduler_options",
  "log_scheduler_option", "log_junction", "log_last_junction", "log_forks",
  "log_fork", "log_conditional", "log_if", "log_content", "log_flags",
  "log_flags_items", "template_content_inner", "type_hint",
  "template_content", "@18", "string", "yesno_strict", "yesno", "dnsmode",
  "nonnegative_integer64", "nonnegative_integer", "positive_integer64",
  "positive_integer", "string_or_number", "optional_string",
  "normalized_flag", "string_list", "string_list_build", "semicolons",
  "source_option", "$@21", "host_resolve_option", "template_option",
  "matcher_option", "matcher_flags", "rewrite_expr_opt",
  "rewrite_condition_opt", "$@31", "_destination_context_push",
  "_destination_context_pop", "_source_context_push",
  "_source_context_pop", "_filterx_context_push", "_filterx_context_pop", YY_NULLPTR
};

static const char *
yysymbol_name (yysymbol_kind_t yysymbol)
{
  return yytname[yysymbol];
}
#endif

#define YYPACT_NINF (-194)

#define yypact_value_is_default(Yyn) \
  ((Yyn) == YYPACT_NINF)

#define YYTABLE_NINF (-136)

#define yytable_value_is_error(Yyn) \
  0

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
static const yytype_int16 yypact[] =
{
     -21,  -182,  -194,  -176,  -167,  -156,  -151,  -147,  -194,  -134,
    -120,  -113,  -110,  -106,   -80,  -194,   151,     1,   -59,   -59,
       1,  -194,  -194,  -194,  -194,  -194,   -50,  -128,  -128,  -194,
    -194,  -194,  -194,   -49,  -194,  -128,  -128,  -194,  -194,   -59,
     -59,   -21,   -21,   -57,  -194,   -62,  -194,  -194,  -144,  -194,
     -51,  -194,  -194,  -128,  -194,  -194,  -194,  -194,  -194,     7,
    -194,   -47,   -45,     1,  -194,  -194,  -194,  -194,     7,   -41,
    -194,  -194,  -194,   -38,  -194,     7,  -144,   -37,   -20,   -28,
    -144,  -194,   -51,   -18,   -15,   -13,   -12,   -11,   -10,    -9,
      -8,    -7,   -22,   -51,  -194,  -194,  -194,  -194,  -194,     7,
       7,     7,     7,    -5,     7,  -194,    76,    76,  -194,    -4,
       7,  -194,   -52,    -3,    -2,  -194,  -128,  -194,  -194,    -1,
    -137,  -128,     0,  -128,  -128,  -128,  -137,  -128,  -128,  -194,
    -194,     7,   -54,     2,     7,  -194,     3,     7,  -194,     4,
       7,  -194,     5,     7,  -194,  -194,  -194,  -117,   -81,   -77,
     -73,   -72,     6,    -6,   -68,     1,   -59,  -194,  -194,  -194,
      24,   -42,     8,  -194,  -194,  -194,  -194,  -194,     9,  -194,
    -194,    12,  -128,    13,  -194,  -194,  -194,  -194,  -194,  -194,
      19,    21,  -194,  -194,    22,    23,    26,    27,    28,    29,
      30,    32,     7,  -194,    33,   -54,   -48,  -194,  -194,  -194,
    -194,  -194,  -194,  -194,  -194,  -194,  -128,  -194,  -128,  -194,
    -128,  -194,  -128,  -194,  -194,    76,  -194,  -194,  -128,  -194,
      78,    76,    34,   -64,  -194,  -194,  -194,  -194,  -194,  -194,
    -194,  -194,  -194,  -194,  -194,  -194,  -194,  -194,  -194,  -194,
    -194,  -194,  -194,    37,    38,  -194,    39,    36,   -43,    40,
      42,    41,    50,    53,    52,   -39,    55,    54,    56,  -194,
     -16,    57,    58,    43,  -194,  -194,    76,  -194,    76,  -128,
    -128,  -194,  -194,    60,  -194,  -194,   -59,  -194,  -194,   -59,
    -194,  -194,  -194,  -194,  -194,  -194,  -194,  -194,   -59,  -194,
     -59,    61,  -194,  -194,  -194,    62,    64,    65,   -16,  -194,
    -194,  -128,    67,    66,    68,    72,  -128,    73,  -194,  -194,
     -43,   -43,  -194,   -39,   -39,    76,  -194,     0,  -194,  -194,
    -194,    74,  -194,  -128,  -194,    63,  -194,  -194,  -194,  -194,
      75,   -66,  -194,  -194,  -194,  -194,    77,    80,    81,   -59,
    -194,    76,  -194,    79,    83,    84,    85,    86,    87,    88,
      89,    90,    91,    92,  -194,   -66,  -194,    11,  -194,  -194,
    -194,  -194,    93,  -137,  -137,  -137,    47,    47,  -128,  -128,
    -128,  -137,  -137,  -128,  -194,    94,    97,    98,    99,  -194,
    -194,   100,   101,   102,  -194,  -194,   103,   104,   105,   106,
     107,   108,   109,   110,  -137,   -84,  -137,  -137,  -194,  -194,
    -194,  -194,  -194,  -194,  -194,  -194,  -194,  -194,  -194,   111,
    -194,  -194,   112,   116,   117,  -194,  -194,  -194,  -194
};

/* YYDEFACT[STATE-NUM] -- Default reduction number in state STATE-NUM.
   Performed when YYTABLE does not specify something else to do.  Zero
   means the default is an error.  */
static const yytype_uint8 yydefact[] =
{
       5,     0,    32,     0,     0,     0,     0,     0,    14,     0,
       0,     0,     0,     0,     0,    12,     0,   117,     0,     0,
     117,   136,   136,   136,    24,   136,     0,     0,     0,   136,
     136,   136,   136,     0,     1,   154,   154,     2,   115,     0,
     159,     5,     5,     0,    18,     0,    20,    22,    37,     8,
      49,   138,   139,     0,   136,    28,    30,    26,    10,    65,
     153,     0,     0,   117,   160,     3,     4,   114,    34,   138,
     133,   134,   137,     0,   131,    34,    37,     0,     0,     0,
      37,    39,    49,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,    49,    51,    50,   190,    16,     6,    56,
      59,    53,    62,     0,    65,    66,    93,    93,   116,     0,
      34,    35,     0,     0,     0,   191,   158,    25,    36,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,    15,
      48,    46,    42,     0,    56,    57,     0,    59,    60,     0,
      53,    54,     0,    62,    63,    13,    64,     0,     0,     0,
       0,     0,     0,     0,     0,   117,     0,   105,   107,   106,
     120,     0,     0,    19,    33,   151,   152,   150,     0,    21,
      23,     0,   158,     0,   156,     9,   140,   141,   143,   142,
       0,     0,   146,   147,     0,     0,     0,     0,     0,     0,
       0,     0,    46,    47,     0,    42,     0,    44,    29,    55,
      31,    58,    27,    52,    11,    61,     0,   195,     0,    81,
       0,    84,     0,   193,    81,    93,   197,   108,     0,    85,
     128,    93,     0,     0,   118,   119,   132,   192,   157,    38,
     189,   177,   178,   179,   180,   181,   182,   188,   183,    17,
      45,     7,    40,     0,     0,    43,     0,     0,    70,     0,
       0,     0,     0,     0,     0,    89,     0,     0,     0,    82,
     111,     0,     0,     0,   126,    92,    93,    81,    93,     0,
     187,    94,    95,     0,    73,   196,     0,    72,    71,     0,
      96,    97,    99,   100,   103,   104,    91,   194,     0,    90,
       0,     0,   123,    98,   198,     0,     0,     0,   111,   101,
     102,   130,     0,     0,     0,     0,   187,     0,    75,    67,
      70,    70,    86,    89,    89,    93,    83,     0,   136,   109,
     110,     0,   155,   130,   121,     0,   125,   184,   186,   185,
       0,   171,    68,    69,    87,    88,     0,     0,     0,     0,
     129,    93,    74,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,    76,   171,    80,     0,   122,   112,
     113,   127,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   158,    77,     0,     0,     0,     0,   172,
     124,     0,     0,     0,   148,   149,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   162,   163,
     167,    79,   161,   166,   164,   165,   168,   169,   170,     0,
     145,   144,     0,     0,     0,   176,   174,   173,   175
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -194,  -194,   126,  -194,  -194,  -194,  -194,  -194,  -194,  -194,
    -194,  -194,  -194,  -194,  -194,  -194,  -194,   -35,  -194,   -31,
    -194,    15,  -194,  -194,    44,  -194,   -40,  -194,    71,  -194,
      95,  -194,   158,  -194,   161,  -194,   124,  -194,  -194,  -141,
    -194,  -194,  -194,  -194,  -194,    14,  -194,  -193,  -194,  -194,
    -194,  -194,  -194,  -138,  -194,  -194,   125,  -194,  -194,  -194,
      49,  -194,    46,   150,    10,  -169,  -194,  -194,  -102,  -194,
      25,  -194,  -194,   -19,  -194,   -27,  -194,  -119,  -194,  -194,
      35,  -194,   -14,  -194,   284,  -194,   -46,   177,   -17,  -194,
    -194,  -194,  -194,  -194,    45,  -100,   -32,  -194,  -194,  -194,
    -194,  -194,  -194,  -194
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
       0,    16,    17,    18,   132,    82,   102,    33,    26,   131,
      68,    75,    76,    48,   101,    99,   100,   109,   110,    79,
      80,   194,   195,   196,   191,   192,    92,    93,   139,   140,
     133,   134,   136,   137,   142,   143,   103,   104,   247,   275,
     276,   277,   278,   330,   331,   354,   355,   250,   258,   294,
     252,   262,   254,   287,   288,   289,   155,   156,   157,   260,
     297,   298,   158,    37,    38,    39,   159,   160,   161,   264,
     321,    72,    73,    44,    45,   172,   179,   180,   412,   183,
     184,   385,   386,   168,    61,   323,   173,   174,    41,   356,
     357,   379,    94,   245,   307,    95,    96,   171,   255,   312,
     248,   309,   259,   316
};

/* YYTABLE[YYPACT[STATE-NUM]] -- What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule whose
   number is the opposite.  If YYTABLE_NINF, syntax error.  */
static const yytype_int16 yytable[] =
{
      53,    54,    42,    46,    47,   162,    49,   188,    60,    60,
      55,    56,    57,    58,    83,    35,    81,    83,    74,    35,
      36,   256,    63,    64,    36,   273,    97,   105,   410,    77,
      43,   343,   197,   344,   243,    98,   111,   345,   176,   177,
     113,     1,   119,   111,    81,   114,    19,    20,    81,   118,
     178,    21,   346,   130,   347,   348,   349,   350,    51,    35,
      22,    52,   351,   352,    36,    84,    85,   135,   138,   141,
     144,    23,   105,   108,   303,   164,    24,    78,   111,   279,
      25,    86,   244,    87,    88,   167,   290,    19,    19,   222,
     223,   176,   177,    27,   181,   197,   185,   186,   187,   193,
     189,   190,   135,   178,   353,   138,    89,    28,   141,   375,
     206,   144,   207,   257,    29,   376,   377,    30,   378,    77,
      90,    31,    77,    90,    69,    70,    71,    52,   295,   296,
     147,   148,   149,   150,    51,   165,   166,    52,     1,   221,
     151,   279,   279,   152,   290,   290,   208,    32,   209,   274,
     210,    34,   211,   286,   212,   214,   213,   215,    91,   218,
     193,   219,   -78,   267,   302,   268,   304,    65,    66,   332,
     333,     2,    40,    67,   -41,   334,   335,    50,    59,   246,
      77,   249,   106,   251,   107,   253,  -135,   182,   224,   112,
     115,   261,     3,     4,     5,     6,     7,     8,     9,    10,
     117,    11,    12,    13,    14,    15,   129,   116,   263,   120,
     242,   203,   121,   336,   122,   123,   124,   125,   126,   127,
     128,   217,   153,   145,   163,   169,   170,   175,   146,   199,
     198,   200,   202,   204,   384,   216,   240,   226,   225,   362,
     227,   229,   305,   306,   381,   382,   383,   230,   154,   231,
     232,   233,   391,   392,   234,   235,   236,   237,   238,   310,
     239,   241,   311,   266,   269,   270,   272,   271,   280,   282,
     301,   313,   281,   314,   322,   409,   411,   413,   414,   306,
     283,   284,   285,   291,   292,   299,   293,   308,   300,   317,
     315,   318,   341,   319,   325,   201,   322,   324,   326,   338,
     327,   329,   339,   342,   205,   220,   363,   358,   359,   360,
     364,   365,   366,   367,   368,   369,   370,   371,   372,   373,
      62,   394,   361,   380,   395,   396,   397,   393,   398,   399,
     400,   401,   402,   403,   404,   405,   406,   407,   408,   415,
     416,   388,   389,   390,   417,   418,   265,   320,   340,   228,
       0,   328,   337,   387,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   374
};

static const yytype_int16 yycheck[] =
{
      27,    28,    19,    22,    23,   107,    25,   126,    35,    36,
      29,    30,    31,    32,    68,    58,    48,    68,    45,    58,
      63,   214,    39,    40,    63,    68,    53,    59,   112,   173,
      20,    97,   132,    99,    82,    54,    68,   103,   175,   176,
      75,    62,    82,    75,    76,    76,     0,   229,    80,    80,
     187,   227,   118,    93,   120,   121,   122,   123,   186,    58,
     227,   189,   128,   129,    63,   116,   117,    99,   100,   101,
     102,   227,   104,    63,   267,   110,   227,   221,   110,   248,
     227,   132,   130,   134,   135,   112,   255,    41,    42,    65,
      66,   175,   176,   227,   121,   195,   123,   124,   125,   131,
     127,   128,   134,   187,   170,   137,   157,   227,   140,    98,
     227,   143,   229,   215,   227,   104,   105,   227,   107,   173,
     174,   227,   173,   174,   186,   187,   188,   189,   144,   145,
      54,    55,    56,    57,   186,   187,   188,   189,    62,   156,
      64,   310,   311,    67,   313,   314,   227,   227,   229,   192,
     227,     0,   229,   192,   227,   227,   229,   229,   209,   227,
     192,   229,   228,   227,   266,   229,   268,    41,    42,   310,
     311,   192,   231,   230,   228,   313,   314,   227,   227,   206,
     173,   208,   229,   210,   229,   212,   227,   187,   230,   227,
     227,   218,   213,   214,   215,   216,   217,   218,   219,   220,
     228,   222,   223,   224,   225,   226,   228,   227,   130,   227,
     195,   140,   227,   315,   227,   227,   227,   227,   227,   227,
     227,   227,   146,   228,   228,   228,   228,   228,   104,   134,
     228,   228,   228,   228,   187,   229,   192,   228,   230,   341,
     228,   228,   269,   270,   363,   364,   365,   228,   172,   228,
     228,   228,   371,   372,   228,   228,   228,   228,   228,   276,
     228,   228,   279,   229,   227,   227,   230,   228,   228,   228,
     227,   288,   230,   290,   301,   394,   395,   396,   397,   306,
     230,   228,   230,   228,   230,   228,   230,   227,   230,   227,
     229,   227,   229,   228,   228,   137,   323,   230,   230,   318,
     228,   228,   228,   228,   143,   155,   227,   230,   228,   228,
     227,   227,   227,   227,   227,   227,   227,   227,   227,   227,
      36,   227,   339,   230,   227,   227,   227,   373,   228,   228,
     228,   228,   228,   228,   228,   228,   228,   228,   228,   228,
     228,   368,   369,   370,   228,   228,   221,   298,   323,   172,
      -1,   306,   317,   367,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   355
};

/* YYSTOS[STATE-NUM] -- The symbol kind of the accessing symbol of
   state STATE-NUM.  */
static const yytype_int16 yystos[] =
{
       0,    62,   192,   213,   214,   215,   216,   217,   218,   219,
     220,   222,   223,   224,   225,   226,   234,   235,   236,   295,
     229,   227,   227,   227,   227,   227,   241,   227,   227,   227,
     227,   227,   227,   240,     0,    58,    63,   296,   297,   298,
     231,   321,   321,   297,   306,   307,   306,   306,   246,   306,
     227,   186,   189,   308,   308,   306,   306,   306,   306,   227,
     308,   317,   317,   321,   321,   235,   235,   230,   243,   186,
     187,   188,   304,   305,   308,   244,   245,   173,   221,   252,
     253,   329,   238,    68,   116,   117,   132,   134,   135,   157,
     174,   209,   259,   260,   325,   328,   329,   308,   306,   248,
     249,   247,   239,   269,   270,   329,   229,   229,   297,   250,
     251,   329,   227,   250,   252,   227,   227,   228,   252,   259,
     227,   227,   227,   227,   227,   227,   227,   227,   227,   228,
     259,   242,   237,   263,   264,   329,   265,   266,   329,   261,
     262,   329,   267,   268,   329,   228,   269,    54,    55,    56,
      57,    64,    67,   146,   172,   289,   290,   291,   295,   299,
     300,   301,   301,   228,   250,   187,   188,   308,   316,   228,
     228,   330,   308,   319,   320,   228,   175,   176,   187,   309,
     310,   308,   187,   312,   313,   308,   308,   308,   310,   308,
     308,   257,   258,   329,   254,   255,   256,   328,   228,   263,
     228,   265,   228,   261,   228,   267,   227,   229,   227,   229,
     227,   229,   227,   229,   227,   229,   229,   227,   227,   229,
     296,   321,    65,    66,   230,   230,   228,   228,   320,   228,
     228,   228,   228,   228,   228,   228,   228,   228,   228,   228,
     257,   228,   254,    82,   130,   326,   308,   271,   333,   308,
     280,   308,   283,   308,   285,   331,   280,   301,   281,   335,
     292,   308,   284,   130,   302,   289,   229,   227,   229,   227,
     227,   228,   230,    68,   192,   272,   273,   274,   275,   298,
     228,   230,   228,   230,   228,   230,   192,   286,   287,   288,
     298,   228,   230,   230,   282,   144,   145,   293,   294,   228,
     230,   227,   301,   280,   301,   308,   308,   327,   227,   334,
     321,   321,   332,   321,   321,   229,   336,   227,   227,   228,
     293,   303,   308,   318,   230,   228,   230,   228,   327,   228,
     276,   277,   272,   272,   286,   286,   301,   313,   306,   228,
     303,   229,   228,    97,    99,   103,   118,   120,   121,   122,
     123,   128,   129,   170,   278,   279,   322,   323,   230,   228,
     228,   321,   301,   227,   227,   227,   227,   227,   227,   227,
     227,   227,   227,   227,   278,    98,   104,   105,   107,   324,
     230,   310,   310,   310,   187,   314,   315,   315,   308,   308,
     308,   310,   310,   319,   227,   227,   227,   227,   228,   228,
     228,   228,   228,   228,   228,   228,   228,   228,   228,   310,
     112,   310,   311,   310,   310,   228,   228,   228,   228
};

/* YYR1[RULE-NUM] -- Symbol kind of the left-hand side of rule RULE-NUM.  */
static const yytype_int16 yyr1[] =
{
       0,   233,   234,   235,   235,   235,   237,   236,   238,   236,
     239,   236,   240,   236,   241,   236,   242,   236,   243,   236,
     244,   236,   245,   236,   246,   236,   247,   236,   248,   236,
     249,   236,   236,   250,   250,   251,   252,   252,   253,   253,
     254,   254,   256,   255,   255,   257,   257,   258,   259,   259,
     260,   260,   261,   261,   262,   263,   263,   264,   265,   265,
     266,   267,   267,   268,   269,   269,   270,   271,   272,   272,
     272,   273,   273,   274,   275,   277,   276,   278,   278,   279,
     279,   280,   282,   281,   283,   284,   285,   286,   286,   286,
     287,   288,   289,   289,   290,   290,   290,   290,   290,   290,
     290,   290,   290,   290,   290,   290,   290,   290,   292,   291,
     293,   293,   294,   294,   295,   296,   297,   297,   298,   298,
     299,   299,   300,   300,   300,   300,   301,   302,   302,   303,
     303,   304,   304,   304,   304,   305,   307,   306,   308,   308,
     309,   309,   310,   310,   311,   311,   312,   313,   314,   315,
     316,   316,   316,   317,   317,   318,   319,   320,   320,   321,
     321,   322,   322,   322,   322,   322,   322,   322,   322,   322,
     322,   323,   322,   324,   324,   324,   324,   325,   325,   325,
     325,   325,   325,   325,   326,   326,   327,   327,   328,   328,
     328,   330,   329,   331,   332,   333,   334,   335,   336
};

/* YYR2[RULE-NUM] -- Number of symbols on the right-hand side of rule RULE-NUM.  */
static const yytype_int8 yyr2[] =
{
       0,     2,     2,     3,     3,     0,     0,     7,     0,     6,
       0,     6,     0,     5,     0,     5,     0,     7,     0,     6,
       0,     6,     0,     6,     0,     5,     0,     6,     0,     6,
       0,     6,     1,     2,     0,     1,     2,     0,     4,     1,
       2,     0,     0,     2,     1,     2,     0,     1,     2,     0,
       1,     1,     2,     0,     1,     2,     0,     1,     2,     0,
       1,     2,     0,     1,     2,     0,     1,     3,     3,     3,
       0,     1,     1,     1,     4,     0,     2,     2,     0,     4,
       1,     0,     0,     3,     0,     0,     3,     3,     3,     0,
       1,     1,     3,     0,     4,     4,     4,     4,     4,     4,
       4,     4,     4,     4,     4,     1,     1,     1,     0,     5,
       2,     0,     4,     4,     4,     1,     3,     0,     5,     5,
       1,     5,     7,     4,     8,     5,     3,     5,     0,     2,
       0,     1,     4,     1,     1,     1,     0,     2,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     0,     1,     1,     2,     0,     1,
       2,     4,     4,     4,     4,     4,     4,     4,     4,     4,
       4,     0,     2,     4,     4,     4,     4,     4,     4,     4,
       4,     4,     4,     4,     4,     4,     2,     0,     4,     4,
       1,     0,     4,     0,     0,     0,     0,     0,     0
};


enum { YYENOMEM = -2 };

#define yyerrok         (yyerrstatus = 0)
#define yyclearin       (yychar = REWRITE_EXPR_EMPTY)

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab
#define YYNOMEM         goto yyexhaustedlab


#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)                                    \
  do                                                              \
    if (yychar == REWRITE_EXPR_EMPTY)                                        \
      {                                                           \
        yychar = (Token);                                         \
        yylval = (Value);                                         \
        YYPOPSTACK (yylen);                                       \
        yystate = *yyssp;                                         \
        goto yybackup;                                            \
      }                                                           \
    else                                                          \
      {                                                           \
        yyerror (&yylloc, lexer, result, arg, YY_("syntax error: cannot back up")); \
        YYERROR;                                                  \
      }                                                           \
  while (0)

/* Backward compatibility with an undocumented macro.
   Use REWRITE_EXPR_error or REWRITE_EXPR_UNDEF. */
#define YYERRCODE REWRITE_EXPR_UNDEF

/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)                                \
    do                                                                  \
      if (N)                                                            \
        {                                                               \
          (Current).first_line   = YYRHSLOC (Rhs, 1).first_line;        \
          (Current).first_column = YYRHSLOC (Rhs, 1).first_column;      \
          (Current).last_line    = YYRHSLOC (Rhs, N).last_line;         \
          (Current).last_column  = YYRHSLOC (Rhs, N).last_column;       \
        }                                                               \
      else                                                              \
        {                                                               \
          (Current).first_line   = (Current).last_line   =              \
            YYRHSLOC (Rhs, 0).last_line;                                \
          (Current).first_column = (Current).last_column =              \
            YYRHSLOC (Rhs, 0).last_column;                              \
        }                                                               \
    while (0)
#endif

#define YYRHSLOC(Rhs, K) ((Rhs)[K])


/* Enable debugging if requested.  */
#if REWRITE_EXPR_DEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)                        \
do {                                            \
  if (yydebug)                                  \
    YYFPRINTF Args;                             \
} while (0)


/* YYLOCATION_PRINT -- Print the location on the stream.
   This macro was not mandated originally: define only if we know
   we won't break user code: when these are the locations we know.  */

# ifndef YYLOCATION_PRINT

#  if defined YY_LOCATION_PRINT

   /* Temporary convenience wrapper in case some people defined the
      undocumented and private YY_LOCATION_PRINT macros.  */
#   define YYLOCATION_PRINT(File, Loc)  YY_LOCATION_PRINT(File, *(Loc))

#  elif defined REWRITE_EXPR_LTYPE_IS_TRIVIAL && REWRITE_EXPR_LTYPE_IS_TRIVIAL

/* Print *YYLOCP on YYO.  Private, do not rely on its existence. */

YY_ATTRIBUTE_UNUSED
static int
yy_location_print_ (FILE *yyo, YYLTYPE const * const yylocp)
{
  int res = 0;
  int end_col = 0 != yylocp->last_column ? yylocp->last_column - 1 : 0;
  if (0 <= yylocp->first_line)
    {
      res += YYFPRINTF (yyo, "%d", yylocp->first_line);
      if (0 <= yylocp->first_column)
        res += YYFPRINTF (yyo, ".%d", yylocp->first_column);
    }
  if (0 <= yylocp->last_line)
    {
      if (yylocp->first_line < yylocp->last_line)
        {
          res += YYFPRINTF (yyo, "-%d", yylocp->last_line);
          if (0 <= end_col)
            res += YYFPRINTF (yyo, ".%d", end_col);
        }
      else if (0 <= end_col && yylocp->first_column < end_col)
        res += YYFPRINTF (yyo, "-%d", end_col);
    }
  return res;
}

#   define YYLOCATION_PRINT  yy_location_print_

    /* Temporary convenience wrapper in case some people defined the
       undocumented and private YY_LOCATION_PRINT macros.  */
#   define YY_LOCATION_PRINT(File, Loc)  YYLOCATION_PRINT(File, &(Loc))

#  else

#   define YYLOCATION_PRINT(File, Loc) ((void) 0)
    /* Temporary convenience wrapper in case some people defined the
       undocumented and private YY_LOCATION_PRINT macros.  */
#   define YY_LOCATION_PRINT  YYLOCATION_PRINT

#  endif
# endif /* !defined YYLOCATION_PRINT */


# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)                    \
do {                                                                      \
  if (yydebug)                                                            \
    {                                                                     \
      YYFPRINTF (stderr, "%s ", Title);                                   \
      yy_symbol_print (stderr,                                            \
                  Kind, Value, Location, lexer, result, arg); \
      YYFPRINTF (stderr, "\n");                                           \
    }                                                                     \
} while (0)


/*-----------------------------------.
| Print this symbol's value on YYO.  |
`-----------------------------------*/

static void
yy_symbol_value_print (FILE *yyo,
                       yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep, YYLTYPE const * const yylocationp, CfgLexer *lexer, LogExprNode **result, gpointer arg)
{
  FILE *yyoutput = yyo;
  YY_USE (yyoutput);
  YY_USE (yylocationp);
  YY_USE (lexer);
  YY_USE (result);
  YY_USE (arg);
  if (!yyvaluep)
    return;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YY_USE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}


/*---------------------------.
| Print this symbol on YYO.  |
`---------------------------*/

static void
yy_symbol_print (FILE *yyo,
                 yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep, YYLTYPE const * const yylocationp, CfgLexer *lexer, LogExprNode **result, gpointer arg)
{
  YYFPRINTF (yyo, "%s %s (",
             yykind < YYNTOKENS ? "token" : "nterm", yysymbol_name (yykind));

  YYLOCATION_PRINT (yyo, yylocationp);
  YYFPRINTF (yyo, ": ");
  yy_symbol_value_print (yyo, yykind, yyvaluep, yylocationp, lexer, result, arg);
  YYFPRINTF (yyo, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

static void
yy_stack_print (yy_state_t *yybottom, yy_state_t *yytop)
{
  YYFPRINTF (stderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (stderr, " %d", yybot);
    }
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)                            \
do {                                                            \
  if (yydebug)                                                  \
    yy_stack_print ((Bottom), (Top));                           \
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

static void
yy_reduce_print (yy_state_t *yyssp, YYSTYPE *yyvsp, YYLTYPE *yylsp,
                 int yyrule, CfgLexer *lexer, LogExprNode **result, gpointer arg)
{
  int yylno = yyrline[yyrule];
  int yynrhs = yyr2[yyrule];
  int yyi;
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %d):\n",
             yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr,
                       YY_ACCESSING_SYMBOL (+yyssp[yyi + 1 - yynrhs]),
                       &yyvsp[(yyi + 1) - (yynrhs)],
                       &(yylsp[(yyi + 1) - (yynrhs)]), lexer, result, arg);
      YYFPRINTF (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)          \
do {                                    \
  if (yydebug)                          \
    yy_reduce_print (yyssp, yyvsp, yylsp, Rule, lexer, result, arg); \
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !REWRITE_EXPR_DEBUG */
# define YYDPRINTF(Args) ((void) 0)
# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !REWRITE_EXPR_DEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif


/* Context of a parse error.  */
typedef struct
{
  yy_state_t *yyssp;
  yysymbol_kind_t yytoken;
  YYLTYPE *yylloc;
} yypcontext_t;

/* Put in YYARG at most YYARGN of the expected tokens given the
   current YYCTX, and return the number of tokens stored in YYARG.  If
   YYARG is null, return the number of expected tokens (guaranteed to
   be less than YYNTOKENS).  Return YYENOMEM on memory exhaustion.
   Return 0 if there are more than YYARGN expected tokens, yet fill
   YYARG up to YYARGN. */
static int
yypcontext_expected_tokens (const yypcontext_t *yyctx,
                            yysymbol_kind_t yyarg[], int yyargn)
{
  /* Actual size of YYARG. */
  int yycount = 0;
  int yyn = yypact[+*yyctx->yyssp];
  if (!yypact_value_is_default (yyn))
    {
      /* Start YYX at -YYN if negative to avoid negative indexes in
         YYCHECK.  In other words, skip the first -YYN actions for
         this state because they are default actions.  */
      int yyxbegin = yyn < 0 ? -yyn : 0;
      /* Stay within bounds of both yycheck and yytname.  */
      int yychecklim = YYLAST - yyn + 1;
      int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
      int yyx;
      for (yyx = yyxbegin; yyx < yyxend; ++yyx)
        if (yycheck[yyx + yyn] == yyx && yyx != YYSYMBOL_YYerror
            && !yytable_value_is_error (yytable[yyx + yyn]))
          {
            if (!yyarg)
              ++yycount;
            else if (yycount == yyargn)
              return 0;
            else
              yyarg[yycount++] = YY_CAST (yysymbol_kind_t, yyx);
          }
    }
  if (yyarg && yycount == 0 && 0 < yyargn)
    yyarg[0] = YYSYMBOL_YYEMPTY;
  return yycount;
}




#ifndef yystrlen
# if defined __GLIBC__ && defined _STRING_H
#  define yystrlen(S) (YY_CAST (YYPTRDIFF_T, strlen (S)))
# else
/* Return the length of YYSTR.  */
static YYPTRDIFF_T
yystrlen (const char *yystr)
{
  YYPTRDIFF_T yylen;
  for (yylen = 0; yystr[yylen]; yylen++)
    continue;
  return yylen;
}
# endif
#endif

#ifndef yystpcpy
# if defined __GLIBC__ && defined _STRING_H && defined _GNU_SOURCE
#  define yystpcpy stpcpy
# else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
static char *
yystpcpy (char *yydest, const char *yysrc)
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
# endif
#endif

#ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYPTRDIFF_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      YYPTRDIFF_T yyn = 0;
      char const *yyp = yystr;
      for (;;)
        switch (*++yyp)
          {
          case '\'':
          case ',':
            goto do_not_strip_quotes;

          case '\\':
            if (*++yyp != '\\')
              goto do_not_strip_quotes;
            else
              goto append;

          append:
          default:
            if (yyres)
              yyres[yyn] = *yyp;
            yyn++;
            break;

          case '"':
            if (yyres)
              yyres[yyn] = '\0';
            return yyn;
          }
    do_not_strip_quotes: ;
    }

  if (yyres)
    return yystpcpy (yyres, yystr) - yyres;
  else
    return yystrlen (yystr);
}
#endif


static int
yy_syntax_error_arguments (const yypcontext_t *yyctx,
                           yysymbol_kind_t yyarg[], int yyargn)
{
  /* Actual size of YYARG. */
  int yycount = 0;
  /* There are many possibilities here to consider:
     - If this state is a consistent state with a default action, then
       the only way this function was invoked is if the default action
       is an error action.  In that case, don't check for expected
       tokens because there are none.
     - The only way there can be no lookahead present (in yychar) is if
       this state is a consistent state with a default action.  Thus,
       detecting the absence of a lookahead is sufficient to determine
       that there is no unexpected or expected token to report.  In that
       case, just report a simple "syntax error".
     - Don't assume there isn't a lookahead just because this state is a
       consistent state with a default action.  There might have been a
       previous inconsistent state, consistent state with a non-default
       action, or user semantic action that manipulated yychar.
     - Of course, the expected token list depends on states to have
       correct lookahead information, and it depends on the parser not
       to perform extra reductions after fetching a lookahead from the
       scanner and before detecting a syntax error.  Thus, state merging
       (from LALR or IELR) and default reductions corrupt the expected
       token list.  However, the list is correct for canonical LR with
       one exception: it will still contain any token that will not be
       accepted due to an error action in a later state.
  */
  if (yyctx->yytoken != YYSYMBOL_YYEMPTY)
    {
      int yyn;
      if (yyarg)
        yyarg[yycount] = yyctx->yytoken;
      ++yycount;
      yyn = yypcontext_expected_tokens (yyctx,
                                        yyarg ? yyarg + 1 : yyarg, yyargn - 1);
      if (yyn == YYENOMEM)
        return YYENOMEM;
      else
        yycount += yyn;
    }
  return yycount;
}

/* Copy into *YYMSG, which is of size *YYMSG_ALLOC, an error message
   about the unexpected token YYTOKEN for the state stack whose top is
   YYSSP.

   Return 0 if *YYMSG was successfully written.  Return -1 if *YYMSG is
   not large enough to hold the message.  In that case, also set
   *YYMSG_ALLOC to the required number of bytes.  Return YYENOMEM if the
   required number of bytes is too large to store.  */
static int
yysyntax_error (YYPTRDIFF_T *yymsg_alloc, char **yymsg,
                const yypcontext_t *yyctx)
{
  enum { YYARGS_MAX = 5 };
  /* Internationalized format string. */
  const char *yyformat = YY_NULLPTR;
  /* Arguments of yyformat: reported tokens (one for the "unexpected",
     one per "expected"). */
  yysymbol_kind_t yyarg[YYARGS_MAX];
  /* Cumulated lengths of YYARG.  */
  YYPTRDIFF_T yysize = 0;

  /* Actual size of YYARG. */
  int yycount = yy_syntax_error_arguments (yyctx, yyarg, YYARGS_MAX);
  if (yycount == YYENOMEM)
    return YYENOMEM;

  switch (yycount)
    {
#define YYCASE_(N, S)                       \
      case N:                               \
        yyformat = S;                       \
        break
    default: /* Avoid compiler warnings. */
      YYCASE_(0, YY_("syntax error"));
      YYCASE_(1, YY_("syntax error, unexpected %s"));
      YYCASE_(2, YY_("syntax error, unexpected %s, expecting %s"));
      YYCASE_(3, YY_("syntax error, unexpected %s, expecting %s or %s"));
      YYCASE_(4, YY_("syntax error, unexpected %s, expecting %s or %s or %s"));
      YYCASE_(5, YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s"));
#undef YYCASE_
    }

  /* Compute error message size.  Don't count the "%s"s, but reserve
     room for the terminator.  */
  yysize = yystrlen (yyformat) - 2 * yycount + 1;
  {
    int yyi;
    for (yyi = 0; yyi < yycount; ++yyi)
      {
        YYPTRDIFF_T yysize1
          = yysize + yytnamerr (YY_NULLPTR, yytname[yyarg[yyi]]);
        if (yysize <= yysize1 && yysize1 <= YYSTACK_ALLOC_MAXIMUM)
          yysize = yysize1;
        else
          return YYENOMEM;
      }
  }

  if (*yymsg_alloc < yysize)
    {
      *yymsg_alloc = 2 * yysize;
      if (! (yysize <= *yymsg_alloc
             && *yymsg_alloc <= YYSTACK_ALLOC_MAXIMUM))
        *yymsg_alloc = YYSTACK_ALLOC_MAXIMUM;
      return -1;
    }

  /* Avoid sprintf, as that infringes on the user's name space.
     Don't have undefined behavior even if the translation
     produced a string with the wrong number of "%s"s.  */
  {
    char *yyp = *yymsg;
    int yyi = 0;
    while ((*yyp = *yyformat) != '\0')
      if (*yyp == '%' && yyformat[1] == 's' && yyi < yycount)
        {
          yyp += yytnamerr (yyp, yytname[yyarg[yyi++]]);
          yyformat += 2;
        }
      else
        {
          ++yyp;
          ++yyformat;
        }
  }
  return 0;
}


/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

static void
yydestruct (const char *yymsg,
            yysymbol_kind_t yykind, YYSTYPE *yyvaluep, YYLTYPE *yylocationp, CfgLexer *lexer, LogExprNode **result, gpointer arg)
{
  YY_USE (yyvaluep);
  YY_USE (yylocationp);
  YY_USE (lexer);
  YY_USE (result);
  YY_USE (arg);
  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yykind, yyvaluep, yylocationp);

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  switch (yykind)
    {
    case YYSYMBOL_LL_IDENTIFIER: /* LL_IDENTIFIER  */
#line 375 "lib/rewrite/rewrite-expr-grammar.y"
            { free(((*yyvaluep).cptr)); }
#line 3465 "lib/rewrite/rewrite-expr-grammar.c"
        break;

    case YYSYMBOL_LL_STRING: /* LL_STRING  */
#line 375 "lib/rewrite/rewrite-expr-grammar.y"
            { free(((*yyvaluep).cptr)); }
#line 3471 "lib/rewrite/rewrite-expr-grammar.c"
        break;

    case YYSYMBOL_LL_BLOCK: /* LL_BLOCK  */
#line 375 "lib/rewrite/rewrite-expr-grammar.y"
            { free(((*yyvaluep).cptr)); }
#line 3477 "lib/rewrite/rewrite-expr-grammar.c"
        break;

    case YYSYMBOL_LL_PLUGIN: /* LL_PLUGIN  */
#line 375 "lib/rewrite/rewrite-expr-grammar.y"
            { free(((*yyvaluep).cptr)); }
#line 3483 "lib/rewrite/rewrite-expr-grammar.c"
        break;

    case YYSYMBOL_LL_TEMPLATE_REF: /* LL_TEMPLATE_REF  */
#line 375 "lib/rewrite/rewrite-expr-grammar.y"
            { free(((*yyvaluep).cptr)); }
#line 3489 "lib/rewrite/rewrite-expr-grammar.c"
        break;

    case YYSYMBOL_LL_MESSAGE_REF: /* LL_MESSAGE_REF  */
#line 375 "lib/rewrite/rewrite-expr-grammar.y"
            { free(((*yyvaluep).cptr)); }
#line 3495 "lib/rewrite/rewrite-expr-grammar.c"
        break;

    case YYSYMBOL_string: /* string  */
#line 375 "lib/rewrite/rewrite-expr-grammar.y"
            { free(((*yyvaluep).cptr)); }
#line 3501 "lib/rewrite/rewrite-expr-grammar.c"
        break;

    case YYSYMBOL_string_or_number: /* string_or_number  */
#line 375 "lib/rewrite/rewrite-expr-grammar.y"
            { free(((*yyvaluep).cptr)); }
#line 3507 "lib/rewrite/rewrite-expr-grammar.c"
        break;

    case YYSYMBOL_optional_string: /* optional_string  */
#line 375 "lib/rewrite/rewrite-expr-grammar.y"
            { free(((*yyvaluep).cptr)); }
#line 3513 "lib/rewrite/rewrite-expr-grammar.c"
        break;

    case YYSYMBOL_normalized_flag: /* normalized_flag  */
#line 375 "lib/rewrite/rewrite-expr-grammar.y"
            { free(((*yyvaluep).cptr)); }
#line 3519 "lib/rewrite/rewrite-expr-grammar.c"
        break;

      default:
        break;
    }
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}






/*----------.
| yyparse.  |
`----------*/

int
yyparse (CfgLexer *lexer, LogExprNode **result, gpointer arg)
{
/* Lookahead token kind.  */
int yychar;


/* The semantic value of the lookahead symbol.  */
/* Default value used for initialization, for pacifying older GCCs
   or non-GCC compilers.  */
YY_INITIAL_VALUE (static YYSTYPE yyval_default;)
YYSTYPE yylval YY_INITIAL_VALUE (= yyval_default);

/* Location data for the lookahead symbol.  */
static YYLTYPE yyloc_default
# if defined REWRITE_EXPR_LTYPE_IS_TRIVIAL && REWRITE_EXPR_LTYPE_IS_TRIVIAL
  = { 1, 1, 1, 1 }
# endif
;
YYLTYPE yylloc = yyloc_default;

    /* Number of syntax errors so far.  */
    int yynerrs = 0;

    yy_state_fast_t yystate = 0;
    /* Number of tokens to shift before error messages enabled.  */
    int yyerrstatus = 0;

    /* Refer to the stacks through separate pointers, to allow yyoverflow
       to reallocate them elsewhere.  */

    /* Their size.  */
    YYPTRDIFF_T yystacksize = YYINITDEPTH;

    /* The state stack: array, bottom, top.  */
    yy_state_t yyssa[YYINITDEPTH];
    yy_state_t *yyss = yyssa;
    yy_state_t *yyssp = yyss;

    /* The semantic value stack: array, bottom, top.  */
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs = yyvsa;
    YYSTYPE *yyvsp = yyvs;

    /* The location stack: array, bottom, top.  */
    YYLTYPE yylsa[YYINITDEPTH];
    YYLTYPE *yyls = yylsa;
    YYLTYPE *yylsp = yyls;

  int yyn;
  /* The return value of yyparse.  */
  int yyresult;
  /* Lookahead symbol kind.  */
  yysymbol_kind_t yytoken = YYSYMBOL_YYEMPTY;
  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;
  YYLTYPE yyloc;

  /* The locations where the error started and ended.  */
  YYLTYPE yyerror_range[3];

  /* Buffer for error messages, and its allocated size.  */
  char yymsgbuf[128];
  char *yymsg = yymsgbuf;
  YYPTRDIFF_T yymsg_alloc = sizeof yymsgbuf;

#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N), yylsp -= (N))

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yychar = REWRITE_EXPR_EMPTY; /* Cause a token to be read.  */

  yylsp[0] = yylloc;
  goto yysetstate;


/*------------------------------------------------------------.
| yynewstate -- push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;


/*--------------------------------------------------------------------.
| yysetstate -- set current state (the top of the stack) to yystate.  |
`--------------------------------------------------------------------*/
yysetstate:
  YYDPRINTF ((stderr, "Entering state %d\n", yystate));
  YY_ASSERT (0 <= yystate && yystate < YYNSTATES);
  YY_IGNORE_USELESS_CAST_BEGIN
  *yyssp = YY_CAST (yy_state_t, yystate);
  YY_IGNORE_USELESS_CAST_END
  YY_STACK_PRINT (yyss, yyssp);

  if (yyss + yystacksize - 1 <= yyssp)
#if !defined yyoverflow && !defined YYSTACK_RELOCATE
    YYNOMEM;
#else
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYPTRDIFF_T yysize = yyssp - yyss + 1;

# if defined yyoverflow
      {
        /* Give user a chance to reallocate the stack.  Use copies of
           these so that the &'s don't force the real ones into
           memory.  */
        yy_state_t *yyss1 = yyss;
        YYSTYPE *yyvs1 = yyvs;
        YYLTYPE *yyls1 = yyls;

        /* Each stack pointer address is followed by the size of the
           data in use in that stack, in bytes.  This used to be a
           conditional around just the two extra args, but that might
           be undefined if yyoverflow is a macro.  */
        yyoverflow (YY_("memory exhausted"),
                    &yyss1, yysize * YYSIZEOF (*yyssp),
                    &yyvs1, yysize * YYSIZEOF (*yyvsp),
                    &yyls1, yysize * YYSIZEOF (*yylsp),
                    &yystacksize);
        yyss = yyss1;
        yyvs = yyvs1;
        yyls = yyls1;
      }
# else /* defined YYSTACK_RELOCATE */
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
        YYNOMEM;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
        yystacksize = YYMAXDEPTH;

      {
        yy_state_t *yyss1 = yyss;
        union yyalloc *yyptr =
          YY_CAST (union yyalloc *,
                   YYSTACK_ALLOC (YY_CAST (YYSIZE_T, YYSTACK_BYTES (yystacksize))));
        if (! yyptr)
          YYNOMEM;
        YYSTACK_RELOCATE (yyss_alloc, yyss);
        YYSTACK_RELOCATE (yyvs_alloc, yyvs);
        YYSTACK_RELOCATE (yyls_alloc, yyls);
#  undef YYSTACK_RELOCATE
        if (yyss1 != yyssa)
          YYSTACK_FREE (yyss1);
      }
# endif

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;
      yylsp = yyls + yysize - 1;

      YY_IGNORE_USELESS_CAST_BEGIN
      YYDPRINTF ((stderr, "Stack size increased to %ld\n",
                  YY_CAST (long, yystacksize)));
      YY_IGNORE_USELESS_CAST_END

      if (yyss + yystacksize - 1 <= yyssp)
        YYABORT;
    }
#endif /* !defined yyoverflow && !defined YYSTACK_RELOCATE */


  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;


/*-----------.
| yybackup.  |
`-----------*/
yybackup:
  /* Do appropriate processing given the current state.  Read a
     lookahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to lookahead token.  */
  yyn = yypact[yystate];
  if (yypact_value_is_default (yyn))
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either empty, or end-of-input, or a valid lookahead.  */
  if (yychar == REWRITE_EXPR_EMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token\n"));
      yychar = yylex (&yylval, &yylloc, lexer);
    }

  if (yychar <= REWRITE_EXPR_EOF)
    {
      yychar = REWRITE_EXPR_EOF;
      yytoken = YYSYMBOL_YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else if (yychar == REWRITE_EXPR_error)
    {
      /* The scanner already issued an error message, process directly
         to error recovery.  But do not keep the error token as
         lookahead, it is too special and may lead us to an endless
         loop in error recovery. */
      yychar = REWRITE_EXPR_UNDEF;
      yytoken = YYSYMBOL_YYerror;
      yyerror_range[1] = yylloc;
      goto yyerrlab1;
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yytable_value_is_error (yyn))
        goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the lookahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);
  yystate = yyn;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END
  *++yylsp = yylloc;

  /* Discard the shifted token.  */
  yychar = REWRITE_EXPR_EMPTY;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     '$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];

  /* Default location. */
  YYLLOC_DEFAULT (yyloc, (yylsp - yylen), yylen);
  yyerror_range[1] = yyloc;
  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
  case 2: /* start: rewrite_expr_list log_last_junction  */
#line 491 "lib/rewrite/rewrite-expr-grammar.y"
                                                     { *result = log_expr_node_append_tail((yyvsp[-1].ptr), (yyvsp[0].ptr)); if (yychar != REWRITE_EXPR_EMPTY) { cfg_lexer_unput_token(lexer, &yylval); } YYACCEPT; }
#line 3825 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 3: /* rewrite_expr_list: rewrite_expr semicolons rewrite_expr_list  */
#line 495 "lib/rewrite/rewrite-expr-grammar.y"
                                                     { (yyval.ptr) = log_expr_node_append_tail(log_expr_node_new_pipe((yyvsp[-2].ptr), &(yylsp[-2])), (yyvsp[0].ptr)); }
#line 3831 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 4: /* rewrite_expr_list: log_junction semicolons rewrite_expr_list  */
#line 496 "lib/rewrite/rewrite-expr-grammar.y"
                                                         { (yyval.ptr) = log_expr_node_append_tail((yyvsp[-2].ptr),  (yyvsp[0].ptr)); }
#line 3837 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 5: /* rewrite_expr_list: %empty  */
#line 497 "lib/rewrite/rewrite-expr-grammar.y"
                                                    { (yyval.ptr) = NULL; }
#line 3843 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 6: /* $@1: %empty  */
#line 502 "lib/rewrite/rewrite-expr-grammar.y"
          {
            last_rewrite = log_rewrite_subst_new((yyvsp[0].ptr), configuration);
            log_template_unref((yyvsp[0].ptr));
          }
#line 3852 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 7: /* rewrite_expr: KW_SUBST '(' string template_content $@1 rewrite_subst_opts ')'  */
#line 507 "lib/rewrite/rewrite-expr-grammar.y"
          {
            GError *error = NULL;
            CHECK_ERROR_GERROR(log_rewrite_subst_compile_pattern(last_rewrite, (yyvsp[-4].cptr), &error), (yylsp[-4]), error, "error compiling search pattern");
            free((yyvsp[-4].cptr));
            (yyval.ptr) = last_rewrite;
          }
#line 3863 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 8: /* $@2: %empty  */
#line 514 "lib/rewrite/rewrite-expr-grammar.y"
          {
            last_rewrite = log_rewrite_set_new((yyvsp[0].ptr), configuration);
            last_template_options = log_rewrite_set_get_template_options(last_rewrite);
            log_template_unref((yyvsp[0].ptr));
          }
#line 3873 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 9: /* rewrite_expr: KW_SET '(' template_content $@2 rewrite_set_opts ')'  */
#line 519 "lib/rewrite/rewrite-expr-grammar.y"
                                               { (yyval.ptr) = last_rewrite; }
#line 3879 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 10: /* $@3: %empty  */
#line 521 "lib/rewrite/rewrite-expr-grammar.y"
          {
            last_rewrite = log_rewrite_set_matches_new((yyvsp[0].ptr), configuration);
            last_template_options = log_rewrite_set_get_template_options(last_rewrite);
            log_template_unref((yyvsp[0].ptr));
          }
#line 3889 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 11: /* rewrite_expr: KW_SET_MATCHES '(' template_content $@3 rewrite_set_matches_opts ')'  */
#line 526 "lib/rewrite/rewrite-expr-grammar.y"
                                               { (yyval.ptr) = last_rewrite; }
#line 3895 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 12: /* $@4: %empty  */
#line 528 "lib/rewrite/rewrite-expr-grammar.y"
          {
            last_rewrite = log_rewrite_unset_matches_new(configuration);
          }
#line 3903 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 13: /* rewrite_expr: KW_UNSET_MATCHES $@4 '(' rewrite_unset_matches_opts ')'  */
#line 531 "lib/rewrite/rewrite-expr-grammar.y"
                                                          { (yyval.ptr) = last_rewrite; }
#line 3909 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 14: /* $@5: %empty  */
#line 533 "lib/rewrite/rewrite-expr-grammar.y"
          {
            last_rewrite = log_rewrite_unset_new(configuration);
          }
#line 3917 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 15: /* rewrite_expr: KW_UNSET $@5 '(' rewrite_set_opts ')'  */
#line 536 "lib/rewrite/rewrite-expr-grammar.y"
                                                { (yyval.ptr) = last_rewrite; }
#line 3923 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 16: /* $@6: %empty  */
#line 538 "lib/rewrite/rewrite-expr-grammar.y"
          {
            NVHandle from = log_msg_get_value_handle((yyvsp[-1].cptr));
            NVHandle to = log_msg_get_value_handle((yyvsp[0].cptr));
            free((yyvsp[-1].cptr));
            free((yyvsp[0].cptr));

            last_rewrite = log_rewrite_rename_new(configuration, from, to);
          }
#line 3936 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 17: /* rewrite_expr: KW_RENAME '(' string string $@6 rewrite_rename_opts ')'  */
#line 546 "lib/rewrite/rewrite-expr-grammar.y"
                                               { (yyval.ptr) = last_rewrite; }
#line 3942 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 18: /* $@7: %empty  */
#line 548 "lib/rewrite/rewrite-expr-grammar.y"
          { 
	    last_rewrite = log_rewrite_set_tag_new((yyvsp[0].ptr), TRUE, configuration);
            log_template_unref((yyvsp[0].ptr));
          }
#line 3951 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 19: /* rewrite_expr: KW_SET_TAG '(' template_content $@7 rewrite_settag_opts ')'  */
#line 552 "lib/rewrite/rewrite-expr-grammar.y"
                                                { (yyval.ptr) = last_rewrite; }
#line 3957 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 20: /* $@8: %empty  */
#line 554 "lib/rewrite/rewrite-expr-grammar.y"
          {
            last_rewrite = log_rewrite_set_tag_new((yyvsp[0].ptr), FALSE, configuration);
            log_template_unref((yyvsp[0].ptr));
          }
#line 3966 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 21: /* rewrite_expr: KW_CLEAR_TAG '(' template_content $@8 rewrite_settag_opts ')'  */
#line 558 "lib/rewrite/rewrite-expr-grammar.y"
                                                { (yyval.ptr) = last_rewrite; }
#line 3972 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 22: /* $@9: %empty  */
#line 560 "lib/rewrite/rewrite-expr-grammar.y"
          {
            last_rewrite = log_rewrite_groupset_new((yyvsp[0].ptr), configuration);
            log_template_unref((yyvsp[0].ptr));
          }
#line 3981 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 23: /* rewrite_expr: KW_GROUP_SET '(' template_content $@9 rewrite_groupset_opts ')'  */
#line 564 "lib/rewrite/rewrite-expr-grammar.y"
                                                { (yyval.ptr) = last_rewrite; }
#line 3987 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 24: /* $@10: %empty  */
#line 566 "lib/rewrite/rewrite-expr-grammar.y"
          {
            last_rewrite = log_rewrite_groupunset_new(configuration);
          }
#line 3995 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 25: /* rewrite_expr: KW_GROUP_UNSET '(' $@10 rewrite_groupset_opts ')'  */
#line 569 "lib/rewrite/rewrite-expr-grammar.y"
                                                { (yyval.ptr) = last_rewrite; }
#line 4001 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 26: /* $@11: %empty  */
#line 571 "lib/rewrite/rewrite-expr-grammar.y"
          {
            last_rewrite = log_rewrite_set_pri_new((yyvsp[0].ptr), configuration);
            log_template_unref((yyvsp[0].ptr));
          }
#line 4010 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 27: /* rewrite_expr: KW_SET_PRI '(' template_content $@11 rewrite_set_pri_opts ')'  */
#line 574 "lib/rewrite/rewrite-expr-grammar.y"
                                                { (yyval.ptr) = last_rewrite; }
#line 4016 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 28: /* $@12: %empty  */
#line 576 "lib/rewrite/rewrite-expr-grammar.y"
          {
            last_rewrite = log_rewrite_set_severity_new((yyvsp[0].ptr), configuration);
            log_template_unref((yyvsp[0].ptr));
          }
#line 4025 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 29: /* rewrite_expr: KW_SET_SEVERITY '(' template_content $@12 rewrite_set_severity_opts ')'  */
#line 579 "lib/rewrite/rewrite-expr-grammar.y"
                                                { (yyval.ptr) = last_rewrite; }
#line 4031 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 30: /* $@13: %empty  */
#line 581 "lib/rewrite/rewrite-expr-grammar.y"
          {
            last_rewrite = log_rewrite_set_facility_new((yyvsp[0].ptr), configuration);
            log_template_unref((yyvsp[0].ptr));
          }
#line 4040 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 31: /* rewrite_expr: KW_SET_FACILITY '(' template_content $@13 rewrite_set_facility_opts ')'  */
#line 584 "lib/rewrite/rewrite-expr-grammar.y"
                                                { (yyval.ptr) = last_rewrite; }
#line 4046 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 32: /* rewrite_expr: LL_PLUGIN  */
#line 586 "lib/rewrite/rewrite-expr-grammar.y"
          {
            Plugin *p;
            gint context = LL_CONTEXT_REWRITE;

            p = cfg_find_plugin(configuration, context, (yyvsp[0].cptr));
            CHECK_ERROR(p, (yylsp[0]), "%s plugin %s not found", cfg_lexer_lookup_context_name_by_type(context), (yyvsp[0].cptr));

            last_rewrite = (LogRewrite *) cfg_parse_plugin(configuration, p, &(yylsp[0]), NULL);
            free((yyvsp[0].cptr));
            if (!last_rewrite)
              {
                YYERROR;
              }
            (yyval.ptr) = last_rewrite;
          }
#line 4066 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 38: /* rewrite_groupset_opt: KW_VALUES '(' string_list ')'  */
#line 619 "lib/rewrite/rewrite-expr-grammar.y"
          {
            log_rewrite_groupset_add_fields(last_rewrite, (yyvsp[-1].ptr));
          }
#line 4074 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 42: /* $@14: %empty  */
#line 631 "lib/rewrite/rewrite-expr-grammar.y"
          { last_matcher_options = log_rewrite_subst_get_matcher_options(last_rewrite); }
#line 4080 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 67: /* source_content: _source_context_push source_items _source_context_pop  */
#line 707 "lib/rewrite/rewrite-expr-grammar.y"
                                                                  { (yyval.ptr) = log_expr_node_new_source_junction((yyvsp[-1].ptr), &(yyloc)); }
#line 4086 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 68: /* source_items: source_item semicolons source_items  */
#line 711 "lib/rewrite/rewrite-expr-grammar.y"
                                                { (yyval.ptr) = log_expr_node_append_tail(log_expr_node_new_pipe((yyvsp[-2].ptr), &(yylsp[-2])), (yyvsp[0].ptr)); }
#line 4092 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 69: /* source_items: log_fork semicolons source_items  */
#line 712 "lib/rewrite/rewrite-expr-grammar.y"
                                                { (yyval.ptr) = log_expr_node_append_tail((yyvsp[-2].ptr),  (yyvsp[0].ptr)); }
#line 4098 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 70: /* source_items: %empty  */
#line 713 "lib/rewrite/rewrite-expr-grammar.y"
                                                { (yyval.ptr) = NULL; }
#line 4104 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 71: /* source_item: source_afinter  */
#line 717 "lib/rewrite/rewrite-expr-grammar.y"
                                                { (yyval.ptr) = (yyvsp[0].ptr); }
#line 4110 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 72: /* source_item: source_plugin  */
#line 718 "lib/rewrite/rewrite-expr-grammar.y"
                                                { (yyval.ptr) = (yyvsp[0].ptr); }
#line 4116 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 73: /* source_plugin: LL_PLUGIN  */
#line 723 "lib/rewrite/rewrite-expr-grammar.y"
          {
            Plugin *p;
            gint context = LL_CONTEXT_SOURCE;

            p = cfg_find_plugin(configuration, context, (yyvsp[0].cptr));
            CHECK_ERROR(p, (yylsp[0]), "%s plugin %s not found", cfg_lexer_lookup_context_name_by_type(context), (yyvsp[0].cptr));

            last_driver = (LogDriver *) cfg_parse_plugin(configuration, p, &(yylsp[0]), NULL);
            free((yyvsp[0].cptr));
            if (!last_driver)
              {
                YYERROR;
              }
            (yyval.ptr) = last_driver;
          }
#line 4136 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 74: /* source_afinter: KW_INTERNAL '(' source_afinter_params ')'  */
#line 741 "lib/rewrite/rewrite-expr-grammar.y"
                                                                        { (yyval.ptr) = (yyvsp[-1].ptr); }
#line 4142 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 75: /* $@15: %empty  */
#line 745 "lib/rewrite/rewrite-expr-grammar.y"
          {
            last_driver = afinter_sd_new(configuration);
            last_source_options = &((AFInterSourceDriver *) last_driver)->source_options.super;
          }
#line 4151 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 76: /* source_afinter_params: $@15 source_afinter_options  */
#line 749 "lib/rewrite/rewrite-expr-grammar.y"
                                 { (yyval.ptr) = last_driver; }
#line 4157 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 79: /* source_afinter_option: KW_LOG_FIFO_SIZE '(' positive_integer ')'  */
#line 758 "lib/rewrite/rewrite-expr-grammar.y"
                                                        { ((AFInterSourceOptions *) last_source_options)->queue_capacity = (yyvsp[-1].num); }
#line 4163 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 81: /* filter_content: %empty  */
#line 764 "lib/rewrite/rewrite-expr-grammar.y"
          {
            FilterExprNode *filter_expr = NULL;

	    CHECK_ERROR_WITHOUT_MESSAGE(cfg_parser_parse(&filter_expr_parser, lexer, (gpointer *) &filter_expr, NULL), (yyloc));

            (yyval.ptr) = log_expr_node_new_pipe(log_filter_pipe_new(filter_expr, configuration), &(yyloc));
	  }
#line 4175 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 82: /* @16: %empty  */
#line 774 "lib/rewrite/rewrite-expr-grammar.y"
                                     {
            GList *filterx_stmts = NULL;

	    CHECK_ERROR_WITHOUT_MESSAGE(cfg_parser_parse(&filterx_parser, lexer, (gpointer *) &filterx_stmts, NULL), (yyloc));

            (yyval.ptr) = log_expr_node_new_pipe(log_filterx_pipe_new(filterx_stmts, configuration), &(yyloc));
	  }
#line 4187 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 83: /* filterx_content: _filterx_context_push @16 _filterx_context_pop  */
#line 780 "lib/rewrite/rewrite-expr-grammar.y"
                                                        { (yyval.ptr) = (yyvsp[-1].ptr); }
#line 4193 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 84: /* parser_content: %empty  */
#line 785 "lib/rewrite/rewrite-expr-grammar.y"
          {
            LogExprNode *last_parser_expr = NULL;

            CHECK_ERROR_WITHOUT_MESSAGE(cfg_parser_parse(&parser_expr_parser, lexer, (gpointer *) &last_parser_expr, NULL), (yyloc));
            (yyval.ptr) = last_parser_expr;
          }
#line 4204 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 85: /* rewrite_content: %empty  */
#line 795 "lib/rewrite/rewrite-expr-grammar.y"
          {
            LogExprNode *last_rewrite_expr = NULL;

            CHECK_ERROR_WITHOUT_MESSAGE(cfg_parser_parse(&rewrite_expr_parser, lexer, (gpointer *) &last_rewrite_expr, NULL), (yyloc));
            (yyval.ptr) = last_rewrite_expr;
          }
#line 4215 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 86: /* dest_content: _destination_context_push dest_items _destination_context_pop  */
#line 804 "lib/rewrite/rewrite-expr-grammar.y"
                                                                                       { (yyval.ptr) = log_expr_node_new_destination_junction((yyvsp[-1].ptr), &(yyloc)); }
#line 4221 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 87: /* dest_items: dest_item semicolons dest_items  */
#line 810 "lib/rewrite/rewrite-expr-grammar.y"
                                                { (yyval.ptr) = log_expr_node_append_tail(log_expr_node_new_pipe((yyvsp[-2].ptr), &(yylsp[-2])), (yyvsp[0].ptr)); }
#line 4227 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 88: /* dest_items: log_fork semicolons dest_items  */
#line 811 "lib/rewrite/rewrite-expr-grammar.y"
                                                { (yyval.ptr) = log_expr_node_append_tail((yyvsp[-2].ptr),  (yyvsp[0].ptr)); }
#line 4233 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 89: /* dest_items: %empty  */
#line 812 "lib/rewrite/rewrite-expr-grammar.y"
                                                { (yyval.ptr) = NULL; }
#line 4239 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 90: /* dest_item: dest_plugin  */
#line 816 "lib/rewrite/rewrite-expr-grammar.y"
                                                { (yyval.ptr) = (yyvsp[0].ptr); }
#line 4245 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 91: /* dest_plugin: LL_PLUGIN  */
#line 821 "lib/rewrite/rewrite-expr-grammar.y"
          {
            Plugin *p;
            gint context = LL_CONTEXT_DESTINATION;

            p = cfg_find_plugin(configuration, context, (yyvsp[0].cptr));
            CHECK_ERROR(p, (yylsp[0]), "%s plugin %s not found", cfg_lexer_lookup_context_name_by_type(context), (yyvsp[0].cptr));

            last_driver = (LogDriver *) cfg_parse_plugin(configuration, p, &(yylsp[0]), NULL);
            free((yyvsp[0].cptr));
            if (!last_driver)
              {
                YYERROR;
              }
            (yyval.ptr) = last_driver;
          }
#line 4265 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 92: /* log_items: log_item semicolons log_items  */
#line 839 "lib/rewrite/rewrite-expr-grammar.y"
                                                { log_expr_node_append_tail((yyvsp[-2].ptr), (yyvsp[0].ptr)); (yyval.ptr) = (yyvsp[-2].ptr); }
#line 4271 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 93: /* log_items: %empty  */
#line 840 "lib/rewrite/rewrite-expr-grammar.y"
                                                { (yyval.ptr) = NULL; }
#line 4277 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 94: /* log_item: KW_SOURCE '(' string ')'  */
#line 844 "lib/rewrite/rewrite-expr-grammar.y"
                                                { (yyval.ptr) = log_expr_node_new_source_reference((yyvsp[-1].cptr), &(yyloc)); free((yyvsp[-1].cptr)); }
#line 4283 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 95: /* log_item: KW_SOURCE '{' source_content '}'  */
#line 845 "lib/rewrite/rewrite-expr-grammar.y"
                                                { (yyval.ptr) = log_expr_node_new_source(NULL, (yyvsp[-1].ptr), &(yyloc)); }
#line 4289 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 96: /* log_item: KW_FILTER '(' string ')'  */
#line 846 "lib/rewrite/rewrite-expr-grammar.y"
                                                { (yyval.ptr) = log_expr_node_new_filter_reference((yyvsp[-1].cptr), &(yyloc)); free((yyvsp[-1].cptr)); }
#line 4295 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 97: /* log_item: KW_FILTER '{' filter_content '}'  */
#line 847 "lib/rewrite/rewrite-expr-grammar.y"
                                                { (yyval.ptr) = log_expr_node_new_filter(NULL, (yyvsp[-1].ptr), &(yyloc)); }
#line 4301 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 98: /* log_item: KW_FILTERX '{' filterx_content '}'  */
#line 848 "lib/rewrite/rewrite-expr-grammar.y"
                                                { (yyval.ptr) = log_expr_node_new_filter(NULL, (yyvsp[-1].ptr), &(yyloc)); }
#line 4307 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 99: /* log_item: KW_PARSER '(' string ')'  */
#line 849 "lib/rewrite/rewrite-expr-grammar.y"
                                                { (yyval.ptr) = log_expr_node_new_parser_reference((yyvsp[-1].cptr), &(yyloc)); free((yyvsp[-1].cptr)); }
#line 4313 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 100: /* log_item: KW_PARSER '{' parser_content '}'  */
#line 850 "lib/rewrite/rewrite-expr-grammar.y"
                                                { (yyval.ptr) = log_expr_node_new_parser(NULL, (yyvsp[-1].ptr), &(yyloc)); }
#line 4319 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 101: /* log_item: KW_REWRITE '(' string ')'  */
#line 851 "lib/rewrite/rewrite-expr-grammar.y"
                                                { (yyval.ptr) = log_expr_node_new_rewrite_reference((yyvsp[-1].cptr), &(yyloc)); free((yyvsp[-1].cptr)); }
#line 4325 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 102: /* log_item: KW_REWRITE '{' rewrite_content '}'  */
#line 852 "lib/rewrite/rewrite-expr-grammar.y"
                                                { (yyval.ptr) = log_expr_node_new_rewrite(NULL, (yyvsp[-1].ptr), &(yyloc)); }
#line 4331 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 103: /* log_item: KW_DESTINATION '(' string ')'  */
#line 853 "lib/rewrite/rewrite-expr-grammar.y"
                                                { (yyval.ptr) = log_expr_node_new_destination_reference((yyvsp[-1].cptr), &(yyloc)); free((yyvsp[-1].cptr)); }
#line 4337 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 104: /* log_item: KW_DESTINATION '{' dest_content '}'  */
#line 854 "lib/rewrite/rewrite-expr-grammar.y"
                                                { (yyval.ptr) = log_expr_node_new_destination(NULL, (yyvsp[-1].ptr), &(yyloc)); }
#line 4343 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 105: /* log_item: log_scheduler  */
#line 855 "lib/rewrite/rewrite-expr-grammar.y"
                                                { (yyval.ptr) = (yyvsp[0].ptr); }
#line 4349 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 106: /* log_item: log_conditional  */
#line 856 "lib/rewrite/rewrite-expr-grammar.y"
                                                { (yyval.ptr) = (yyvsp[0].ptr); }
#line 4355 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 107: /* log_item: log_junction  */
#line 857 "lib/rewrite/rewrite-expr-grammar.y"
                                                { (yyval.ptr) = (yyvsp[0].ptr); }
#line 4361 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 108: /* @17: %empty  */
#line 862 "lib/rewrite/rewrite-expr-grammar.y"
          {
            LogPipe *scheduler_pipe = log_scheduler_pipe_new(configuration);
            last_scheduler_options = log_scheduler_pipe_get_scheduler_options(scheduler_pipe);
            (yyval.ptr) = scheduler_pipe;
          }
#line 4371 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 109: /* log_scheduler: KW_PARALLELIZE '(' @17 log_scheduler_options ')'  */
#line 867 "lib/rewrite/rewrite-expr-grammar.y"
                                                { (yyval.ptr) = log_expr_node_new_pipe((yyvsp[-2].ptr), &(yyloc)); }
#line 4377 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 112: /* log_scheduler_option: KW_PARTITIONS '(' nonnegative_integer ')'  */
#line 877 "lib/rewrite/rewrite-expr-grammar.y"
          {
            last_scheduler_options->num_partitions = (yyvsp[-1].num);
          }
#line 4385 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 113: /* log_scheduler_option: KW_PARTITION_KEY '(' template_content ')'  */
#line 881 "lib/rewrite/rewrite-expr-grammar.y"
          {
            log_scheduler_options_set_partition_key_ref(last_scheduler_options, (yyvsp[-1].ptr));
          }
#line 4393 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 114: /* log_junction: KW_JUNCTION '{' log_forks '}'  */
#line 888 "lib/rewrite/rewrite-expr-grammar.y"
                                                { (yyval.ptr) = log_expr_node_new_junction((yyvsp[-1].ptr), &(yyloc)); }
#line 4399 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 115: /* log_last_junction: log_forks  */
#line 900 "lib/rewrite/rewrite-expr-grammar.y"
                                                { (yyval.ptr) = (yyvsp[0].ptr) ? log_expr_node_new_junction((yyvsp[0].ptr), &(yylsp[0])) :  NULL; }
#line 4405 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 116: /* log_forks: log_fork semicolons log_forks  */
#line 905 "lib/rewrite/rewrite-expr-grammar.y"
                                                { log_expr_node_append_tail((yyvsp[-2].ptr), (yyvsp[0].ptr)); (yyval.ptr) = (yyvsp[-2].ptr); }
#line 4411 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 117: /* log_forks: %empty  */
#line 906 "lib/rewrite/rewrite-expr-grammar.y"
                                                { (yyval.ptr) = NULL; }
#line 4417 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 118: /* log_fork: KW_LOG optional_string '{' log_content '}'  */
#line 911 "lib/rewrite/rewrite-expr-grammar.y"
          {
            if ((yyvsp[-3].cptr))
              {
                log_expr_node_set_name((yyvsp[-1].ptr), (yyvsp[-3].cptr));
                free((yyvsp[-3].cptr));
              }
            (yyval.ptr) = (yyvsp[-1].ptr);
          }
#line 4430 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 119: /* log_fork: KW_CHANNEL optional_string '{' log_content '}'  */
#line 920 "lib/rewrite/rewrite-expr-grammar.y"
          {
            if ((yyvsp[-3].cptr))
              {
                log_expr_node_set_name((yyvsp[-1].ptr), (yyvsp[-3].cptr));
                free((yyvsp[-3].cptr));
              }
            (yyval.ptr) = (yyvsp[-1].ptr);
          }
#line 4443 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 120: /* log_conditional: log_if  */
#line 931 "lib/rewrite/rewrite-expr-grammar.y"
                                                { (yyval.ptr) = (yyvsp[0].ptr); }
#line 4449 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 121: /* log_conditional: log_if KW_ELSE '{' log_content '}'  */
#line 933 "lib/rewrite/rewrite-expr-grammar.y"
          {
            log_expr_node_conditional_set_false_branch_of_the_last_if((yyvsp[-4].ptr), (yyvsp[-1].ptr));
            (yyval.ptr) = (yyvsp[-4].ptr);
          }
#line 4458 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 122: /* log_if: KW_IF '(' filter_content ')' '{' log_content '}'  */
#line 941 "lib/rewrite/rewrite-expr-grammar.y"
          {
            (yyval.ptr) = log_expr_node_new_simple_conditional((yyvsp[-4].ptr), (yyvsp[-1].ptr), &(yyloc));
          }
#line 4466 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 123: /* log_if: KW_IF '{' log_content '}'  */
#line 945 "lib/rewrite/rewrite-expr-grammar.y"
          {
            (yyval.ptr) = log_expr_node_new_compound_conditional((yyvsp[-1].ptr), &(yyloc));
          }
#line 4474 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 124: /* log_if: log_if KW_ELIF '(' filter_content ')' '{' log_content '}'  */
#line 949 "lib/rewrite/rewrite-expr-grammar.y"
          {
            LogExprNode *false_branch;

            false_branch = log_expr_node_new_simple_conditional((yyvsp[-4].ptr), (yyvsp[-1].ptr), &(yyloc));
            log_expr_node_conditional_set_false_branch_of_the_last_if((yyvsp[-7].ptr), false_branch);
            (yyval.ptr) = (yyvsp[-7].ptr);
          }
#line 4486 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 125: /* log_if: log_if KW_ELIF '{' log_content '}'  */
#line 957 "lib/rewrite/rewrite-expr-grammar.y"
          {
            LogExprNode *false_branch;

            false_branch = log_expr_node_new_compound_conditional((yyvsp[-1].ptr), &(yyloc));
            log_expr_node_conditional_set_false_branch_of_the_last_if((yyvsp[-4].ptr), false_branch);
            (yyval.ptr) = (yyvsp[-4].ptr);
          }
#line 4498 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 126: /* log_content: log_items log_last_junction log_flags  */
#line 967 "lib/rewrite/rewrite-expr-grammar.y"
                                                               { (yyval.ptr) = log_expr_node_new_log(log_expr_node_append_tail((yyvsp[-2].ptr), (yyvsp[-1].ptr)), (yyvsp[0].num), &(yyloc)); }
#line 4504 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 127: /* log_flags: KW_FLAGS '(' log_flags_items ')' semicolons  */
#line 971 "lib/rewrite/rewrite-expr-grammar.y"
                                                        { (yyval.num) = (yyvsp[-2].num); }
#line 4510 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 128: /* log_flags: %empty  */
#line 972 "lib/rewrite/rewrite-expr-grammar.y"
                                                { (yyval.num) = 0; }
#line 4516 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 129: /* log_flags_items: normalized_flag log_flags_items  */
#line 976 "lib/rewrite/rewrite-expr-grammar.y"
                                                { (yyval.num) = log_expr_node_lookup_flag((yyvsp[-1].cptr)) | (yyvsp[0].num); free((yyvsp[-1].cptr)); }
#line 4522 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 130: /* log_flags_items: %empty  */
#line 977 "lib/rewrite/rewrite-expr-grammar.y"
                                                { (yyval.num) = 0; }
#line 4528 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 131: /* template_content_inner: string  */
#line 984 "lib/rewrite/rewrite-expr-grammar.y"
        {
          GError *error = NULL;

          CHECK_ERROR_GERROR(log_template_compile((yyvsp[-1].ptr), (yyvsp[0].cptr), &error), (yylsp[0]), error, "Error compiling template");
          free((yyvsp[0].cptr));
        }
#line 4539 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 132: /* template_content_inner: type_hint '(' string_or_number ')'  */
#line 991 "lib/rewrite/rewrite-expr-grammar.y"
        {
          GError *error = NULL;

          CHECK_ERROR_GERROR(log_template_compile((yyvsp[-4].ptr), (yyvsp[-1].cptr), &error), (yylsp[-1]), error, "Error compiling template");
          free((yyvsp[-1].cptr));

          log_template_set_type_hint_value((yyvsp[-4].ptr), (yyvsp[-3].num));
        }
#line 4552 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 133: /* template_content_inner: LL_NUMBER  */
#line 1000 "lib/rewrite/rewrite-expr-grammar.y"
        {
          gchar decimal[32];

          g_snprintf(decimal, sizeof(decimal), "%" G_GINT64_FORMAT, (yyvsp[0].num));
          log_template_compile_literal_string((yyvsp[-1].ptr), decimal);
          log_template_set_type_hint((yyvsp[-1].ptr), "int64", NULL);
        }
#line 4564 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 134: /* template_content_inner: LL_FLOAT  */
#line 1008 "lib/rewrite/rewrite-expr-grammar.y"
        {
          log_template_compile_literal_string((yyvsp[-1].ptr), lexer->token_text->str);
          log_template_set_type_hint((yyvsp[-1].ptr), "float", NULL);
        }
#line 4573 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 135: /* type_hint: LL_IDENTIFIER  */
#line 1016 "lib/rewrite/rewrite-expr-grammar.y"
          {
            LogMessageValueType type;
            GError *error = NULL;

            CHECK_ERROR_GERROR(type_hint_parse((yyvsp[0].cptr), &type, &error), (yylsp[0]), error, "Unknown type hint");
            free((yyvsp[0].cptr));
            (yyval.num) = type;
          }
#line 4586 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 136: /* @18: %empty  */
#line 1026 "lib/rewrite/rewrite-expr-grammar.y"
               {
            (yyval.ptr) = log_template_new(configuration, NULL);
          }
#line 4594 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 137: /* template_content: @18 template_content_inner  */
#line 1028 "lib/rewrite/rewrite-expr-grammar.y"
                                                                            { (yyval.ptr) = (yyvsp[-1].ptr); }
#line 4600 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 140: /* yesno_strict: KW_YES  */
#line 1053 "lib/rewrite/rewrite-expr-grammar.y"
                                                { (yyval.num) = 1; }
#line 4606 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 141: /* yesno_strict: KW_NO  */
#line 1054 "lib/rewrite/rewrite-expr-grammar.y"
                                                { (yyval.num) = 0; }
#line 4612 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 143: /* yesno: LL_NUMBER  */
#line 1059 "lib/rewrite/rewrite-expr-grammar.y"
                                                { (yyval.num) = (yyvsp[0].num); }
#line 4618 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 144: /* dnsmode: yesno  */
#line 1069 "lib/rewrite/rewrite-expr-grammar.y"
                                                { (yyval.num) = (yyvsp[0].num); }
#line 4624 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 145: /* dnsmode: KW_PERSIST_ONLY  */
#line 1070 "lib/rewrite/rewrite-expr-grammar.y"
                                                { (yyval.num) = 2; }
#line 4630 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 146: /* nonnegative_integer64: LL_NUMBER  */
#line 1075 "lib/rewrite/rewrite-expr-grammar.y"
          {
            CHECK_ERROR(((yyvsp[0].num) >= 0), (yylsp[0]), "It cannot be negative");
          }
#line 4638 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 147: /* nonnegative_integer: nonnegative_integer64  */
#line 1082 "lib/rewrite/rewrite-expr-grammar.y"
          {
            CHECK_ERROR(((yyvsp[0].num) <= G_MAXINT32), (yylsp[0]), "Must be smaller than 2^31");
          }
#line 4646 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 148: /* positive_integer64: LL_NUMBER  */
#line 1089 "lib/rewrite/rewrite-expr-grammar.y"
          {
            CHECK_ERROR(((yyvsp[0].num) > 0), (yylsp[0]), "Must be positive");
          }
#line 4654 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 149: /* positive_integer: positive_integer64  */
#line 1096 "lib/rewrite/rewrite-expr-grammar.y"
          {
            CHECK_ERROR(((yyvsp[0].num) <= G_MAXINT32), (yylsp[0]), "Must be smaller than 2^31");
          }
#line 4662 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 150: /* string_or_number: string  */
#line 1124 "lib/rewrite/rewrite-expr-grammar.y"
                                                { (yyval.cptr) = (yyvsp[0].cptr); }
#line 4668 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 151: /* string_or_number: LL_NUMBER  */
#line 1125 "lib/rewrite/rewrite-expr-grammar.y"
                                                { (yyval.cptr) = strdup(lexer->token_text->str); }
#line 4674 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 152: /* string_or_number: LL_FLOAT  */
#line 1126 "lib/rewrite/rewrite-expr-grammar.y"
                                                { (yyval.cptr) = strdup(lexer->token_text->str); }
#line 4680 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 153: /* optional_string: string  */
#line 1130 "lib/rewrite/rewrite-expr-grammar.y"
                                                { (yyval.cptr) = (yyvsp[0].cptr); }
#line 4686 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 154: /* optional_string: %empty  */
#line 1131 "lib/rewrite/rewrite-expr-grammar.y"
                                                { (yyval.cptr) = NULL; }
#line 4692 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 155: /* normalized_flag: string  */
#line 1157 "lib/rewrite/rewrite-expr-grammar.y"
                                                { (yyval.cptr) = normalize_flag((yyvsp[0].cptr)); free((yyvsp[0].cptr)); }
#line 4698 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 156: /* string_list: string_list_build  */
#line 1161 "lib/rewrite/rewrite-expr-grammar.y"
                                                { (yyval.ptr) = (yyvsp[0].ptr); }
#line 4704 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 157: /* string_list_build: string string_list_build  */
#line 1165 "lib/rewrite/rewrite-expr-grammar.y"
                                                { (yyval.ptr) = g_list_prepend((yyvsp[0].ptr), g_strdup((yyvsp[-1].cptr))); free((yyvsp[-1].cptr)); }
#line 4710 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 158: /* string_list_build: %empty  */
#line 1166 "lib/rewrite/rewrite-expr-grammar.y"
                                                { (yyval.ptr) = NULL; }
#line 4716 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 161: /* source_option: KW_LOG_IW_SIZE '(' positive_integer ')'  */
#line 1338 "lib/rewrite/rewrite-expr-grammar.y"
                                                        { last_source_options->init_window_size = (yyvsp[-1].num); }
#line 4722 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 162: /* source_option: KW_CHAIN_HOSTNAMES '(' yesno ')'  */
#line 1339 "lib/rewrite/rewrite-expr-grammar.y"
                                                { last_source_options->chain_hostnames = (yyvsp[-1].num); }
#line 4728 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 163: /* source_option: KW_KEEP_HOSTNAME '(' yesno ')'  */
#line 1340 "lib/rewrite/rewrite-expr-grammar.y"
                                                { last_source_options->keep_hostname = (yyvsp[-1].num); }
#line 4734 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 164: /* source_option: KW_PROGRAM_OVERRIDE '(' string ')'  */
#line 1341 "lib/rewrite/rewrite-expr-grammar.y"
                                                { last_source_options->program_override = g_strdup((yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 4740 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 165: /* source_option: KW_HOST_OVERRIDE '(' string ')'  */
#line 1342 "lib/rewrite/rewrite-expr-grammar.y"
                                                { last_source_options->host_override = g_strdup((yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 4746 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 166: /* source_option: KW_LOG_PREFIX '(' string ')'  */
#line 1343 "lib/rewrite/rewrite-expr-grammar.y"
                                                { gchar *p = strrchr((yyvsp[-1].cptr), ':'); if (p) *p = 0; last_source_options->program_override = g_strdup((yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 4752 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 167: /* source_option: KW_KEEP_TIMESTAMP '(' yesno ')'  */
#line 1344 "lib/rewrite/rewrite-expr-grammar.y"
                                                { last_source_options->keep_timestamp = (yyvsp[-1].num); }
#line 4758 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 168: /* source_option: KW_READ_OLD_RECORDS '(' yesno ')'  */
#line 1345 "lib/rewrite/rewrite-expr-grammar.y"
                                                { last_source_options->read_old_records = (yyvsp[-1].num); }
#line 4764 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 169: /* source_option: KW_USE_SYSLOGNG_PID '(' yesno ')'  */
#line 1346 "lib/rewrite/rewrite-expr-grammar.y"
                                                { last_source_options->use_syslogng_pid = (yyvsp[-1].num); }
#line 4770 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 170: /* source_option: KW_TAGS '(' string_list ')'  */
#line 1347 "lib/rewrite/rewrite-expr-grammar.y"
                                                { log_source_options_set_tags(last_source_options, (yyvsp[-1].ptr)); }
#line 4776 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 171: /* $@21: %empty  */
#line 1348 "lib/rewrite/rewrite-expr-grammar.y"
          { last_host_resolve_options = &last_source_options->host_resolve_options; }
#line 4782 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 173: /* host_resolve_option: KW_USE_FQDN '(' yesno ')'  */
#line 1384 "lib/rewrite/rewrite-expr-grammar.y"
                                                { last_host_resolve_options->use_fqdn = (yyvsp[-1].num); }
#line 4788 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 174: /* host_resolve_option: KW_USE_DNS '(' dnsmode ')'  */
#line 1385 "lib/rewrite/rewrite-expr-grammar.y"
                                                { last_host_resolve_options->use_dns = (yyvsp[-1].num); }
#line 4794 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 175: /* host_resolve_option: KW_DNS_CACHE '(' yesno ')'  */
#line 1386 "lib/rewrite/rewrite-expr-grammar.y"
                                                { last_host_resolve_options->use_dns_cache = (yyvsp[-1].num); }
#line 4800 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 176: /* host_resolve_option: KW_NORMALIZE_HOSTNAMES '(' yesno ')'  */
#line 1387 "lib/rewrite/rewrite-expr-grammar.y"
                                                { last_host_resolve_options->normalize_hostnames = (yyvsp[-1].num); }
#line 4806 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 177: /* template_option: KW_TS_FORMAT '(' string ')'  */
#line 1459 "lib/rewrite/rewrite-expr-grammar.y"
                                                { last_template_options->ts_format = cfg_ts_format_value((yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 4812 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 178: /* template_option: KW_FRAC_DIGITS '(' nonnegative_integer ')'  */
#line 1460 "lib/rewrite/rewrite-expr-grammar.y"
                                                        { last_template_options->frac_digits = (yyvsp[-1].num); }
#line 4818 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 179: /* template_option: KW_TIME_ZONE '(' string ')'  */
#line 1461 "lib/rewrite/rewrite-expr-grammar.y"
                                                { last_template_options->time_zone[LTZ_SEND] = g_strdup((yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 4824 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 180: /* template_option: KW_SEND_TIME_ZONE '(' string ')'  */
#line 1462 "lib/rewrite/rewrite-expr-grammar.y"
                                                { last_template_options->time_zone[LTZ_SEND] = g_strdup((yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 4830 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 181: /* template_option: KW_LOCAL_TIME_ZONE '(' string ')'  */
#line 1463 "lib/rewrite/rewrite-expr-grammar.y"
                                                { last_template_options->time_zone[LTZ_LOCAL] = g_strdup((yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 4836 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 182: /* template_option: KW_TEMPLATE_ESCAPE '(' yesno ')'  */
#line 1464 "lib/rewrite/rewrite-expr-grammar.y"
                                                { last_template_options->escape = (yyvsp[-1].num); }
#line 4842 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 183: /* template_option: KW_ON_ERROR '(' string ')'  */
#line 1466 "lib/rewrite/rewrite-expr-grammar.y"
        {
          gint on_error;

          CHECK_ERROR(log_template_on_error_parse((yyvsp[-1].cptr), &on_error), (yylsp[-1]), "Invalid on-error() setting \"%s\"", (yyvsp[-1].cptr));
          free((yyvsp[-1].cptr));

          log_template_options_set_on_error(last_template_options, on_error);
        }
#line 4855 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 184: /* matcher_option: KW_TYPE '(' string ')'  */
#line 1477 "lib/rewrite/rewrite-expr-grammar.y"
                                                { CHECK_ERROR(log_matcher_options_set_type(last_matcher_options, (yyvsp[-1].cptr)), (yylsp[-1]), "unknown matcher type \"%s\"", (yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 4861 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 186: /* matcher_flags: string matcher_flags  */
#line 1482 "lib/rewrite/rewrite-expr-grammar.y"
                                                { CHECK_ERROR(log_matcher_options_process_flag(last_matcher_options, (yyvsp[-1].cptr)), (yylsp[-1]), "unknown matcher flag \"%s\"", (yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 4867 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 188: /* rewrite_expr_opt: KW_VALUE '(' string ')'  */
#line 1577 "lib/rewrite/rewrite-expr-grammar.y"
          {
            const gchar *p = (yyvsp[-1].cptr);
            if (p[0] == '$')
              {
                msg_warning("Value references in rewrite rules should not use the '$' prefix, those are only needed in templates",
                            evt_tag_str("value", (yyvsp[-1].cptr)),
                            cfg_lexer_format_location_tag(lexer, &(yylsp[-1])));
                p++;
              }
            last_rewrite->value_handle = log_msg_get_value_handle(p);
            CHECK_ERROR(!log_msg_is_handle_macro(last_rewrite->value_handle), (yylsp[-1]), "%s is read-only, it cannot be changed in rewrite rules", p);
	    CHECK_ERROR(log_msg_is_value_name_valid(p), (yylsp[-1]), "%s is not a valid name for a name-value pair, perhaps a misspelled .SDATA reference?", p);
            free((yyvsp[-1].cptr));
          }
#line 4886 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 189: /* rewrite_expr_opt: KW_INTERNAL '(' yesno ')'  */
#line 1591 "lib/rewrite/rewrite-expr-grammar.y"
                                    { log_pipe_set_internal(&last_rewrite->super, (yyvsp[-1].num)); }
#line 4892 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 191: /* $@31: %empty  */
#line 1597 "lib/rewrite/rewrite-expr-grammar.y"
          {
            FilterExprNode *filter_expr;

            CHECK_ERROR_WITHOUT_MESSAGE(cfg_parser_parse(&filter_expr_parser, lexer, (gpointer *) &filter_expr, NULL), (yylsp[-1]));
            log_rewrite_set_condition(last_rewrite, filter_expr);
          }
#line 4903 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 193: /* _destination_context_push: %empty  */
#line 1628 "lib/rewrite/rewrite-expr-grammar.y"
                           { cfg_lexer_push_context(lexer, LL_CONTEXT_DESTINATION, NULL, "destination statement"); }
#line 4909 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 194: /* _destination_context_pop: %empty  */
#line 1629 "lib/rewrite/rewrite-expr-grammar.y"
                          { cfg_lexer_pop_context(lexer); }
#line 4915 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 195: /* _source_context_push: %empty  */
#line 1630 "lib/rewrite/rewrite-expr-grammar.y"
                      { cfg_lexer_push_context(lexer, LL_CONTEXT_SOURCE, NULL, "source statement"); }
#line 4921 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 196: /* _source_context_pop: %empty  */
#line 1631 "lib/rewrite/rewrite-expr-grammar.y"
                      { cfg_lexer_pop_context(lexer); }
#line 4927 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 197: /* _filterx_context_push: %empty  */
#line 1638 "lib/rewrite/rewrite-expr-grammar.y"
                       { cfg_lexer_push_context(lexer, LL_CONTEXT_FILTERX, NULL, "filterx statement"); }
#line 4933 "lib/rewrite/rewrite-expr-grammar.c"
    break;

  case 198: /* _filterx_context_pop: %empty  */
#line 1639 "lib/rewrite/rewrite-expr-grammar.y"
                      { cfg_lexer_pop_context(lexer); }
#line 4939 "lib/rewrite/rewrite-expr-grammar.c"
    break;


#line 4943 "lib/rewrite/rewrite-expr-grammar.c"

      default: break;
    }
  /* User semantic actions sometimes alter yychar, and that requires
     that yytoken be updated with the new translation.  We take the
     approach of translating immediately before every use of yytoken.
     One alternative is translating here after every semantic action,
     but that translation would be missed if the semantic action invokes
     YYABORT, YYACCEPT, or YYERROR immediately after altering yychar or
     if it invokes YYBACKUP.  In the case of YYABORT or YYACCEPT, an
     incorrect destructor might then be invoked immediately.  In the
     case of YYERROR or YYBACKUP, subsequent parser actions might lead
     to an incorrect destructor call or verbose syntax error message
     before the lookahead is translated.  */
  YY_SYMBOL_PRINT ("-> $$ =", YY_CAST (yysymbol_kind_t, yyr1[yyn]), &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;

  *++yyvsp = yyval;
  *++yylsp = yyloc;

  /* Now 'shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */
  {
    const int yylhs = yyr1[yyn] - YYNTOKENS;
    const int yyi = yypgoto[yylhs] + *yyssp;
    yystate = (0 <= yyi && yyi <= YYLAST && yycheck[yyi] == *yyssp
               ? yytable[yyi]
               : yydefgoto[yylhs]);
  }

  goto yynewstate;


/*--------------------------------------.
| yyerrlab -- here on detecting error.  |
`--------------------------------------*/
yyerrlab:
  /* Make sure we have latest lookahead translation.  See comments at
     user semantic actions for why this is necessary.  */
  yytoken = yychar == REWRITE_EXPR_EMPTY ? YYSYMBOL_YYEMPTY : YYTRANSLATE (yychar);
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
      {
        yypcontext_t yyctx
          = {yyssp, yytoken, &yylloc};
        char const *yymsgp = YY_("syntax error");
        int yysyntax_error_status;
        yysyntax_error_status = yysyntax_error (&yymsg_alloc, &yymsg, &yyctx);
        if (yysyntax_error_status == 0)
          yymsgp = yymsg;
        else if (yysyntax_error_status == -1)
          {
            if (yymsg != yymsgbuf)
              YYSTACK_FREE (yymsg);
            yymsg = YY_CAST (char *,
                             YYSTACK_ALLOC (YY_CAST (YYSIZE_T, yymsg_alloc)));
            if (yymsg)
              {
                yysyntax_error_status
                  = yysyntax_error (&yymsg_alloc, &yymsg, &yyctx);
                yymsgp = yymsg;
              }
            else
              {
                yymsg = yymsgbuf;
                yymsg_alloc = sizeof yymsgbuf;
                yysyntax_error_status = YYENOMEM;
              }
          }
        yyerror (&yylloc, lexer, result, arg, yymsgp);
        if (yysyntax_error_status == YYENOMEM)
          YYNOMEM;
      }
    }

  yyerror_range[1] = yylloc;
  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
         error, discard it.  */

      if (yychar <= REWRITE_EXPR_EOF)
        {
          /* Return failure if at end of input.  */
          if (yychar == REWRITE_EXPR_EOF)
            YYABORT;
        }
      else
        {
          yydestruct ("Error: discarding",
                      yytoken, &yylval, &yylloc, lexer, result, arg);
          yychar = REWRITE_EXPR_EMPTY;
        }
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:
  /* Pacify compilers when the user code never invokes YYERROR and the
     label yyerrorlab therefore never appears in user code.  */
  if (0)
    YYERROR;
  ++yynerrs;

  /* Do not reclaim the symbols of the rule whose action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;      /* Each real token shifted decrements this.  */

  /* Pop stack until we find a state that shifts the error token.  */
  for (;;)
    {
      yyn = yypact[yystate];
      if (!yypact_value_is_default (yyn))
        {
          yyn += YYSYMBOL_YYerror;
          if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYSYMBOL_YYerror)
            {
              yyn = yytable[yyn];
              if (0 < yyn)
                break;
            }
        }

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
        YYABORT;

      yyerror_range[1] = *yylsp;
      yydestruct ("Error: popping",
                  YY_ACCESSING_SYMBOL (yystate), yyvsp, yylsp, lexer, result, arg);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END

  yyerror_range[2] = yylloc;
  ++yylsp;
  YYLLOC_DEFAULT (*yylsp, yyerror_range, 2);

  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", YY_ACCESSING_SYMBOL (yyn), yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturnlab;


/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturnlab;


/*-----------------------------------------------------------.
| yyexhaustedlab -- YYNOMEM (memory exhaustion) comes here.  |
`-----------------------------------------------------------*/
yyexhaustedlab:
  yyerror (&yylloc, lexer, result, arg, YY_("memory exhausted"));
  yyresult = 2;
  goto yyreturnlab;


/*----------------------------------------------------------.
| yyreturnlab -- parsing is finished, clean up and return.  |
`----------------------------------------------------------*/
yyreturnlab:
  if (yychar != REWRITE_EXPR_EMPTY)
    {
      /* Make sure we have latest lookahead translation.  See comments at
         user semantic actions for why this is necessary.  */
      yytoken = YYTRANSLATE (yychar);
      yydestruct ("Cleanup: discarding lookahead",
                  yytoken, &yylval, &yylloc, lexer, result, arg);
    }
  /* Do not reclaim the symbols of the rule whose action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
                  YY_ACCESSING_SYMBOL (+*yyssp), yyvsp, yylsp, lexer, result, arg);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
  if (yymsg != yymsgbuf)
    YYSTACK_FREE (yymsg);
  return yyresult;
}

#line 1659 "lib/rewrite/rewrite-expr-grammar.y"

