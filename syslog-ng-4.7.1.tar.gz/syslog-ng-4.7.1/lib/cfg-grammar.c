/* A Bison parser, made by GNU Bison 3.8.2.  */

/* Bison implementation for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2021 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output, and Bison version.  */
#define YYBISON 30802

/* Bison version string.  */
#define YYBISON_VERSION "3.8.2"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 1

/* Push parsers.  */
#define YYPUSH 0

/* Pull parsers.  */
#define YYPULL 1

/* Substitute the type names.  */
#define YYSTYPE         MAIN_STYPE
#define YYLTYPE         MAIN_LTYPE
/* Substitute the variable and function names.  */
#define yyparse         main_parse
#define yylex           main_lex
#define yyerror         main_error
#define yydebug         main_debug
#define yynerrs         main_nerrs


# ifndef YY_CAST
#  ifdef __cplusplus
#   define YY_CAST(Type, Val) static_cast<Type> (Val)
#   define YY_REINTERPRET_CAST(Type, Val) reinterpret_cast<Type> (Val)
#  else
#   define YY_CAST(Type, Val) ((Type) (Val))
#   define YY_REINTERPRET_CAST(Type, Val) ((Type) (Val))
#  endif
# endif
# ifndef YY_NULLPTR
#  if defined __cplusplus
#   if 201103L <= __cplusplus
#    define YY_NULLPTR nullptr
#   else
#    define YY_NULLPTR 0
#   endif
#  else
#   define YY_NULLPTR ((void*)0)
#  endif
# endif

/* Use api.header.include to #include this header
   instead of duplicating it here.  */
#ifndef YY_MAIN_LIB_CFG_GRAMMAR_H_INCLUDED
# define YY_MAIN_LIB_CFG_GRAMMAR_H_INCLUDED
/* Debug traces.  */
#ifndef MAIN_DEBUG
# if defined YYDEBUG
#if YYDEBUG
#   define MAIN_DEBUG 1
#  else
#   define MAIN_DEBUG 0
#  endif
# else /* ! defined YYDEBUG */
#  define MAIN_DEBUG 0
# endif /* ! defined YYDEBUG */
#endif  /* ! defined MAIN_DEBUG */
#if MAIN_DEBUG
extern int main_debug;
#endif
/* "%code requires" blocks.  */
#line 25 "/source/lib/cfg-grammar.y"


/* this block is inserted into cfg-grammar.h, so it is included
   practically all of the syslog-ng code. Please add headers here
   with care. If you need additional headers, please look for a
   massive list of includes further below. */

/* YYSTYPE and YYLTYPE is defined by the lexer */
#include "cfg-lexer.h"
#include "cfg-grammar-internal.h"
#include "syslog-names.h"

/* uses struct declarations instead of the typedefs to avoid having to
 * include logreader/logwriter/driver.h, which defines the typedefs.  This
 * is to avoid including unnecessary dependencies into grammars that are not
 * themselves reader/writer based */


#line 138 "lib/cfg-grammar.c"

/* Token kinds.  */
#ifndef MAIN_TOKENTYPE
# define MAIN_TOKENTYPE
  enum main_tokentype
  {
    MAIN_EMPTY = -2,
    MAIN_EOF = 0,                  /* "end of file"  */
    MAIN_error = 256,              /* error  */
    MAIN_UNDEF = 10531,            /* "invalid token"  */
    LL_CONTEXT_ROOT = 1,           /* LL_CONTEXT_ROOT  */
    LL_CONTEXT_DESTINATION = 2,    /* LL_CONTEXT_DESTINATION  */
    LL_CONTEXT_SOURCE = 3,         /* LL_CONTEXT_SOURCE  */
    LL_CONTEXT_PARSER = 4,         /* LL_CONTEXT_PARSER  */
    LL_CONTEXT_REWRITE = 5,        /* LL_CONTEXT_REWRITE  */
    LL_CONTEXT_FILTER = 6,         /* LL_CONTEXT_FILTER  */
    LL_CONTEXT_LOG = 7,            /* LL_CONTEXT_LOG  */
    LL_CONTEXT_BLOCK_DEF = 8,      /* LL_CONTEXT_BLOCK_DEF  */
    LL_CONTEXT_BLOCK_REF = 9,      /* LL_CONTEXT_BLOCK_REF  */
    LL_CONTEXT_BLOCK_CONTENT = 10, /* LL_CONTEXT_BLOCK_CONTENT  */
    LL_CONTEXT_BLOCK_ARG = 11,     /* LL_CONTEXT_BLOCK_ARG  */
    LL_CONTEXT_PRAGMA = 12,        /* LL_CONTEXT_PRAGMA  */
    LL_CONTEXT_FORMAT = 13,        /* LL_CONTEXT_FORMAT  */
    LL_CONTEXT_TEMPLATE_FUNC = 14, /* LL_CONTEXT_TEMPLATE_FUNC  */
    LL_CONTEXT_INNER_DEST = 15,    /* LL_CONTEXT_INNER_DEST  */
    LL_CONTEXT_INNER_SRC = 16,     /* LL_CONTEXT_INNER_SRC  */
    LL_CONTEXT_CLIENT_PROTO = 17,  /* LL_CONTEXT_CLIENT_PROTO  */
    LL_CONTEXT_SERVER_PROTO = 18,  /* LL_CONTEXT_SERVER_PROTO  */
    LL_CONTEXT_OPTIONS = 19,       /* LL_CONTEXT_OPTIONS  */
    LL_CONTEXT_CONFIG = 20,        /* LL_CONTEXT_CONFIG  */
    LL_CONTEXT_TEMPLATE_REF = 21,  /* LL_CONTEXT_TEMPLATE_REF  */
    LL_CONTEXT_FILTERX = 22,       /* LL_CONTEXT_FILTERX  */
    LL_CONTEXT_FILTERX_FUNC = 23,  /* LL_CONTEXT_FILTERX_FUNC  */
    LL_CONTEXT_FILTERX_ENUM = 24,  /* LL_CONTEXT_FILTERX_ENUM  */
    LL_CONTEXT_MAX = 25,           /* LL_CONTEXT_MAX  */
    KW_ASSIGN = 9000,              /* KW_ASSIGN  */
    KW_OR = 9001,                  /* KW_OR  */
    KW_AND = 9002,                 /* KW_AND  */
    KW_STR_EQ = 9003,              /* KW_STR_EQ  */
    KW_STR_NE = 9004,              /* KW_STR_NE  */
    KW_TA_EQ = 9005,               /* KW_TA_EQ  */
    KW_TA_NE = 9006,               /* KW_TA_NE  */
    KW_TAV_EQ = 9007,              /* KW_TAV_EQ  */
    KW_TAV_NE = 9008,              /* KW_TAV_NE  */
    KW_STR_LT = 9009,              /* KW_STR_LT  */
    KW_STR_LE = 9010,              /* KW_STR_LE  */
    KW_STR_GE = 9011,              /* KW_STR_GE  */
    KW_STR_GT = 9012,              /* KW_STR_GT  */
    KW_TA_LT = 9013,               /* KW_TA_LT  */
    KW_TA_LE = 9014,               /* KW_TA_LE  */
    KW_TA_GE = 9015,               /* KW_TA_GE  */
    KW_TA_GT = 9016,               /* KW_TA_GT  */
    KW_PLUS_ASSIGN = 9018,         /* KW_PLUS_ASSIGN  */
    KW_NOT = 9017,                 /* KW_NOT  */
    KW_SOURCE = 10000,             /* KW_SOURCE  */
    KW_FILTER = 10001,             /* KW_FILTER  */
    KW_PARSER = 10002,             /* KW_PARSER  */
    KW_DESTINATION = 10003,        /* KW_DESTINATION  */
    KW_LOG = 10004,                /* KW_LOG  */
    KW_OPTIONS = 10005,            /* KW_OPTIONS  */
    KW_INCLUDE = 10006,            /* KW_INCLUDE  */
    KW_BLOCK = 10007,              /* KW_BLOCK  */
    KW_JUNCTION = 10008,           /* KW_JUNCTION  */
    KW_CHANNEL = 10009,            /* KW_CHANNEL  */
    KW_IF = 10010,                 /* KW_IF  */
    KW_ELSE = 10011,               /* KW_ELSE  */
    KW_ELIF = 10012,               /* KW_ELIF  */
    KW_FILTERX = 10013,            /* KW_FILTERX  */
    KW_INTERNAL = 10020,           /* KW_INTERNAL  */
    KW_SYSLOG = 10060,             /* KW_SYSLOG  */
    KW_MARK_FREQ = 10071,          /* KW_MARK_FREQ  */
    KW_STATS_FREQ = 10072,         /* KW_STATS_FREQ  */
    KW_STATS_LEVEL = 10073,        /* KW_STATS_LEVEL  */
    KW_STATS_LIFETIME = 10074,     /* KW_STATS_LIFETIME  */
    KW_FLUSH_LINES = 10075,        /* KW_FLUSH_LINES  */
    KW_SUPPRESS = 10076,           /* KW_SUPPRESS  */
    KW_FLUSH_TIMEOUT = 10077,      /* KW_FLUSH_TIMEOUT  */
    KW_LOG_MSG_SIZE = 10078,       /* KW_LOG_MSG_SIZE  */
    KW_FILE_TEMPLATE = 10079,      /* KW_FILE_TEMPLATE  */
    KW_PROTO_TEMPLATE = 10080,     /* KW_PROTO_TEMPLATE  */
    KW_MARK_MODE = 10081,          /* KW_MARK_MODE  */
    KW_ENCODING = 10082,           /* KW_ENCODING  */
    KW_TYPE = 10083,               /* KW_TYPE  */
    KW_STATS_MAX_DYNAMIC = 10084,  /* KW_STATS_MAX_DYNAMIC  */
    KW_MIN_IW_SIZE_PER_READER = 10085, /* KW_MIN_IW_SIZE_PER_READER  */
    KW_WORKERS = 10086,            /* KW_WORKERS  */
    KW_BATCH_LINES = 10087,        /* KW_BATCH_LINES  */
    KW_BATCH_TIMEOUT = 10088,      /* KW_BATCH_TIMEOUT  */
    KW_TRIM_LARGE_MESSAGES = 10089, /* KW_TRIM_LARGE_MESSAGES  */
    KW_STATS = 10400,              /* KW_STATS  */
    KW_FREQ = 10401,               /* KW_FREQ  */
    KW_LEVEL = 10402,              /* KW_LEVEL  */
    KW_LIFETIME = 10403,           /* KW_LIFETIME  */
    KW_MAX_DYNAMIC = 10404,        /* KW_MAX_DYNAMIC  */
    KW_SYSLOG_STATS = 10405,       /* KW_SYSLOG_STATS  */
    KW_HEALTHCHECK_FREQ = 10406,   /* KW_HEALTHCHECK_FREQ  */
    KW_WORKER_PARTITION_KEY = 10407, /* KW_WORKER_PARTITION_KEY  */
    KW_CHAIN_HOSTNAMES = 10090,    /* KW_CHAIN_HOSTNAMES  */
    KW_NORMALIZE_HOSTNAMES = 10091, /* KW_NORMALIZE_HOSTNAMES  */
    KW_KEEP_HOSTNAME = 10092,      /* KW_KEEP_HOSTNAME  */
    KW_CHECK_HOSTNAME = 10093,     /* KW_CHECK_HOSTNAME  */
    KW_BAD_HOSTNAME = 10094,       /* KW_BAD_HOSTNAME  */
    KW_LOG_LEVEL = 10095,          /* KW_LOG_LEVEL  */
    KW_KEEP_TIMESTAMP = 10100,     /* KW_KEEP_TIMESTAMP  */
    KW_USE_DNS = 10110,            /* KW_USE_DNS  */
    KW_USE_FQDN = 10111,           /* KW_USE_FQDN  */
    KW_CUSTOM_DOMAIN = 10112,      /* KW_CUSTOM_DOMAIN  */
    KW_DNS_CACHE = 10120,          /* KW_DNS_CACHE  */
    KW_DNS_CACHE_SIZE = 10121,     /* KW_DNS_CACHE_SIZE  */
    KW_DNS_CACHE_EXPIRE = 10130,   /* KW_DNS_CACHE_EXPIRE  */
    KW_DNS_CACHE_EXPIRE_FAILED = 10131, /* KW_DNS_CACHE_EXPIRE_FAILED  */
    KW_DNS_CACHE_HOSTS = 10132,    /* KW_DNS_CACHE_HOSTS  */
    KW_PERSIST_ONLY = 10140,       /* KW_PERSIST_ONLY  */
    KW_USE_RCPTID = 10141,         /* KW_USE_RCPTID  */
    KW_USE_UNIQID = 10142,         /* KW_USE_UNIQID  */
    KW_TZ_CONVERT = 10150,         /* KW_TZ_CONVERT  */
    KW_TS_FORMAT = 10151,          /* KW_TS_FORMAT  */
    KW_FRAC_DIGITS = 10152,        /* KW_FRAC_DIGITS  */
    KW_LOG_FIFO_SIZE = 10160,      /* KW_LOG_FIFO_SIZE  */
    KW_LOG_FETCH_LIMIT = 10162,    /* KW_LOG_FETCH_LIMIT  */
    KW_LOG_IW_SIZE = 10163,        /* KW_LOG_IW_SIZE  */
    KW_LOG_PREFIX = 10164,         /* KW_LOG_PREFIX  */
    KW_PROGRAM_OVERRIDE = 10165,   /* KW_PROGRAM_OVERRIDE  */
    KW_HOST_OVERRIDE = 10166,      /* KW_HOST_OVERRIDE  */
    KW_THROTTLE = 10170,           /* KW_THROTTLE  */
    KW_THREADED = 10171,           /* KW_THREADED  */
    KW_PASS_UNIX_CREDENTIALS = 10180, /* KW_PASS_UNIX_CREDENTIALS  */
    KW_PERSIST_NAME = 10181,       /* KW_PERSIST_NAME  */
    KW_READ_OLD_RECORDS = 10182,   /* KW_READ_OLD_RECORDS  */
    KW_USE_SYSLOGNG_PID = 10183,   /* KW_USE_SYSLOGNG_PID  */
    KW_FLAGS = 10190,              /* KW_FLAGS  */
    KW_PAD_SIZE = 10200,           /* KW_PAD_SIZE  */
    KW_TIME_ZONE = 10201,          /* KW_TIME_ZONE  */
    KW_RECV_TIME_ZONE = 10202,     /* KW_RECV_TIME_ZONE  */
    KW_SEND_TIME_ZONE = 10203,     /* KW_SEND_TIME_ZONE  */
    KW_LOCAL_TIME_ZONE = 10204,    /* KW_LOCAL_TIME_ZONE  */
    KW_FORMAT = 10205,             /* KW_FORMAT  */
    KW_MULTI_LINE_MODE = 10206,    /* KW_MULTI_LINE_MODE  */
    KW_MULTI_LINE_PREFIX = 10207,  /* KW_MULTI_LINE_PREFIX  */
    KW_MULTI_LINE_GARBAGE = 10208, /* KW_MULTI_LINE_GARBAGE  */
    KW_TRUNCATE_SIZE = 10209,      /* KW_TRUNCATE_SIZE  */
    KW_TIME_REOPEN = 10210,        /* KW_TIME_REOPEN  */
    KW_TIME_REAP = 10211,          /* KW_TIME_REAP  */
    KW_TIME_SLEEP = 10212,         /* KW_TIME_SLEEP  */
    KW_PARTITIONS = 10213,         /* KW_PARTITIONS  */
    KW_PARTITION_KEY = 10214,      /* KW_PARTITION_KEY  */
    KW_PARALLELIZE = 10215,        /* KW_PARALLELIZE  */
    KW_TMPL_ESCAPE = 10220,        /* KW_TMPL_ESCAPE  */
    KW_OPTIONAL = 10230,           /* KW_OPTIONAL  */
    KW_CREATE_DIRS = 10240,        /* KW_CREATE_DIRS  */
    KW_OWNER = 10250,              /* KW_OWNER  */
    KW_GROUP = 10251,              /* KW_GROUP  */
    KW_PERM = 10252,               /* KW_PERM  */
    KW_DIR_OWNER = 10260,          /* KW_DIR_OWNER  */
    KW_DIR_GROUP = 10261,          /* KW_DIR_GROUP  */
    KW_DIR_PERM = 10262,           /* KW_DIR_PERM  */
    KW_TEMPLATE = 10270,           /* KW_TEMPLATE  */
    KW_TEMPLATE_ESCAPE = 10271,    /* KW_TEMPLATE_ESCAPE  */
    KW_TEMPLATE_FUNCTION = 10272,  /* KW_TEMPLATE_FUNCTION  */
    KW_DEFAULT_FACILITY = 10300,   /* KW_DEFAULT_FACILITY  */
    KW_DEFAULT_SEVERITY = 10301,   /* KW_DEFAULT_SEVERITY  */
    KW_SDATA_PREFIX = 10302,       /* KW_SDATA_PREFIX  */
    KW_PORT = 10323,               /* KW_PORT  */
    KW_USE_TIME_RECVD = 10340,     /* KW_USE_TIME_RECVD  */
    KW_FACILITY = 10350,           /* KW_FACILITY  */
    KW_SEVERITY = 10351,           /* KW_SEVERITY  */
    KW_HOST = 10352,               /* KW_HOST  */
    KW_MATCH = 10353,              /* KW_MATCH  */
    KW_MESSAGE = 10354,            /* KW_MESSAGE  */
    KW_NETMASK = 10355,            /* KW_NETMASK  */
    KW_TAGS = 10356,               /* KW_TAGS  */
    KW_NETMASK6 = 10357,           /* KW_NETMASK6  */
    KW_REWRITE = 10370,            /* KW_REWRITE  */
    KW_CONDITION = 10371,          /* KW_CONDITION  */
    KW_VALUE = 10372,              /* KW_VALUE  */
    KW_YES = 10380,                /* KW_YES  */
    KW_NO = 10381,                 /* KW_NO  */
    KW_AUTO = 10382,               /* KW_AUTO  */
    KW_IFDEF = 10410,              /* KW_IFDEF  */
    KW_ENDIF = 10411,              /* KW_ENDIF  */
    LL_DOTDOT = 10420,             /* LL_DOTDOT  */
    LL_DOTDOTDOT = 10421,          /* LL_DOTDOTDOT  */
    LL_PRAGMA = 10422,             /* LL_PRAGMA  */
    LL_EOL = 10423,                /* LL_EOL  */
    LL_ERROR = 10424,              /* LL_ERROR  */
    LL_ARROW = 10425,              /* LL_ARROW  */
    LL_IDENTIFIER = 10430,         /* LL_IDENTIFIER  */
    LL_NUMBER = 10431,             /* LL_NUMBER  */
    LL_FLOAT = 10432,              /* LL_FLOAT  */
    LL_STRING = 10433,             /* LL_STRING  */
    LL_TOKEN = 10434,              /* LL_TOKEN  */
    LL_BLOCK = 10435,              /* LL_BLOCK  */
    LL_PLUGIN = 10436,             /* LL_PLUGIN  */
    LL_TEMPLATE_REF = 10437,       /* LL_TEMPLATE_REF  */
    LL_MESSAGE_REF = 10438,        /* LL_MESSAGE_REF  */
    KW_VALUE_PAIRS = 10500,        /* KW_VALUE_PAIRS  */
    KW_EXCLUDE = 10502,            /* KW_EXCLUDE  */
    KW_PAIR = 10503,               /* KW_PAIR  */
    KW_KEY = 10504,                /* KW_KEY  */
    KW_SCOPE = 10505,              /* KW_SCOPE  */
    KW_SHIFT = 10506,              /* KW_SHIFT  */
    KW_SHIFT_LEVELS = 10507,       /* KW_SHIFT_LEVELS  */
    KW_REKEY = 10508,              /* KW_REKEY  */
    KW_ADD_PREFIX = 10509,         /* KW_ADD_PREFIX  */
    KW_REPLACE_PREFIX = 10510,     /* KW_REPLACE_PREFIX  */
    KW_CAST = 10511,               /* KW_CAST  */
    KW_UPPER = 10512,              /* KW_UPPER  */
    KW_LOWER = 10513,              /* KW_LOWER  */
    KW_INCLUDE_BYTES = 10514,      /* KW_INCLUDE_BYTES  */
    KW_ON_ERROR = 10520,           /* KW_ON_ERROR  */
    KW_RETRIES = 10521,            /* KW_RETRIES  */
    KW_FETCH_NO_DATA_DELAY = 10522, /* KW_FETCH_NO_DATA_DELAY  */
    KW_LABELS = 10530              /* KW_LABELS  */
  };
  typedef enum main_tokentype main_token_kind_t;
#endif
/* Token kinds.  */
#define MAIN_EMPTY -2
#define MAIN_EOF 0
#define MAIN_error 256
#define MAIN_UNDEF 10531
#define LL_CONTEXT_ROOT 1
#define LL_CONTEXT_DESTINATION 2
#define LL_CONTEXT_SOURCE 3
#define LL_CONTEXT_PARSER 4
#define LL_CONTEXT_REWRITE 5
#define LL_CONTEXT_FILTER 6
#define LL_CONTEXT_LOG 7
#define LL_CONTEXT_BLOCK_DEF 8
#define LL_CONTEXT_BLOCK_REF 9
#define LL_CONTEXT_BLOCK_CONTENT 10
#define LL_CONTEXT_BLOCK_ARG 11
#define LL_CONTEXT_PRAGMA 12
#define LL_CONTEXT_FORMAT 13
#define LL_CONTEXT_TEMPLATE_FUNC 14
#define LL_CONTEXT_INNER_DEST 15
#define LL_CONTEXT_INNER_SRC 16
#define LL_CONTEXT_CLIENT_PROTO 17
#define LL_CONTEXT_SERVER_PROTO 18
#define LL_CONTEXT_OPTIONS 19
#define LL_CONTEXT_CONFIG 20
#define LL_CONTEXT_TEMPLATE_REF 21
#define LL_CONTEXT_FILTERX 22
#define LL_CONTEXT_FILTERX_FUNC 23
#define LL_CONTEXT_FILTERX_ENUM 24
#define LL_CONTEXT_MAX 25
#define KW_ASSIGN 9000
#define KW_OR 9001
#define KW_AND 9002
#define KW_STR_EQ 9003
#define KW_STR_NE 9004
#define KW_TA_EQ 9005
#define KW_TA_NE 9006
#define KW_TAV_EQ 9007
#define KW_TAV_NE 9008
#define KW_STR_LT 9009
#define KW_STR_LE 9010
#define KW_STR_GE 9011
#define KW_STR_GT 9012
#define KW_TA_LT 9013
#define KW_TA_LE 9014
#define KW_TA_GE 9015
#define KW_TA_GT 9016
#define KW_PLUS_ASSIGN 9018
#define KW_NOT 9017
#define KW_SOURCE 10000
#define KW_FILTER 10001
#define KW_PARSER 10002
#define KW_DESTINATION 10003
#define KW_LOG 10004
#define KW_OPTIONS 10005
#define KW_INCLUDE 10006
#define KW_BLOCK 10007
#define KW_JUNCTION 10008
#define KW_CHANNEL 10009
#define KW_IF 10010
#define KW_ELSE 10011
#define KW_ELIF 10012
#define KW_FILTERX 10013
#define KW_INTERNAL 10020
#define KW_SYSLOG 10060
#define KW_MARK_FREQ 10071
#define KW_STATS_FREQ 10072
#define KW_STATS_LEVEL 10073
#define KW_STATS_LIFETIME 10074
#define KW_FLUSH_LINES 10075
#define KW_SUPPRESS 10076
#define KW_FLUSH_TIMEOUT 10077
#define KW_LOG_MSG_SIZE 10078
#define KW_FILE_TEMPLATE 10079
#define KW_PROTO_TEMPLATE 10080
#define KW_MARK_MODE 10081
#define KW_ENCODING 10082
#define KW_TYPE 10083
#define KW_STATS_MAX_DYNAMIC 10084
#define KW_MIN_IW_SIZE_PER_READER 10085
#define KW_WORKERS 10086
#define KW_BATCH_LINES 10087
#define KW_BATCH_TIMEOUT 10088
#define KW_TRIM_LARGE_MESSAGES 10089
#define KW_STATS 10400
#define KW_FREQ 10401
#define KW_LEVEL 10402
#define KW_LIFETIME 10403
#define KW_MAX_DYNAMIC 10404
#define KW_SYSLOG_STATS 10405
#define KW_HEALTHCHECK_FREQ 10406
#define KW_WORKER_PARTITION_KEY 10407
#define KW_CHAIN_HOSTNAMES 10090
#define KW_NORMALIZE_HOSTNAMES 10091
#define KW_KEEP_HOSTNAME 10092
#define KW_CHECK_HOSTNAME 10093
#define KW_BAD_HOSTNAME 10094
#define KW_LOG_LEVEL 10095
#define KW_KEEP_TIMESTAMP 10100
#define KW_USE_DNS 10110
#define KW_USE_FQDN 10111
#define KW_CUSTOM_DOMAIN 10112
#define KW_DNS_CACHE 10120
#define KW_DNS_CACHE_SIZE 10121
#define KW_DNS_CACHE_EXPIRE 10130
#define KW_DNS_CACHE_EXPIRE_FAILED 10131
#define KW_DNS_CACHE_HOSTS 10132
#define KW_PERSIST_ONLY 10140
#define KW_USE_RCPTID 10141
#define KW_USE_UNIQID 10142
#define KW_TZ_CONVERT 10150
#define KW_TS_FORMAT 10151
#define KW_FRAC_DIGITS 10152
#define KW_LOG_FIFO_SIZE 10160
#define KW_LOG_FETCH_LIMIT 10162
#define KW_LOG_IW_SIZE 10163
#define KW_LOG_PREFIX 10164
#define KW_PROGRAM_OVERRIDE 10165
#define KW_HOST_OVERRIDE 10166
#define KW_THROTTLE 10170
#define KW_THREADED 10171
#define KW_PASS_UNIX_CREDENTIALS 10180
#define KW_PERSIST_NAME 10181
#define KW_READ_OLD_RECORDS 10182
#define KW_USE_SYSLOGNG_PID 10183
#define KW_FLAGS 10190
#define KW_PAD_SIZE 10200
#define KW_TIME_ZONE 10201
#define KW_RECV_TIME_ZONE 10202
#define KW_SEND_TIME_ZONE 10203
#define KW_LOCAL_TIME_ZONE 10204
#define KW_FORMAT 10205
#define KW_MULTI_LINE_MODE 10206
#define KW_MULTI_LINE_PREFIX 10207
#define KW_MULTI_LINE_GARBAGE 10208
#define KW_TRUNCATE_SIZE 10209
#define KW_TIME_REOPEN 10210
#define KW_TIME_REAP 10211
#define KW_TIME_SLEEP 10212
#define KW_PARTITIONS 10213
#define KW_PARTITION_KEY 10214
#define KW_PARALLELIZE 10215
#define KW_TMPL_ESCAPE 10220
#define KW_OPTIONAL 10230
#define KW_CREATE_DIRS 10240
#define KW_OWNER 10250
#define KW_GROUP 10251
#define KW_PERM 10252
#define KW_DIR_OWNER 10260
#define KW_DIR_GROUP 10261
#define KW_DIR_PERM 10262
#define KW_TEMPLATE 10270
#define KW_TEMPLATE_ESCAPE 10271
#define KW_TEMPLATE_FUNCTION 10272
#define KW_DEFAULT_FACILITY 10300
#define KW_DEFAULT_SEVERITY 10301
#define KW_SDATA_PREFIX 10302
#define KW_PORT 10323
#define KW_USE_TIME_RECVD 10340
#define KW_FACILITY 10350
#define KW_SEVERITY 10351
#define KW_HOST 10352
#define KW_MATCH 10353
#define KW_MESSAGE 10354
#define KW_NETMASK 10355
#define KW_TAGS 10356
#define KW_NETMASK6 10357
#define KW_REWRITE 10370
#define KW_CONDITION 10371
#define KW_VALUE 10372
#define KW_YES 10380
#define KW_NO 10381
#define KW_AUTO 10382
#define KW_IFDEF 10410
#define KW_ENDIF 10411
#define LL_DOTDOT 10420
#define LL_DOTDOTDOT 10421
#define LL_PRAGMA 10422
#define LL_EOL 10423
#define LL_ERROR 10424
#define LL_ARROW 10425
#define LL_IDENTIFIER 10430
#define LL_NUMBER 10431
#define LL_FLOAT 10432
#define LL_STRING 10433
#define LL_TOKEN 10434
#define LL_BLOCK 10435
#define LL_PLUGIN 10436
#define LL_TEMPLATE_REF 10437
#define LL_MESSAGE_REF 10438
#define KW_VALUE_PAIRS 10500
#define KW_EXCLUDE 10502
#define KW_PAIR 10503
#define KW_KEY 10504
#define KW_SCOPE 10505
#define KW_SHIFT 10506
#define KW_SHIFT_LEVELS 10507
#define KW_REKEY 10508
#define KW_ADD_PREFIX 10509
#define KW_REPLACE_PREFIX 10510
#define KW_CAST 10511
#define KW_UPPER 10512
#define KW_LOWER 10513
#define KW_INCLUDE_BYTES 10514
#define KW_ON_ERROR 10520
#define KW_RETRIES 10521
#define KW_FETCH_NO_DATA_DELAY 10522
#define KW_LABELS 10530

/* Value type.  */
#if ! defined MAIN_STYPE && ! defined MAIN_STYPE_IS_DECLARED
typedef CFG_STYPE MAIN_STYPE;
# define MAIN_STYPE_IS_TRIVIAL 1
# define MAIN_STYPE_IS_DECLARED 1
#endif

/* Location type.  */
typedef CFG_LTYPE MAIN_LTYPE;




int main_parse (CfgLexer *lexer, gpointer *dummy, gpointer arg);


#endif /* !YY_MAIN_LIB_CFG_GRAMMAR_H_INCLUDED  */
/* Symbol kind.  */
enum yysymbol_kind_t
{
  YYSYMBOL_YYEMPTY = -2,
  YYSYMBOL_YYEOF = 0,                      /* "end of file"  */
  YYSYMBOL_YYerror = 1,                    /* error  */
  YYSYMBOL_YYUNDEF = 2,                    /* "invalid token"  */
  YYSYMBOL_LL_CONTEXT_ROOT = 3,            /* LL_CONTEXT_ROOT  */
  YYSYMBOL_LL_CONTEXT_DESTINATION = 4,     /* LL_CONTEXT_DESTINATION  */
  YYSYMBOL_LL_CONTEXT_SOURCE = 5,          /* LL_CONTEXT_SOURCE  */
  YYSYMBOL_LL_CONTEXT_PARSER = 6,          /* LL_CONTEXT_PARSER  */
  YYSYMBOL_LL_CONTEXT_REWRITE = 7,         /* LL_CONTEXT_REWRITE  */
  YYSYMBOL_LL_CONTEXT_FILTER = 8,          /* LL_CONTEXT_FILTER  */
  YYSYMBOL_LL_CONTEXT_LOG = 9,             /* LL_CONTEXT_LOG  */
  YYSYMBOL_LL_CONTEXT_BLOCK_DEF = 10,      /* LL_CONTEXT_BLOCK_DEF  */
  YYSYMBOL_LL_CONTEXT_BLOCK_REF = 11,      /* LL_CONTEXT_BLOCK_REF  */
  YYSYMBOL_LL_CONTEXT_BLOCK_CONTENT = 12,  /* LL_CONTEXT_BLOCK_CONTENT  */
  YYSYMBOL_LL_CONTEXT_BLOCK_ARG = 13,      /* LL_CONTEXT_BLOCK_ARG  */
  YYSYMBOL_LL_CONTEXT_PRAGMA = 14,         /* LL_CONTEXT_PRAGMA  */
  YYSYMBOL_LL_CONTEXT_FORMAT = 15,         /* LL_CONTEXT_FORMAT  */
  YYSYMBOL_LL_CONTEXT_TEMPLATE_FUNC = 16,  /* LL_CONTEXT_TEMPLATE_FUNC  */
  YYSYMBOL_LL_CONTEXT_INNER_DEST = 17,     /* LL_CONTEXT_INNER_DEST  */
  YYSYMBOL_LL_CONTEXT_INNER_SRC = 18,      /* LL_CONTEXT_INNER_SRC  */
  YYSYMBOL_LL_CONTEXT_CLIENT_PROTO = 19,   /* LL_CONTEXT_CLIENT_PROTO  */
  YYSYMBOL_LL_CONTEXT_SERVER_PROTO = 20,   /* LL_CONTEXT_SERVER_PROTO  */
  YYSYMBOL_LL_CONTEXT_OPTIONS = 21,        /* LL_CONTEXT_OPTIONS  */
  YYSYMBOL_LL_CONTEXT_CONFIG = 22,         /* LL_CONTEXT_CONFIG  */
  YYSYMBOL_LL_CONTEXT_TEMPLATE_REF = 23,   /* LL_CONTEXT_TEMPLATE_REF  */
  YYSYMBOL_LL_CONTEXT_FILTERX = 24,        /* LL_CONTEXT_FILTERX  */
  YYSYMBOL_LL_CONTEXT_FILTERX_FUNC = 25,   /* LL_CONTEXT_FILTERX_FUNC  */
  YYSYMBOL_LL_CONTEXT_FILTERX_ENUM = 26,   /* LL_CONTEXT_FILTERX_ENUM  */
  YYSYMBOL_LL_CONTEXT_MAX = 27,            /* LL_CONTEXT_MAX  */
  YYSYMBOL_KW_ASSIGN = 28,                 /* KW_ASSIGN  */
  YYSYMBOL_KW_OR = 29,                     /* KW_OR  */
  YYSYMBOL_KW_AND = 30,                    /* KW_AND  */
  YYSYMBOL_KW_STR_EQ = 31,                 /* KW_STR_EQ  */
  YYSYMBOL_KW_STR_NE = 32,                 /* KW_STR_NE  */
  YYSYMBOL_KW_TA_EQ = 33,                  /* KW_TA_EQ  */
  YYSYMBOL_KW_TA_NE = 34,                  /* KW_TA_NE  */
  YYSYMBOL_KW_TAV_EQ = 35,                 /* KW_TAV_EQ  */
  YYSYMBOL_KW_TAV_NE = 36,                 /* KW_TAV_NE  */
  YYSYMBOL_KW_STR_LT = 37,                 /* KW_STR_LT  */
  YYSYMBOL_KW_STR_LE = 38,                 /* KW_STR_LE  */
  YYSYMBOL_KW_STR_GE = 39,                 /* KW_STR_GE  */
  YYSYMBOL_KW_STR_GT = 40,                 /* KW_STR_GT  */
  YYSYMBOL_KW_TA_LT = 41,                  /* KW_TA_LT  */
  YYSYMBOL_KW_TA_LE = 42,                  /* KW_TA_LE  */
  YYSYMBOL_KW_TA_GE = 43,                  /* KW_TA_GE  */
  YYSYMBOL_KW_TA_GT = 44,                  /* KW_TA_GT  */
  YYSYMBOL_KW_PLUS_ASSIGN = 45,            /* KW_PLUS_ASSIGN  */
  YYSYMBOL_46_ = 46,                       /* '+'  */
  YYSYMBOL_47_ = 47,                       /* '-'  */
  YYSYMBOL_48_ = 48,                       /* '*'  */
  YYSYMBOL_49_ = 49,                       /* '/'  */
  YYSYMBOL_50_ = 50,                       /* '.'  */
  YYSYMBOL_51_ = 51,                       /* '['  */
  YYSYMBOL_52_ = 52,                       /* ']'  */
  YYSYMBOL_KW_NOT = 53,                    /* KW_NOT  */
  YYSYMBOL_KW_SOURCE = 54,                 /* KW_SOURCE  */
  YYSYMBOL_KW_FILTER = 55,                 /* KW_FILTER  */
  YYSYMBOL_KW_PARSER = 56,                 /* KW_PARSER  */
  YYSYMBOL_KW_DESTINATION = 57,            /* KW_DESTINATION  */
  YYSYMBOL_KW_LOG = 58,                    /* KW_LOG  */
  YYSYMBOL_KW_OPTIONS = 59,                /* KW_OPTIONS  */
  YYSYMBOL_KW_INCLUDE = 60,                /* KW_INCLUDE  */
  YYSYMBOL_KW_BLOCK = 61,                  /* KW_BLOCK  */
  YYSYMBOL_KW_JUNCTION = 62,               /* KW_JUNCTION  */
  YYSYMBOL_KW_CHANNEL = 63,                /* KW_CHANNEL  */
  YYSYMBOL_KW_IF = 64,                     /* KW_IF  */
  YYSYMBOL_KW_ELSE = 65,                   /* KW_ELSE  */
  YYSYMBOL_KW_ELIF = 66,                   /* KW_ELIF  */
  YYSYMBOL_KW_FILTERX = 67,                /* KW_FILTERX  */
  YYSYMBOL_KW_INTERNAL = 68,               /* KW_INTERNAL  */
  YYSYMBOL_KW_SYSLOG = 69,                 /* KW_SYSLOG  */
  YYSYMBOL_KW_MARK_FREQ = 70,              /* KW_MARK_FREQ  */
  YYSYMBOL_KW_STATS_FREQ = 71,             /* KW_STATS_FREQ  */
  YYSYMBOL_KW_STATS_LEVEL = 72,            /* KW_STATS_LEVEL  */
  YYSYMBOL_KW_STATS_LIFETIME = 73,         /* KW_STATS_LIFETIME  */
  YYSYMBOL_KW_FLUSH_LINES = 74,            /* KW_FLUSH_LINES  */
  YYSYMBOL_KW_SUPPRESS = 75,               /* KW_SUPPRESS  */
  YYSYMBOL_KW_FLUSH_TIMEOUT = 76,          /* KW_FLUSH_TIMEOUT  */
  YYSYMBOL_KW_LOG_MSG_SIZE = 77,           /* KW_LOG_MSG_SIZE  */
  YYSYMBOL_KW_FILE_TEMPLATE = 78,          /* KW_FILE_TEMPLATE  */
  YYSYMBOL_KW_PROTO_TEMPLATE = 79,         /* KW_PROTO_TEMPLATE  */
  YYSYMBOL_KW_MARK_MODE = 80,              /* KW_MARK_MODE  */
  YYSYMBOL_KW_ENCODING = 81,               /* KW_ENCODING  */
  YYSYMBOL_KW_TYPE = 82,                   /* KW_TYPE  */
  YYSYMBOL_KW_STATS_MAX_DYNAMIC = 83,      /* KW_STATS_MAX_DYNAMIC  */
  YYSYMBOL_KW_MIN_IW_SIZE_PER_READER = 84, /* KW_MIN_IW_SIZE_PER_READER  */
  YYSYMBOL_KW_WORKERS = 85,                /* KW_WORKERS  */
  YYSYMBOL_KW_BATCH_LINES = 86,            /* KW_BATCH_LINES  */
  YYSYMBOL_KW_BATCH_TIMEOUT = 87,          /* KW_BATCH_TIMEOUT  */
  YYSYMBOL_KW_TRIM_LARGE_MESSAGES = 88,    /* KW_TRIM_LARGE_MESSAGES  */
  YYSYMBOL_KW_STATS = 89,                  /* KW_STATS  */
  YYSYMBOL_KW_FREQ = 90,                   /* KW_FREQ  */
  YYSYMBOL_KW_LEVEL = 91,                  /* KW_LEVEL  */
  YYSYMBOL_KW_LIFETIME = 92,               /* KW_LIFETIME  */
  YYSYMBOL_KW_MAX_DYNAMIC = 93,            /* KW_MAX_DYNAMIC  */
  YYSYMBOL_KW_SYSLOG_STATS = 94,           /* KW_SYSLOG_STATS  */
  YYSYMBOL_KW_HEALTHCHECK_FREQ = 95,       /* KW_HEALTHCHECK_FREQ  */
  YYSYMBOL_KW_WORKER_PARTITION_KEY = 96,   /* KW_WORKER_PARTITION_KEY  */
  YYSYMBOL_KW_CHAIN_HOSTNAMES = 97,        /* KW_CHAIN_HOSTNAMES  */
  YYSYMBOL_KW_NORMALIZE_HOSTNAMES = 98,    /* KW_NORMALIZE_HOSTNAMES  */
  YYSYMBOL_KW_KEEP_HOSTNAME = 99,          /* KW_KEEP_HOSTNAME  */
  YYSYMBOL_KW_CHECK_HOSTNAME = 100,        /* KW_CHECK_HOSTNAME  */
  YYSYMBOL_KW_BAD_HOSTNAME = 101,          /* KW_BAD_HOSTNAME  */
  YYSYMBOL_KW_LOG_LEVEL = 102,             /* KW_LOG_LEVEL  */
  YYSYMBOL_KW_KEEP_TIMESTAMP = 103,        /* KW_KEEP_TIMESTAMP  */
  YYSYMBOL_KW_USE_DNS = 104,               /* KW_USE_DNS  */
  YYSYMBOL_KW_USE_FQDN = 105,              /* KW_USE_FQDN  */
  YYSYMBOL_KW_CUSTOM_DOMAIN = 106,         /* KW_CUSTOM_DOMAIN  */
  YYSYMBOL_KW_DNS_CACHE = 107,             /* KW_DNS_CACHE  */
  YYSYMBOL_KW_DNS_CACHE_SIZE = 108,        /* KW_DNS_CACHE_SIZE  */
  YYSYMBOL_KW_DNS_CACHE_EXPIRE = 109,      /* KW_DNS_CACHE_EXPIRE  */
  YYSYMBOL_KW_DNS_CACHE_EXPIRE_FAILED = 110, /* KW_DNS_CACHE_EXPIRE_FAILED  */
  YYSYMBOL_KW_DNS_CACHE_HOSTS = 111,       /* KW_DNS_CACHE_HOSTS  */
  YYSYMBOL_KW_PERSIST_ONLY = 112,          /* KW_PERSIST_ONLY  */
  YYSYMBOL_KW_USE_RCPTID = 113,            /* KW_USE_RCPTID  */
  YYSYMBOL_KW_USE_UNIQID = 114,            /* KW_USE_UNIQID  */
  YYSYMBOL_KW_TZ_CONVERT = 115,            /* KW_TZ_CONVERT  */
  YYSYMBOL_KW_TS_FORMAT = 116,             /* KW_TS_FORMAT  */
  YYSYMBOL_KW_FRAC_DIGITS = 117,           /* KW_FRAC_DIGITS  */
  YYSYMBOL_KW_LOG_FIFO_SIZE = 118,         /* KW_LOG_FIFO_SIZE  */
  YYSYMBOL_KW_LOG_FETCH_LIMIT = 119,       /* KW_LOG_FETCH_LIMIT  */
  YYSYMBOL_KW_LOG_IW_SIZE = 120,           /* KW_LOG_IW_SIZE  */
  YYSYMBOL_KW_LOG_PREFIX = 121,            /* KW_LOG_PREFIX  */
  YYSYMBOL_KW_PROGRAM_OVERRIDE = 122,      /* KW_PROGRAM_OVERRIDE  */
  YYSYMBOL_KW_HOST_OVERRIDE = 123,         /* KW_HOST_OVERRIDE  */
  YYSYMBOL_KW_THROTTLE = 124,              /* KW_THROTTLE  */
  YYSYMBOL_KW_THREADED = 125,              /* KW_THREADED  */
  YYSYMBOL_KW_PASS_UNIX_CREDENTIALS = 126, /* KW_PASS_UNIX_CREDENTIALS  */
  YYSYMBOL_KW_PERSIST_NAME = 127,          /* KW_PERSIST_NAME  */
  YYSYMBOL_KW_READ_OLD_RECORDS = 128,      /* KW_READ_OLD_RECORDS  */
  YYSYMBOL_KW_USE_SYSLOGNG_PID = 129,      /* KW_USE_SYSLOGNG_PID  */
  YYSYMBOL_KW_FLAGS = 130,                 /* KW_FLAGS  */
  YYSYMBOL_KW_PAD_SIZE = 131,              /* KW_PAD_SIZE  */
  YYSYMBOL_KW_TIME_ZONE = 132,             /* KW_TIME_ZONE  */
  YYSYMBOL_KW_RECV_TIME_ZONE = 133,        /* KW_RECV_TIME_ZONE  */
  YYSYMBOL_KW_SEND_TIME_ZONE = 134,        /* KW_SEND_TIME_ZONE  */
  YYSYMBOL_KW_LOCAL_TIME_ZONE = 135,       /* KW_LOCAL_TIME_ZONE  */
  YYSYMBOL_KW_FORMAT = 136,                /* KW_FORMAT  */
  YYSYMBOL_KW_MULTI_LINE_MODE = 137,       /* KW_MULTI_LINE_MODE  */
  YYSYMBOL_KW_MULTI_LINE_PREFIX = 138,     /* KW_MULTI_LINE_PREFIX  */
  YYSYMBOL_KW_MULTI_LINE_GARBAGE = 139,    /* KW_MULTI_LINE_GARBAGE  */
  YYSYMBOL_KW_TRUNCATE_SIZE = 140,         /* KW_TRUNCATE_SIZE  */
  YYSYMBOL_KW_TIME_REOPEN = 141,           /* KW_TIME_REOPEN  */
  YYSYMBOL_KW_TIME_REAP = 142,             /* KW_TIME_REAP  */
  YYSYMBOL_KW_TIME_SLEEP = 143,            /* KW_TIME_SLEEP  */
  YYSYMBOL_KW_PARTITIONS = 144,            /* KW_PARTITIONS  */
  YYSYMBOL_KW_PARTITION_KEY = 145,         /* KW_PARTITION_KEY  */
  YYSYMBOL_KW_PARALLELIZE = 146,           /* KW_PARALLELIZE  */
  YYSYMBOL_KW_TMPL_ESCAPE = 147,           /* KW_TMPL_ESCAPE  */
  YYSYMBOL_KW_OPTIONAL = 148,              /* KW_OPTIONAL  */
  YYSYMBOL_KW_CREATE_DIRS = 149,           /* KW_CREATE_DIRS  */
  YYSYMBOL_KW_OWNER = 150,                 /* KW_OWNER  */
  YYSYMBOL_KW_GROUP = 151,                 /* KW_GROUP  */
  YYSYMBOL_KW_PERM = 152,                  /* KW_PERM  */
  YYSYMBOL_KW_DIR_OWNER = 153,             /* KW_DIR_OWNER  */
  YYSYMBOL_KW_DIR_GROUP = 154,             /* KW_DIR_GROUP  */
  YYSYMBOL_KW_DIR_PERM = 155,              /* KW_DIR_PERM  */
  YYSYMBOL_KW_TEMPLATE = 156,              /* KW_TEMPLATE  */
  YYSYMBOL_KW_TEMPLATE_ESCAPE = 157,       /* KW_TEMPLATE_ESCAPE  */
  YYSYMBOL_KW_TEMPLATE_FUNCTION = 158,     /* KW_TEMPLATE_FUNCTION  */
  YYSYMBOL_KW_DEFAULT_FACILITY = 159,      /* KW_DEFAULT_FACILITY  */
  YYSYMBOL_KW_DEFAULT_SEVERITY = 160,      /* KW_DEFAULT_SEVERITY  */
  YYSYMBOL_KW_SDATA_PREFIX = 161,          /* KW_SDATA_PREFIX  */
  YYSYMBOL_KW_PORT = 162,                  /* KW_PORT  */
  YYSYMBOL_KW_USE_TIME_RECVD = 163,        /* KW_USE_TIME_RECVD  */
  YYSYMBOL_KW_FACILITY = 164,              /* KW_FACILITY  */
  YYSYMBOL_KW_SEVERITY = 165,              /* KW_SEVERITY  */
  YYSYMBOL_KW_HOST = 166,                  /* KW_HOST  */
  YYSYMBOL_KW_MATCH = 167,                 /* KW_MATCH  */
  YYSYMBOL_KW_MESSAGE = 168,               /* KW_MESSAGE  */
  YYSYMBOL_KW_NETMASK = 169,               /* KW_NETMASK  */
  YYSYMBOL_KW_TAGS = 170,                  /* KW_TAGS  */
  YYSYMBOL_KW_NETMASK6 = 171,              /* KW_NETMASK6  */
  YYSYMBOL_KW_REWRITE = 172,               /* KW_REWRITE  */
  YYSYMBOL_KW_CONDITION = 173,             /* KW_CONDITION  */
  YYSYMBOL_KW_VALUE = 174,                 /* KW_VALUE  */
  YYSYMBOL_KW_YES = 175,                   /* KW_YES  */
  YYSYMBOL_KW_NO = 176,                    /* KW_NO  */
  YYSYMBOL_KW_AUTO = 177,                  /* KW_AUTO  */
  YYSYMBOL_KW_IFDEF = 178,                 /* KW_IFDEF  */
  YYSYMBOL_KW_ENDIF = 179,                 /* KW_ENDIF  */
  YYSYMBOL_LL_DOTDOT = 180,                /* LL_DOTDOT  */
  YYSYMBOL_LL_DOTDOTDOT = 181,             /* LL_DOTDOTDOT  */
  YYSYMBOL_LL_PRAGMA = 182,                /* LL_PRAGMA  */
  YYSYMBOL_LL_EOL = 183,                   /* LL_EOL  */
  YYSYMBOL_LL_ERROR = 184,                 /* LL_ERROR  */
  YYSYMBOL_LL_ARROW = 185,                 /* LL_ARROW  */
  YYSYMBOL_LL_IDENTIFIER = 186,            /* LL_IDENTIFIER  */
  YYSYMBOL_LL_NUMBER = 187,                /* LL_NUMBER  */
  YYSYMBOL_LL_FLOAT = 188,                 /* LL_FLOAT  */
  YYSYMBOL_LL_STRING = 189,                /* LL_STRING  */
  YYSYMBOL_LL_TOKEN = 190,                 /* LL_TOKEN  */
  YYSYMBOL_LL_BLOCK = 191,                 /* LL_BLOCK  */
  YYSYMBOL_LL_PLUGIN = 192,                /* LL_PLUGIN  */
  YYSYMBOL_LL_TEMPLATE_REF = 193,          /* LL_TEMPLATE_REF  */
  YYSYMBOL_LL_MESSAGE_REF = 194,           /* LL_MESSAGE_REF  */
  YYSYMBOL_KW_VALUE_PAIRS = 195,           /* KW_VALUE_PAIRS  */
  YYSYMBOL_KW_EXCLUDE = 196,               /* KW_EXCLUDE  */
  YYSYMBOL_KW_PAIR = 197,                  /* KW_PAIR  */
  YYSYMBOL_KW_KEY = 198,                   /* KW_KEY  */
  YYSYMBOL_KW_SCOPE = 199,                 /* KW_SCOPE  */
  YYSYMBOL_KW_SHIFT = 200,                 /* KW_SHIFT  */
  YYSYMBOL_KW_SHIFT_LEVELS = 201,          /* KW_SHIFT_LEVELS  */
  YYSYMBOL_KW_REKEY = 202,                 /* KW_REKEY  */
  YYSYMBOL_KW_ADD_PREFIX = 203,            /* KW_ADD_PREFIX  */
  YYSYMBOL_KW_REPLACE_PREFIX = 204,        /* KW_REPLACE_PREFIX  */
  YYSYMBOL_KW_CAST = 205,                  /* KW_CAST  */
  YYSYMBOL_KW_UPPER = 206,                 /* KW_UPPER  */
  YYSYMBOL_KW_LOWER = 207,                 /* KW_LOWER  */
  YYSYMBOL_KW_INCLUDE_BYTES = 208,         /* KW_INCLUDE_BYTES  */
  YYSYMBOL_KW_ON_ERROR = 209,              /* KW_ON_ERROR  */
  YYSYMBOL_KW_RETRIES = 210,               /* KW_RETRIES  */
  YYSYMBOL_KW_FETCH_NO_DATA_DELAY = 211,   /* KW_FETCH_NO_DATA_DELAY  */
  YYSYMBOL_KW_LABELS = 212,                /* KW_LABELS  */
  YYSYMBOL_213_ = 213,                     /* '{'  */
  YYSYMBOL_214_ = 214,                     /* '}'  */
  YYSYMBOL_215_ = 215,                     /* '('  */
  YYSYMBOL_216_ = 216,                     /* ')'  */
  YYSYMBOL_217_ = 217,                     /* ';'  */
  YYSYMBOL_218_ = 218,                     /* ':'  */
  YYSYMBOL_YYACCEPT = 219,                 /* $accept  */
  YYSYMBOL_start = 220,                    /* start  */
  YYSYMBOL_stmts = 221,                    /* stmts  */
  YYSYMBOL_stmt = 222,                     /* stmt  */
  YYSYMBOL_expr_stmt = 223,                /* expr_stmt  */
  YYSYMBOL_source_stmt = 224,              /* source_stmt  */
  YYSYMBOL_dest_stmt = 225,                /* dest_stmt  */
  YYSYMBOL_filter_stmt = 226,              /* filter_stmt  */
  YYSYMBOL_parser_stmt = 227,              /* parser_stmt  */
  YYSYMBOL_rewrite_stmt = 228,             /* rewrite_stmt  */
  YYSYMBOL_log_stmt = 229,                 /* log_stmt  */
  YYSYMBOL_plugin_stmt = 230,              /* plugin_stmt  */
  YYSYMBOL_source_content = 231,           /* source_content  */
  YYSYMBOL_source_items = 232,             /* source_items  */
  YYSYMBOL_source_item = 233,              /* source_item  */
  YYSYMBOL_source_plugin = 234,            /* source_plugin  */
  YYSYMBOL_source_afinter = 235,           /* source_afinter  */
  YYSYMBOL_source_afinter_params = 236,    /* source_afinter_params  */
  YYSYMBOL_237_1 = 237,                    /* $@1  */
  YYSYMBOL_source_afinter_options = 238,   /* source_afinter_options  */
  YYSYMBOL_source_afinter_option = 239,    /* source_afinter_option  */
  YYSYMBOL_filter_content = 240,           /* filter_content  */
  YYSYMBOL_filterx_content = 241,          /* filterx_content  */
  YYSYMBOL_242_2 = 242,                    /* @2  */
  YYSYMBOL_parser_content = 243,           /* parser_content  */
  YYSYMBOL_rewrite_content = 244,          /* rewrite_content  */
  YYSYMBOL_dest_content = 245,             /* dest_content  */
  YYSYMBOL_dest_items = 246,               /* dest_items  */
  YYSYMBOL_dest_item = 247,                /* dest_item  */
  YYSYMBOL_dest_plugin = 248,              /* dest_plugin  */
  YYSYMBOL_log_items = 249,                /* log_items  */
  YYSYMBOL_log_item = 250,                 /* log_item  */
  YYSYMBOL_log_scheduler = 251,            /* log_scheduler  */
  YYSYMBOL_252_3 = 252,                    /* @3  */
  YYSYMBOL_log_scheduler_options = 253,    /* log_scheduler_options  */
  YYSYMBOL_log_scheduler_option = 254,     /* log_scheduler_option  */
  YYSYMBOL_log_junction = 255,             /* log_junction  */
  YYSYMBOL_log_last_junction = 256,        /* log_last_junction  */
  YYSYMBOL_log_forks = 257,                /* log_forks  */
  YYSYMBOL_log_fork = 258,                 /* log_fork  */
  YYSYMBOL_log_conditional = 259,          /* log_conditional  */
  YYSYMBOL_log_if = 260,                   /* log_if  */
  YYSYMBOL_log_content = 261,              /* log_content  */
  YYSYMBOL_log_flags = 262,                /* log_flags  */
  YYSYMBOL_log_flags_items = 263,          /* log_flags_items  */
  YYSYMBOL_options_stmt = 264,             /* options_stmt  */
  YYSYMBOL_template_stmt = 265,            /* template_stmt  */
  YYSYMBOL_template_def = 266,             /* template_def  */
  YYSYMBOL_template_block = 267,           /* template_block  */
  YYSYMBOL_268_4 = 268,                    /* @4  */
  YYSYMBOL_269_5 = 269,                    /* @5  */
  YYSYMBOL_template_simple = 270,          /* template_simple  */
  YYSYMBOL_271_6 = 271,                    /* @6  */
  YYSYMBOL_template_fn = 272,              /* template_fn  */
  YYSYMBOL_273_7 = 273,                    /* @7  */
  YYSYMBOL_template_items = 274,           /* template_items  */
  YYSYMBOL_275_8 = 275,                    /* @8  */
  YYSYMBOL_276_9 = 276,                    /* @9  */
  YYSYMBOL_template_item = 277,            /* template_item  */
  YYSYMBOL_278_10 = 278,                   /* @10  */
  YYSYMBOL_template_content_inner = 279,   /* template_content_inner  */
  YYSYMBOL_type_hint = 280,                /* type_hint  */
  YYSYMBOL_template_content = 281,         /* template_content  */
  YYSYMBOL_282_11 = 282,                   /* @11  */
  YYSYMBOL_block_stmt = 283,               /* block_stmt  */
  YYSYMBOL_284_12 = 284,                   /* $@12  */
  YYSYMBOL_block_definition = 285,         /* block_definition  */
  YYSYMBOL_block_args = 286,               /* block_args  */
  YYSYMBOL_block_arg = 287,                /* block_arg  */
  YYSYMBOL_options_items = 288,            /* options_items  */
  YYSYMBOL_options_item = 289,             /* options_item  */
  YYSYMBOL_290_13 = 290,                   /* $@13  */
  YYSYMBOL_291_14 = 291,                   /* $@14  */
  YYSYMBOL_292_15 = 292,                   /* $@15  */
  YYSYMBOL_293_16 = 293,                   /* $@16  */
  YYSYMBOL_294_17 = 294,                   /* $@17  */
  YYSYMBOL_stat_option = 295,              /* stat_option  */
  YYSYMBOL_stats_group_options = 296,      /* stats_group_options  */
  YYSYMBOL_stats_group_option = 297,       /* stats_group_option  */
  YYSYMBOL_dns_cache_option = 298,         /* dns_cache_option  */
  YYSYMBOL_string = 299,                   /* string  */
  YYSYMBOL_yesno_strict = 300,             /* yesno_strict  */
  YYSYMBOL_yesno = 301,                    /* yesno  */
  YYSYMBOL_yesnoauto = 302,                /* yesnoauto  */
  YYSYMBOL_dnsmode = 303,                  /* dnsmode  */
  YYSYMBOL_nonnegative_integer64 = 304,    /* nonnegative_integer64  */
  YYSYMBOL_nonnegative_integer = 305,      /* nonnegative_integer  */
  YYSYMBOL_positive_integer64 = 306,       /* positive_integer64  */
  YYSYMBOL_positive_integer = 307,         /* positive_integer  */
  YYSYMBOL_string_or_number = 308,         /* string_or_number  */
  YYSYMBOL_optional_string = 309,          /* optional_string  */
  YYSYMBOL_normalized_flag = 310,          /* normalized_flag  */
  YYSYMBOL_string_list = 311,              /* string_list  */
  YYSYMBOL_string_list_build = 312,        /* string_list_build  */
  YYSYMBOL_semicolons = 313,               /* semicolons  */
  YYSYMBOL_source_option = 314,            /* source_option  */
  YYSYMBOL_315_20 = 315,                   /* $@20  */
  YYSYMBOL_host_resolve_option = 316,      /* host_resolve_option  */
  YYSYMBOL_file_perm_option = 317,         /* file_perm_option  */
  YYSYMBOL_template_option = 318,          /* template_option  */
  YYSYMBOL__destination_context_push = 319, /* _destination_context_push  */
  YYSYMBOL__destination_context_pop = 320, /* _destination_context_pop  */
  YYSYMBOL__source_context_push = 321,     /* _source_context_push  */
  YYSYMBOL__source_context_pop = 322,      /* _source_context_pop  */
  YYSYMBOL__filterx_context_push = 323,    /* _filterx_context_push  */
  YYSYMBOL__filterx_context_pop = 324,     /* _filterx_context_pop  */
  YYSYMBOL__log_context_push = 325,        /* _log_context_push  */
  YYSYMBOL__log_context_pop = 326,         /* _log_context_pop  */
  YYSYMBOL__block_def_context_push = 327,  /* _block_def_context_push  */
  YYSYMBOL__block_def_context_pop = 328,   /* _block_def_context_pop  */
  YYSYMBOL__block_content_context_push = 329, /* _block_content_context_push  */
  YYSYMBOL__block_content_context_pop = 330, /* _block_content_context_pop  */
  YYSYMBOL__block_arg_context_push = 331,  /* _block_arg_context_push  */
  YYSYMBOL__block_arg_context_pop = 332,   /* _block_arg_context_pop  */
  YYSYMBOL__options_context_push = 333,    /* _options_context_push  */
  YYSYMBOL__options_context_pop = 334      /* _options_context_pop  */
};
typedef enum yysymbol_kind_t yysymbol_kind_t;



/* Unqualified %code blocks.  */
#line 59 "/source/lib/cfg-grammar.y"


#pragma GCC diagnostic ignored "-Wswitch-default"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"

#if (defined(__GNUC__) && __GNUC__ >= 6) || (defined(__clang__) && __clang_major__ >= 10)
#  pragma GCC diagnostic ignored "-Wmisleading-indentation"
#endif


# define YYLLOC_DEFAULT(Current, Rhs, N)                                \
  do {                                                                  \
    if (N)                                                              \
      {                                                                 \
        (Current).name         = YYRHSLOC(Rhs, 1).name;                 \
        (Current).first_line   = YYRHSLOC (Rhs, 1).first_line;          \
        (Current).first_column = YYRHSLOC (Rhs, 1).first_column;        \
        (Current).last_line    = YYRHSLOC (Rhs, N).last_line;           \
        (Current).last_column  = YYRHSLOC (Rhs, N).last_column;         \
      }                                                                 \
    else                                                                \
      {                                                                 \
        (Current).name         = YYRHSLOC(Rhs, 0).name;                 \
        (Current).first_line   = (Current).last_line   =                \
          YYRHSLOC (Rhs, 0).last_line;                                  \
        (Current).first_column = (Current).last_column =                \
          YYRHSLOC (Rhs, 0).last_column;                                \
      }                                                                 \
  } while (0)

#define CHECK_ERROR_WITHOUT_MESSAGE(val, token) do {                    \
    if (!(val))                                                         \
      {                                                                 \
        YYERROR;                                                        \
      }                                                                 \
  } while (0)

#define CHECK_ERROR(val, token, errorfmt, ...) do {                     \
    if (!(val))                                                         \
      {                                                                 \
        if (errorfmt)                                                   \
          {                                                             \
            gchar __buf[256];                                           \
            g_snprintf(__buf, sizeof(__buf), errorfmt, ## __VA_ARGS__); \
            yyerror(& (token), lexer, NULL, NULL, __buf);               \
          }                                                             \
        YYERROR;                                                        \
      }                                                                 \
  } while (0)

#define CHECK_ERROR_GERROR(val, token, error, errorfmt, ...) do {       \
    if (!(val))                                                         \
      {                                                                 \
        if (errorfmt)                                                   \
          {                                                             \
            gchar __buf[256];                                           \
            g_snprintf(__buf, sizeof(__buf), errorfmt ", error=%s", ## __VA_ARGS__, error->message); \
            yyerror(& (token), lexer, NULL, NULL, __buf);               \
          }                                                             \
        g_clear_error(&error);						\
        YYERROR;                                                        \
      }                                                                 \
  } while (0)

#define YYMAXDEPTH 20000



#line 995 "lib/cfg-grammar.c"

#ifdef short
# undef short
#endif

/* On compilers that do not define __PTRDIFF_MAX__ etc., make sure
   <limits.h> and (if available) <stdint.h> are included
   so that the code can choose integer types of a good width.  */

#ifndef __PTRDIFF_MAX__
# include <limits.h> /* INFRINGES ON USER NAME SPACE */
# if defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stdint.h> /* INFRINGES ON USER NAME SPACE */
#  define YY_STDINT_H
# endif
#endif

/* Narrow types that promote to a signed type and that can represent a
   signed or unsigned integer of at least N bits.  In tables they can
   save space and decrease cache pressure.  Promoting to a signed type
   helps avoid bugs in integer arithmetic.  */

#ifdef __INT_LEAST8_MAX__
typedef __INT_LEAST8_TYPE__ yytype_int8;
#elif defined YY_STDINT_H
typedef int_least8_t yytype_int8;
#else
typedef signed char yytype_int8;
#endif

#ifdef __INT_LEAST16_MAX__
typedef __INT_LEAST16_TYPE__ yytype_int16;
#elif defined YY_STDINT_H
typedef int_least16_t yytype_int16;
#else
typedef short yytype_int16;
#endif

/* Work around bug in HP-UX 11.23, which defines these macros
   incorrectly for preprocessor constants.  This workaround can likely
   be removed in 2023, as HPE has promised support for HP-UX 11.23
   (aka HP-UX 11i v2) only through the end of 2022; see Table 2 of
   <https://h20195.www2.hpe.com/V2/getpdf.aspx/4AA4-7673ENW.pdf>.  */
#ifdef __hpux
# undef UINT_LEAST8_MAX
# undef UINT_LEAST16_MAX
# define UINT_LEAST8_MAX 255
# define UINT_LEAST16_MAX 65535
#endif

#if defined __UINT_LEAST8_MAX__ && __UINT_LEAST8_MAX__ <= __INT_MAX__
typedef __UINT_LEAST8_TYPE__ yytype_uint8;
#elif (!defined __UINT_LEAST8_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST8_MAX <= INT_MAX)
typedef uint_least8_t yytype_uint8;
#elif !defined __UINT_LEAST8_MAX__ && UCHAR_MAX <= INT_MAX
typedef unsigned char yytype_uint8;
#else
typedef short yytype_uint8;
#endif

#if defined __UINT_LEAST16_MAX__ && __UINT_LEAST16_MAX__ <= __INT_MAX__
typedef __UINT_LEAST16_TYPE__ yytype_uint16;
#elif (!defined __UINT_LEAST16_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST16_MAX <= INT_MAX)
typedef uint_least16_t yytype_uint16;
#elif !defined __UINT_LEAST16_MAX__ && USHRT_MAX <= INT_MAX
typedef unsigned short yytype_uint16;
#else
typedef int yytype_uint16;
#endif

#ifndef YYPTRDIFF_T
# if defined __PTRDIFF_TYPE__ && defined __PTRDIFF_MAX__
#  define YYPTRDIFF_T __PTRDIFF_TYPE__
#  define YYPTRDIFF_MAXIMUM __PTRDIFF_MAX__
# elif defined PTRDIFF_MAX
#  ifndef ptrdiff_t
#   include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  endif
#  define YYPTRDIFF_T ptrdiff_t
#  define YYPTRDIFF_MAXIMUM PTRDIFF_MAX
# else
#  define YYPTRDIFF_T long
#  define YYPTRDIFF_MAXIMUM LONG_MAX
# endif
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned
# endif
#endif

#define YYSIZE_MAXIMUM                                  \
  YY_CAST (YYPTRDIFF_T,                                 \
           (YYPTRDIFF_MAXIMUM < YY_CAST (YYSIZE_T, -1)  \
            ? YYPTRDIFF_MAXIMUM                         \
            : YY_CAST (YYSIZE_T, -1)))

#define YYSIZEOF(X) YY_CAST (YYPTRDIFF_T, sizeof (X))


/* Stored state numbers (used for stacks). */
typedef yytype_int16 yy_state_t;

/* State numbers in computations.  */
typedef int yy_state_fast_t;

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(Msgid) dgettext ("bison-runtime", Msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(Msgid) Msgid
# endif
#endif


#ifndef YY_ATTRIBUTE_PURE
# if defined __GNUC__ && 2 < __GNUC__ + (96 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_PURE __attribute__ ((__pure__))
# else
#  define YY_ATTRIBUTE_PURE
# endif
#endif

#ifndef YY_ATTRIBUTE_UNUSED
# if defined __GNUC__ && 2 < __GNUC__ + (7 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_UNUSED __attribute__ ((__unused__))
# else
#  define YY_ATTRIBUTE_UNUSED
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YY_USE(E) ((void) (E))
#else
# define YY_USE(E) /* empty */
#endif

/* Suppress an incorrect diagnostic about yylval being uninitialized.  */
#if defined __GNUC__ && ! defined __ICC && 406 <= __GNUC__ * 100 + __GNUC_MINOR__
# if __GNUC__ * 100 + __GNUC_MINOR__ < 407
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")
# else
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")              \
    _Pragma ("GCC diagnostic ignored \"-Wmaybe-uninitialized\"")
# endif
# define YY_IGNORE_MAYBE_UNINITIALIZED_END      \
    _Pragma ("GCC diagnostic pop")
#else
# define YY_INITIAL_VALUE(Value) Value
#endif
#ifndef YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_END
#endif
#ifndef YY_INITIAL_VALUE
# define YY_INITIAL_VALUE(Value) /* Nothing. */
#endif

#if defined __cplusplus && defined __GNUC__ && ! defined __ICC && 6 <= __GNUC__
# define YY_IGNORE_USELESS_CAST_BEGIN                          \
    _Pragma ("GCC diagnostic push")                            \
    _Pragma ("GCC diagnostic ignored \"-Wuseless-cast\"")
# define YY_IGNORE_USELESS_CAST_END            \
    _Pragma ("GCC diagnostic pop")
#endif
#ifndef YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_END
#endif


#define YY_ASSERT(E) ((void) (0 && (E)))

#if 1

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined EXIT_SUCCESS
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
      /* Use EXIT_SUCCESS as a witness for stdlib.h.  */
#     ifndef EXIT_SUCCESS
#      define EXIT_SUCCESS 0
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's 'empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined EXIT_SUCCESS \
       && ! ((defined YYMALLOC || defined malloc) \
             && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef EXIT_SUCCESS
#    define EXIT_SUCCESS 0
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined EXIT_SUCCESS
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined EXIT_SUCCESS
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* 1 */

#if (! defined yyoverflow \
     && (! defined __cplusplus \
         || (defined MAIN_LTYPE_IS_TRIVIAL && MAIN_LTYPE_IS_TRIVIAL \
             && defined MAIN_STYPE_IS_TRIVIAL && MAIN_STYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yy_state_t yyss_alloc;
  YYSTYPE yyvs_alloc;
  YYLTYPE yyls_alloc;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (YYSIZEOF (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (YYSIZEOF (yy_state_t) + YYSIZEOF (YYSTYPE) \
             + YYSIZEOF (YYLTYPE)) \
      + 2 * YYSTACK_GAP_MAXIMUM)

# define YYCOPY_NEEDED 1

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack_alloc, Stack)                           \
    do                                                                  \
      {                                                                 \
        YYPTRDIFF_T yynewbytes;                                         \
        YYCOPY (&yyptr->Stack_alloc, Stack, yysize);                    \
        Stack = &yyptr->Stack_alloc;                                    \
        yynewbytes = yystacksize * YYSIZEOF (*Stack) + YYSTACK_GAP_MAXIMUM; \
        yyptr += yynewbytes / YYSIZEOF (*yyptr);                        \
      }                                                                 \
    while (0)

#endif

#if defined YYCOPY_NEEDED && YYCOPY_NEEDED
/* Copy COUNT objects from SRC to DST.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(Dst, Src, Count) \
      __builtin_memcpy (Dst, Src, YY_CAST (YYSIZE_T, (Count)) * sizeof (*(Src)))
#  else
#   define YYCOPY(Dst, Src, Count)              \
      do                                        \
        {                                       \
          YYPTRDIFF_T yyi;                      \
          for (yyi = 0; yyi < (Count); yyi++)   \
            (Dst)[yyi] = (Src)[yyi];            \
        }                                       \
      while (0)
#  endif
# endif
#endif /* !YYCOPY_NEEDED */

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  43
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   694

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  219
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  116
/* YYNRULES -- Number of rules.  */
#define YYNRULES  256
/* YYNSTATES -- Number of states.  */
#define YYNSTATES  605

/* YYMAXUTOK -- Last valid token kind.  */
#define YYMAXUTOK   10531


/* YYTRANSLATE(TOKEN-NUM) -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex, with out-of-bounds checking.  */
#define YYTRANSLATE(YYX)                                \
  (0 <= (YYX) && (YYX) <= YYMAXUTOK                     \
   ? YY_CAST (yysymbol_kind_t, yytranslate[YYX])        \
   : YYSYMBOL_YYUNDEF)

/* YYTRANSLATE[TOKEN-NUM] -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex.  */
static const yytype_uint8 yytranslate[] =
{
       0,     3,     4,     5,     6,     7,     8,     9,    10,    11,
      12,    13,    14,    15,    16,    17,    18,    19,    20,    21,
      22,    23,    24,    25,    26,    27,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     215,   216,    48,    46,     2,    47,    50,    49,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,   218,   217,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,    51,     2,    52,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,   213,     2,   214,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
      28,    29,    30,    31,    32,    33,    34,    35,    36,    37,
      38,    39,    40,    41,    42,    43,    44,    53,    45,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
      54,    55,    56,    57,    58,    59,    60,    61,    62,    63,
      64,    65,    66,    67,     2,     2,     2,     2,     2,     2,
      68,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
      69,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,    70,    71,    72,    73,    74,    75,    76,    77,    78,
      79,    80,    81,    82,    83,    84,    85,    86,    87,    88,
      97,    98,    99,   100,   101,   102,     2,     2,     2,     2,
     103,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     104,   105,   106,     2,     2,     2,     2,     2,     2,     2,
     107,   108,     2,     2,     2,     2,     2,     2,     2,     2,
     109,   110,   111,     2,     2,     2,     2,     2,     2,     2,
     112,   113,   114,     2,     2,     2,     2,     2,     2,     2,
     115,   116,   117,     2,     2,     2,     2,     2,     2,     2,
     118,     2,   119,   120,   121,   122,   123,     2,     2,     2,
     124,   125,     2,     2,     2,     2,     2,     2,     2,     2,
     126,   127,   128,   129,     2,     2,     2,     2,     2,     2,
     130,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     131,   132,   133,   134,   135,   136,   137,   138,   139,   140,
     141,   142,   143,   144,   145,   146,     2,     2,     2,     2,
     147,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     148,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     149,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     150,   151,   152,     2,     2,     2,     2,     2,     2,     2,
     153,   154,   155,     2,     2,     2,     2,     2,     2,     2,
     156,   157,   158,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     159,   160,   161,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,   162,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     163,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     164,   165,   166,   167,   168,   169,   170,   171,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     172,   173,   174,     2,     2,     2,     2,     2,     2,     2,
     175,   176,   177,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
      89,    90,    91,    92,    93,    94,    95,    96,     2,     2,
     178,   179,     2,     2,     2,     2,     2,     2,     2,     2,
     180,   181,   182,   183,   184,   185,     2,     2,     2,     2,
     186,   187,   188,   189,   190,   191,   192,   193,   194,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     195,     2,   196,   197,   198,   199,   200,   201,   202,   203,
     204,   205,   206,   207,   208,     2,     2,     2,     2,     2,
     209,   210,   211,     2,     2,     2,     2,     2,     2,     2,
     212,     2
};

#if MAIN_DEBUG
/* YYRLINE[YYN] -- Source line where rule number YYN was defined.  */
static const yytype_int16 yyrline[] =
{
       0,   483,   483,   487,   488,   492,   496,   497,   498,   499,
     503,   504,   505,   506,   507,   508,   512,   519,   528,   545,
     553,   560,   573,   592,   596,   597,   598,   602,   603,   607,
     626,   630,   630,   638,   639,   643,   644,   649,   659,   659,
     670,   680,   689,   695,   696,   697,   701,   705,   724,   725,
     729,   730,   731,   732,   733,   734,   735,   736,   737,   738,
     739,   740,   741,   742,   747,   746,   756,   757,   761,   765,
     773,   785,   790,   791,   795,   804,   816,   817,   825,   829,
     833,   841,   852,   856,   857,   861,   862,   868,   872,   876,
     885,   886,   891,   894,   890,   899,   898,   907,   906,   914,
     914,   914,   915,   919,   919,   920,   927,   934,   943,   951,
     959,   970,   970,   997,   994,  1018,  1019,  1023,  1024,  1028,
    1032,  1033,  1037,  1038,  1039,  1040,  1046,  1047,  1048,  1049,
    1050,  1051,  1052,  1053,  1054,  1055,  1056,  1057,  1058,  1059,
    1060,  1061,  1062,  1063,  1064,  1065,  1066,  1067,  1068,  1069,
    1070,  1071,  1072,  1072,  1073,  1073,  1074,  1074,  1075,  1075,
    1076,  1076,  1077,  1091,  1092,  1093,  1094,  1095,  1099,  1100,
    1104,  1105,  1106,  1107,  1108,  1109,  1113,  1114,  1115,  1117,
    1125,  1126,  1130,  1131,  1135,  1136,  1140,  1141,  1142,  1146,
    1147,  1151,  1158,  1165,  1172,  1201,  1202,  1203,  1207,  1208,
    1234,  1238,  1242,  1243,  1247,  1248,  1415,  1416,  1417,  1418,
    1419,  1420,  1421,  1422,  1423,  1424,  1425,  1425,  1461,  1462,
    1463,  1464,  1521,  1522,  1523,  1524,  1525,  1526,  1527,  1528,
    1529,  1530,  1531,  1532,  1536,  1537,  1538,  1539,  1540,  1541,
    1542,  1705,  1706,  1707,  1708,  1715,  1716,  1717,  1718,  1719,
    1720,  1723,  1724,  1725,  1726,  1732,  1733
};
#endif

/** Accessing symbol of state STATE.  */
#define YY_ACCESSING_SYMBOL(State) YY_CAST (yysymbol_kind_t, yystos[State])

#if 1
/* The user-facing name of the symbol whose (internal) number is
   YYSYMBOL.  No bounds checking.  */
static const char *yysymbol_name (yysymbol_kind_t yysymbol) YY_ATTRIBUTE_UNUSED;

/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "\"end of file\"", "error", "\"invalid token\"", "LL_CONTEXT_ROOT",
  "LL_CONTEXT_DESTINATION", "LL_CONTEXT_SOURCE", "LL_CONTEXT_PARSER",
  "LL_CONTEXT_REWRITE", "LL_CONTEXT_FILTER", "LL_CONTEXT_LOG",
  "LL_CONTEXT_BLOCK_DEF", "LL_CONTEXT_BLOCK_REF",
  "LL_CONTEXT_BLOCK_CONTENT", "LL_CONTEXT_BLOCK_ARG", "LL_CONTEXT_PRAGMA",
  "LL_CONTEXT_FORMAT", "LL_CONTEXT_TEMPLATE_FUNC", "LL_CONTEXT_INNER_DEST",
  "LL_CONTEXT_INNER_SRC", "LL_CONTEXT_CLIENT_PROTO",
  "LL_CONTEXT_SERVER_PROTO", "LL_CONTEXT_OPTIONS", "LL_CONTEXT_CONFIG",
  "LL_CONTEXT_TEMPLATE_REF", "LL_CONTEXT_FILTERX",
  "LL_CONTEXT_FILTERX_FUNC", "LL_CONTEXT_FILTERX_ENUM", "LL_CONTEXT_MAX",
  "KW_ASSIGN", "KW_OR", "KW_AND", "KW_STR_EQ", "KW_STR_NE", "KW_TA_EQ",
  "KW_TA_NE", "KW_TAV_EQ", "KW_TAV_NE", "KW_STR_LT", "KW_STR_LE",
  "KW_STR_GE", "KW_STR_GT", "KW_TA_LT", "KW_TA_LE", "KW_TA_GE", "KW_TA_GT",
  "KW_PLUS_ASSIGN", "'+'", "'-'", "'*'", "'/'", "'.'", "'['", "']'",
  "KW_NOT", "KW_SOURCE", "KW_FILTER", "KW_PARSER", "KW_DESTINATION",
  "KW_LOG", "KW_OPTIONS", "KW_INCLUDE", "KW_BLOCK", "KW_JUNCTION",
  "KW_CHANNEL", "KW_IF", "KW_ELSE", "KW_ELIF", "KW_FILTERX", "KW_INTERNAL",
  "KW_SYSLOG", "KW_MARK_FREQ", "KW_STATS_FREQ", "KW_STATS_LEVEL",
  "KW_STATS_LIFETIME", "KW_FLUSH_LINES", "KW_SUPPRESS", "KW_FLUSH_TIMEOUT",
  "KW_LOG_MSG_SIZE", "KW_FILE_TEMPLATE", "KW_PROTO_TEMPLATE",
  "KW_MARK_MODE", "KW_ENCODING", "KW_TYPE", "KW_STATS_MAX_DYNAMIC",
  "KW_MIN_IW_SIZE_PER_READER", "KW_WORKERS", "KW_BATCH_LINES",
  "KW_BATCH_TIMEOUT", "KW_TRIM_LARGE_MESSAGES", "KW_STATS", "KW_FREQ",
  "KW_LEVEL", "KW_LIFETIME", "KW_MAX_DYNAMIC", "KW_SYSLOG_STATS",
  "KW_HEALTHCHECK_FREQ", "KW_WORKER_PARTITION_KEY", "KW_CHAIN_HOSTNAMES",
  "KW_NORMALIZE_HOSTNAMES", "KW_KEEP_HOSTNAME", "KW_CHECK_HOSTNAME",
  "KW_BAD_HOSTNAME", "KW_LOG_LEVEL", "KW_KEEP_TIMESTAMP", "KW_USE_DNS",
  "KW_USE_FQDN", "KW_CUSTOM_DOMAIN", "KW_DNS_CACHE", "KW_DNS_CACHE_SIZE",
  "KW_DNS_CACHE_EXPIRE", "KW_DNS_CACHE_EXPIRE_FAILED",
  "KW_DNS_CACHE_HOSTS", "KW_PERSIST_ONLY", "KW_USE_RCPTID",
  "KW_USE_UNIQID", "KW_TZ_CONVERT", "KW_TS_FORMAT", "KW_FRAC_DIGITS",
  "KW_LOG_FIFO_SIZE", "KW_LOG_FETCH_LIMIT", "KW_LOG_IW_SIZE",
  "KW_LOG_PREFIX", "KW_PROGRAM_OVERRIDE", "KW_HOST_OVERRIDE",
  "KW_THROTTLE", "KW_THREADED", "KW_PASS_UNIX_CREDENTIALS",
  "KW_PERSIST_NAME", "KW_READ_OLD_RECORDS", "KW_USE_SYSLOGNG_PID",
  "KW_FLAGS", "KW_PAD_SIZE", "KW_TIME_ZONE", "KW_RECV_TIME_ZONE",
  "KW_SEND_TIME_ZONE", "KW_LOCAL_TIME_ZONE", "KW_FORMAT",
  "KW_MULTI_LINE_MODE", "KW_MULTI_LINE_PREFIX", "KW_MULTI_LINE_GARBAGE",
  "KW_TRUNCATE_SIZE", "KW_TIME_REOPEN", "KW_TIME_REAP", "KW_TIME_SLEEP",
  "KW_PARTITIONS", "KW_PARTITION_KEY", "KW_PARALLELIZE", "KW_TMPL_ESCAPE",
  "KW_OPTIONAL", "KW_CREATE_DIRS", "KW_OWNER", "KW_GROUP", "KW_PERM",
  "KW_DIR_OWNER", "KW_DIR_GROUP", "KW_DIR_PERM", "KW_TEMPLATE",
  "KW_TEMPLATE_ESCAPE", "KW_TEMPLATE_FUNCTION", "KW_DEFAULT_FACILITY",
  "KW_DEFAULT_SEVERITY", "KW_SDATA_PREFIX", "KW_PORT", "KW_USE_TIME_RECVD",
  "KW_FACILITY", "KW_SEVERITY", "KW_HOST", "KW_MATCH", "KW_MESSAGE",
  "KW_NETMASK", "KW_TAGS", "KW_NETMASK6", "KW_REWRITE", "KW_CONDITION",
  "KW_VALUE", "KW_YES", "KW_NO", "KW_AUTO", "KW_IFDEF", "KW_ENDIF",
  "LL_DOTDOT", "LL_DOTDOTDOT", "LL_PRAGMA", "LL_EOL", "LL_ERROR",
  "LL_ARROW", "LL_IDENTIFIER", "LL_NUMBER", "LL_FLOAT", "LL_STRING",
  "LL_TOKEN", "LL_BLOCK", "LL_PLUGIN", "LL_TEMPLATE_REF", "LL_MESSAGE_REF",
  "KW_VALUE_PAIRS", "KW_EXCLUDE", "KW_PAIR", "KW_KEY", "KW_SCOPE",
  "KW_SHIFT", "KW_SHIFT_LEVELS", "KW_REKEY", "KW_ADD_PREFIX",
  "KW_REPLACE_PREFIX", "KW_CAST", "KW_UPPER", "KW_LOWER",
  "KW_INCLUDE_BYTES", "KW_ON_ERROR", "KW_RETRIES",
  "KW_FETCH_NO_DATA_DELAY", "KW_LABELS", "'{'", "'}'", "'('", "')'", "';'",
  "':'", "$accept", "start", "stmts", "stmt", "expr_stmt", "source_stmt",
  "dest_stmt", "filter_stmt", "parser_stmt", "rewrite_stmt", "log_stmt",
  "plugin_stmt", "source_content", "source_items", "source_item",
  "source_plugin", "source_afinter", "source_afinter_params", "$@1",
  "source_afinter_options", "source_afinter_option", "filter_content",
  "filterx_content", "@2", "parser_content", "rewrite_content",
  "dest_content", "dest_items", "dest_item", "dest_plugin", "log_items",
  "log_item", "log_scheduler", "@3", "log_scheduler_options",
  "log_scheduler_option", "log_junction", "log_last_junction", "log_forks",
  "log_fork", "log_conditional", "log_if", "log_content", "log_flags",
  "log_flags_items", "options_stmt", "template_stmt", "template_def",
  "template_block", "@4", "@5", "template_simple", "@6", "template_fn",
  "@7", "template_items", "@8", "@9", "template_item", "@10",
  "template_content_inner", "type_hint", "template_content", "@11",
  "block_stmt", "$@12", "block_definition", "block_args", "block_arg",
  "options_items", "options_item", "$@13", "$@14", "$@15", "$@16", "$@17",
  "stat_option", "stats_group_options", "stats_group_option",
  "dns_cache_option", "string", "yesno_strict", "yesno", "yesnoauto",
  "dnsmode", "nonnegative_integer64", "nonnegative_integer",
  "positive_integer64", "positive_integer", "string_or_number",
  "optional_string", "normalized_flag", "string_list", "string_list_build",
  "semicolons", "source_option", "$@20", "host_resolve_option",
  "file_perm_option", "template_option", "_destination_context_push",
  "_destination_context_pop", "_source_context_push",
  "_source_context_pop", "_filterx_context_push", "_filterx_context_pop",
  "_log_context_push", "_log_context_pop", "_block_def_context_push",
  "_block_def_context_pop", "_block_content_context_push",
  "_block_content_context_pop", "_block_arg_context_push",
  "_block_arg_context_pop", "_options_context_push",
  "_options_context_pop", YY_NULLPTR
};

static const char *
yysymbol_name (yysymbol_kind_t yysymbol)
{
  return yytname[yysymbol];
}
#endif

#define YYPACT_NINF (-226)

#define yypact_value_is_default(Yyn) \
  ((Yyn) == YYPACT_NINF)

#define YYTABLE_NINF (-161)

#define yytable_value_is_error(Yyn) \
  0

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
static const yytype_int16 yypact[] =
{
     -31,  -137,  -137,  -137,  -137,  -137,  -226,  -226,  -137,  -137,
    -137,  -226,    15,  -226,  -183,  -226,  -226,  -226,  -226,  -226,
    -226,  -226,  -226,  -226,  -226,  -226,  -226,  -226,  -226,  -226,
    -226,  -226,  -175,  -166,  -125,  -115,  -226,  -226,  -110,   -85,
     -58,  -226,   -50,  -226,  -183,   -31,  -226,  -226,  -226,  -226,
     -41,   480,   -18,   -28,  -117,  -117,  -226,  -226,  -226,   -86,
     -47,   -12,    -9,    -7,   -26,   142,   -46,   -27,   -14,     5,
       6,     8,    10,    12,    28,    43,    44,    45,    47,    48,
      49,    50,    51,    52,    53,    54,    55,    56,    57,    58,
      59,    60,    61,    62,    63,  -226,    -6,  -183,   -35,    42,
      46,   141,    79,    64,  -226,    65,  -226,  -226,  -226,    66,
    -226,  -226,    -4,  -226,  -137,  -137,    69,  -226,  -226,  -183,
    -226,  -226,  -183,  -226,  -226,  -226,  -226,  -226,  -183,  -226,
    -183,  -154,  -128,   -79,   -65,   -19,   -57,    77,    76,   -42,
     -22,  -183,  -226,  -226,  -226,     0,    68,    70,    70,    70,
      74,    74,  -137,  -137,   -56,    74,  -136,  -136,  -136,  -136,
    -137,  -137,  -136,  -137,  -136,  -136,    74,    74,    74,  -136,
    -136,  -137,    74,    70,    70,  -136,  -226,   480,    78,    80,
      81,    82,    83,    85,    88,  -226,    89,    90,    91,    92,
    -226,    93,    94,    95,    96,    97,  -226,    98,   100,   101,
     102,  -226,   103,   104,   105,   106,   107,   108,  -226,  -226,
     110,    67,  -226,   112,   113,  -226,  -226,   -47,   -47,  -226,
     -26,   -26,  -226,  -137,  -226,  -137,  -226,  -137,  -226,  -137,
     -22,   142,  -226,  -226,  -226,  -226,  -137,   162,  -226,  -183,
     142,   114,   -20,  -226,  -226,  -226,   115,   116,   117,  -226,
    -226,   118,   119,   120,   121,   122,   123,   124,  -226,  -226,
    -226,  -226,   125,   126,   127,   128,   129,   131,   132,   133,
     134,   135,   136,   137,   138,   143,   145,   147,   148,   149,
     151,   152,  -226,  -226,  -137,    70,  -137,  -137,  -137,  -136,
    -137,  -136,   -81,  -136,  -136,    70,    70,    74,    70,   146,
      74,    74,    74,  -137,  -112,    -5,  -168,    26,    30,  -152,
     144,   155,   -78,  -226,  -226,  -226,   154,   142,   142,   156,
     -13,  -226,  -226,  -226,  -226,   157,   158,   159,   160,   161,
     163,   164,   165,   166,   168,   167,   170,  -226,   -21,   171,
     173,   172,  -226,   -22,  -226,   142,   142,  -226,  -226,  -226,
    -226,  -226,  -226,  -226,  -226,  -226,  -226,  -226,  -226,  -226,
    -226,  -226,  -226,  -226,  -226,  -226,  -226,  -226,  -226,  -226,
    -226,  -226,  -226,  -226,  -226,  -226,  -226,  -226,  -226,   174,
     175,   176,   177,   180,   182,   183,   184,  -226,  -226,   185,
     186,   187,   188,   189,   190,   192,   194,   195,   199,   200,
     201,   202,   205,   146,   206,   207,   208,   209,  -226,   210,
    -226,   211,   212,  -226,  -226,   213,  -226,   214,   215,  -226,
    -226,   216,   181,   144,  -226,   203,   218,  -183,  -226,   220,
     221,  -226,   222,   223,   224,   225,   226,   227,   228,   229,
     230,   231,   232,  -226,   -13,  -226,    42,  -226,  -226,  -226,
    -226,  -226,  -226,  -226,  -226,  -226,  -226,   235,  -226,  -226,
     234,   236,   237,   -21,  -226,  -226,  -137,  -226,   238,   240,
     239,  -226,  -226,  -226,  -226,  -226,  -226,  -226,  -226,  -226,
    -226,  -226,  -226,  -226,  -226,  -226,    70,    70,    74,    70,
     -33,    70,  -226,  -226,  -226,  -226,  -226,  -226,  -226,  -226,
    -226,  -226,  -226,  -226,   245,  -226,  -226,  -226,  -226,  -136,
    -226,  -226,  -226,  -136,  -136,  -136,    74,    74,  -137,  -137,
    -137,  -136,  -136,  -137,  -226,  -226,   142,  -226,    70,  -226,
    -226,  -226,   241,  -226,  -137,  -226,  -226,   243,   242,   244,
     246,   247,  -226,  -226,  -226,   248,   250,  -226,   259,  -117,
     251,   110,   252,   253,   254,   255,   256,   257,   258,   260,
     261,   262,  -137,   263,  -226,   266,   265,   267,  -117,  -183,
    -226,   142,  -226,  -226,  -226,  -226,  -226,  -226,  -226,  -226,
     268,  -226,  -226,  -226,  -226,  -226,  -226,  -226,  -226,  -226,
    -226,  -226,  -226,  -226,  -226,  -226,  -226,  -226,  -226,  -226,
     271,  -226,  -226,  -226,  -226
};

/* YYDEFACT[STATE-NUM] -- Default reduction number in state STATE-NUM.
   Performed when YYTABLE does not specify something else to do.  Zero
   means the default is an error.  */
static const yytype_int16 yydefact[] =
{
       4,     0,     0,     0,     0,   199,   255,   249,     0,     0,
       0,    22,     0,     2,     0,     5,    10,    11,    12,    13,
      14,    15,     9,     7,     6,    88,    90,    91,    89,     8,
     180,   181,     0,     0,     0,     0,   198,   247,     0,     0,
      95,    97,     0,     1,   204,     4,   243,    37,    40,   241,
       0,   152,     0,     0,     0,     0,    41,   205,     3,     0,
      26,     0,     0,     0,    45,    49,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   162,     0,     0,     0,     0,
       0,     0,     0,     0,    93,   180,   108,   109,    96,     0,
     106,    98,     0,    16,   199,   199,     0,    29,   244,     0,
      28,    27,     0,    18,    19,    17,    47,   242,     0,    46,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      73,     0,    61,    63,    62,    76,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   256,   152,     0,     0,
       0,     0,     0,     0,     0,   153,     0,     0,     0,     0,
     155,     0,     0,     0,     0,     0,   157,     0,     0,     0,
       0,   159,     0,     0,     0,     0,     0,     0,   161,   113,
      99,     0,    20,     0,     0,    31,    23,    26,    26,    42,
      45,    45,   243,     0,    37,     0,    40,     0,   241,     0,
      73,    49,    37,   245,    64,    41,     0,    84,    71,     0,
      49,     0,     0,   248,   191,   192,     0,     0,     0,   193,
     194,     0,     0,     0,     0,     0,     0,     0,   182,   183,
     185,   184,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,    87,   120,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   169,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     118,     0,     0,   196,   197,   195,     0,    49,    49,     0,
     216,    24,    25,    43,    44,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,    38,    67,     0,
       0,     0,    82,    73,    48,    49,    49,    37,    21,   122,
     123,   134,   126,   142,   147,   148,   124,   125,   150,   143,
     127,   128,   129,   130,   151,   144,   146,   137,   138,   139,
     141,   140,   135,   136,   149,   131,   132,   133,   145,     0,
       0,     0,     0,     0,     0,     0,     0,   190,   189,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   169,     0,     0,     0,     0,   223,     0,
     225,     0,     0,   227,   229,     0,   231,     0,     0,   233,
     253,     0,   115,   118,    94,     0,     0,     0,   107,     0,
       0,    30,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,    32,   216,    36,     0,    51,    50,    53,
      52,    56,    55,    60,    59,    70,    79,     0,    54,   246,
       0,     0,     0,    67,    58,    57,    86,    72,     0,     0,
       0,   234,   235,   236,   237,   238,   239,   240,   221,   219,
     218,   220,   163,   164,   165,   166,     0,     0,     0,     0,
       0,     0,   167,   168,   176,   177,   178,   179,   222,   224,
     226,   228,   230,   232,     0,   251,   116,   117,   103,     0,
     100,    74,    75,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   203,    33,   217,    49,    39,     0,   111,
      65,    66,     0,   200,    86,    77,    81,     0,     0,     0,
       0,     0,   186,   187,   188,     0,     0,   254,     0,     0,
       0,    99,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   203,     0,   201,     0,     0,     0,     0,     0,
      85,    49,   170,   171,   172,   173,   174,   175,   119,   252,
       0,   105,   101,   207,   208,   212,    35,   206,   211,   209,
     210,   213,   214,   202,   215,    78,    68,    69,   112,    83,
       0,   250,   104,    80,   114
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -226,  -226,   249,  -226,  -226,  -226,  -226,  -226,  -226,  -226,
    -226,  -226,   264,  -106,  -226,  -226,  -226,  -226,  -226,  -116,
    -226,  -210,  -226,  -226,   233,   270,   269,   -89,  -226,  -226,
     272,  -226,  -226,  -226,  -134,  -226,  -226,  -226,  -217,   -44,
    -226,  -226,  -225,  -226,  -177,  -226,  -226,  -226,  -226,  -226,
    -226,  -226,  -226,  -226,  -226,  -174,  -226,  -226,  -226,  -226,
     -45,  -226,  -226,  -226,  -226,  -226,  -226,   -37,  -226,   284,
    -226,  -226,  -226,  -226,  -226,  -226,  -226,    72,  -226,  -226,
      -1,  -226,  -102,  -226,  -226,  -226,  -131,  -226,  -122,   -60,
      24,  -226,  -226,   -80,   -39,  -226,  -226,    41,  -226,  -226,
    -226,  -226,  -226,  -226,  -226,  -226,  -226,  -226,  -226,  -226,
    -226,  -226,  -226,  -226,  -226,  -226
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
       0,    12,    13,    14,    15,    16,    17,    18,    19,    20,
      21,    22,    59,   118,   119,   120,   121,   319,   320,   443,
     444,    61,   336,   459,    62,   112,    63,   127,   128,   129,
     140,   141,   142,   338,   462,   463,   143,   237,   238,   122,
     144,   145,   146,   342,   532,    23,    24,    25,    26,    53,
     210,    27,    54,    28,    55,   311,   312,   551,   427,   549,
     108,   109,   567,   568,    29,   310,   421,   422,   423,    96,
      97,    98,    99,   100,   101,   102,   196,   402,   403,   201,
     315,   261,   262,   545,   389,   245,   246,   250,   251,   316,
      37,   534,   563,   564,    45,   445,   446,   190,   208,   185,
      64,   219,    60,   216,   337,   527,    50,   348,    39,   604,
     548,   601,   504,   578,    38,   282
};

/* YYTABLE[YYPACT[STATE-NUM]] -- What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule whose
   number is the opposite.  If YYTABLE_NINF, syntax error.  */
static const yytype_int16 yytable[] =
{
      32,    33,    34,    35,    36,    57,   334,    40,    41,    42,
     111,   114,   255,   333,   327,    43,   115,   247,   248,   412,
     130,   116,   335,     1,     2,     3,     4,     5,     6,   252,
       7,   387,   114,   257,    44,   418,   114,   115,    46,   258,
     259,   115,   279,   280,   272,   273,   274,    47,   413,    30,
     278,   260,    31,   110,   110,   263,   264,   265,   177,   222,
     268,   223,   270,   271,   419,   241,   242,   275,   276,   105,
     106,   107,    31,   281,    30,   313,   314,    31,   425,   426,
     217,   178,   179,   218,   432,   224,   433,   225,    48,   220,
     434,   221,   429,   430,   258,   259,   239,   180,    49,   181,
     182,    52,   240,    51,   408,   435,   260,   436,   437,   438,
     439,   321,   322,    36,    36,   440,   441,   191,   192,   193,
     468,   469,   183,   460,   461,     8,   467,     9,   113,   194,
      30,   323,   324,    31,   226,   195,   227,   470,   213,   214,
     186,    10,   542,   543,   544,   117,   187,   188,   228,   189,
     229,   253,   254,   256,   380,   -92,   231,   442,   232,   266,
     267,    11,   269,    56,   392,   393,   126,   395,   103,   147,
     277,   235,    65,   236,   184,   394,   130,   130,   404,   405,
     406,    30,   313,   314,    31,   104,   239,   384,   148,   386,
     388,   390,   391,   346,   230,   347,   131,   132,   133,   134,
     343,   149,   123,   -34,   135,   124,   136,   125,   176,   137,
     212,   410,    30,   313,   314,    31,    30,   313,   314,    31,
     150,   151,   326,   152,   328,   153,   330,   154,   332,   202,
     203,   204,   205,   206,   207,   340,   396,   397,   398,   399,
     400,   401,   414,   155,   409,   411,   416,   415,   417,   197,
     198,   199,   200,    30,   313,   314,    31,   244,   156,   157,
     158,   249,   159,   160,   161,   162,   163,   164,   165,   166,
     167,   168,   169,   170,   171,   172,   173,   174,   175,   209,
    -110,   211,   243,   379,   215,   381,   382,   383,   138,   385,
     233,   234,   341,   284,    58,   285,   286,   287,   288,   239,
     289,   565,   407,   290,   291,   292,   293,   294,   295,   296,
     297,   298,   299,   300,   139,   301,   302,   303,   304,   305,
     306,   307,   308,   309,  -102,   317,   318,   345,   524,   531,
     420,   349,   350,   351,   352,   353,   354,   355,   356,   357,
     358,   359,   360,   361,   362,   363,   600,   364,   365,   366,
     367,   368,   369,   370,   371,   538,   539,   570,   541,   372,
     546,   373,   506,   374,   375,   376,   540,   377,   378,   424,
     428,   447,   431,   449,   448,   451,   450,   582,   453,   452,
     455,   454,   456,   457,   458,   464,   507,   466,   510,   465,
     471,   472,   473,   474,   555,   556,   475,   566,   476,   477,
     478,   479,   480,   481,   482,   483,   484,   550,   485,   486,
     487,   552,   553,   554,   488,   489,   490,   491,   508,   560,
     561,   492,   494,   495,   496,   497,   498,   499,   500,   501,
     502,   503,   505,   509,   511,   512,   547,   513,   514,   515,
     516,   517,   518,   519,   520,   521,   522,   523,   526,   528,
     579,   529,   535,   530,   536,   537,   571,   569,   572,   329,
     573,   283,   574,   575,   576,   533,   577,   581,   583,   584,
     585,   586,   587,   588,   589,   493,   590,   591,   592,   594,
     595,   596,   593,   597,   602,   603,   325,   525,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   331,     0,     0,
       0,     0,     0,     0,   580,   339,     0,     0,     0,     0,
       0,     0,   344,     0,     0,     0,     0,   557,   558,   559,
       0,     0,   562,   598,     0,     0,     0,     0,     0,     0,
     599,     0,     0,   533,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   110,     0,
      66,  -156,  -156,  -156,    67,    68,    69,    70,    71,    72,
      73,   562,     0,  -156,    74,     0,     0,   110,    75,  -156,
       0,     0,     0,     0,     0,     0,     0,    76,  -154,    77,
      78,    79,    80,    81,  -154,  -154,    82,  -154,  -158,  -158,
    -158,  -158,     0,    83,    84,     0,     0,     0,    85,    86,
      87,     0,     0,     0,     0,    88,    89,     0,     0,     0,
       0,     0,     0,    90,     0,     0,     0,     0,     0,     0,
       0,    91,    92,    93,     0,     0,     0,     0,     0,    94,
    -160,  -160,  -160,  -160,  -160,  -160,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,    95,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,  -121
};

static const yytype_int16 yycheck[] =
{
       1,     2,     3,     4,     5,    44,   231,     8,     9,    10,
      55,    58,    68,   230,   224,     0,    63,   148,   149,   187,
      64,    68,   232,    54,    55,    56,    57,    58,    59,   151,
      61,   112,    58,   155,   217,   187,    58,    63,   213,   175,
     176,    63,   173,   174,   166,   167,   168,   213,   216,   186,
     172,   187,   189,    54,    55,   157,   158,   159,    97,   213,
     162,   215,   164,   165,   216,    65,    66,   169,   170,   186,
     187,   188,   189,   175,   186,   187,   188,   189,   156,   157,
     119,   116,   117,   122,    97,   213,    99,   215,   213,   128,
     103,   130,   317,   318,   175,   176,   140,   132,   213,   134,
     135,   186,   141,   213,   216,   118,   187,   120,   121,   122,
     123,   217,   218,   114,   115,   128,   129,    71,    72,    73,
     345,   346,   157,   144,   145,   156,   343,   158,   214,    83,
     186,   220,   221,   189,   213,    89,   215,   347,   114,   115,
      98,   172,   175,   176,   177,   192,   104,   105,   213,   107,
     215,   152,   153,   154,   285,   213,   213,   170,   215,   160,
     161,   192,   163,   213,   295,   296,   192,   298,   186,   215,
     171,   213,   213,   215,   209,   297,   220,   221,   300,   301,
     302,   186,   187,   188,   189,   213,   230,   289,   215,   291,
     292,   293,   294,   213,   213,   215,    54,    55,    56,    57,
     239,   215,   214,   216,    62,   214,    64,   214,   214,    67,
     214,   216,   186,   187,   188,   189,   186,   187,   188,   189,
     215,   215,   223,   215,   225,   215,   227,   215,   229,   150,
     151,   152,   153,   154,   155,   236,    90,    91,    92,    93,
      94,    95,   216,   215,   304,   305,   216,   307,   308,   108,
     109,   110,   111,   186,   187,   188,   189,   187,   215,   215,
     215,   187,   215,   215,   215,   215,   215,   215,   215,   215,
     215,   215,   215,   215,   215,   215,   215,   215,   215,   215,
     215,   215,   214,   284,   215,   286,   287,   288,   146,   290,
     213,   215,   130,   215,    45,   215,   215,   215,   215,   343,
     215,   526,   303,   215,   215,   215,   215,   215,   215,   215,
     215,   215,   215,   215,   172,   215,   215,   215,   215,   215,
     215,   215,   215,   215,   214,   213,   213,   213,   444,   463,
     186,   216,   216,   216,   216,   216,   216,   216,   216,   216,
     216,   216,   216,   216,   216,   216,   571,   216,   216,   216,
     216,   216,   216,   216,   216,   486,   487,   534,   489,   216,
     491,   216,   181,   216,   216,   216,   488,   216,   216,   214,
     216,   214,   216,   214,   216,   214,   216,   551,   214,   216,
     214,   216,   214,   216,   214,   214,   423,   215,   427,   216,
     216,   216,   216,   216,   516,   517,   216,   528,   216,   216,
     216,   216,   216,   216,   216,   216,   216,   509,   216,   215,
     215,   513,   514,   515,   215,   215,   215,   215,   215,   521,
     522,   216,   216,   216,   216,   216,   216,   216,   216,   216,
     216,   216,   216,   215,   214,   214,   191,   215,   215,   215,
     215,   215,   215,   215,   215,   215,   215,   215,   213,   215,
     191,   215,   214,   216,   214,   216,   213,   216,   216,   226,
     216,   177,   216,   216,   216,   466,   216,   216,   216,   216,
     216,   216,   216,   216,   216,   403,   216,   216,   216,   216,
     214,   216,   562,   216,   216,   214,   222,   446,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   228,    -1,    -1,
      -1,    -1,    -1,    -1,   549,   235,    -1,    -1,    -1,    -1,
      -1,    -1,   240,    -1,    -1,    -1,    -1,   518,   519,   520,
      -1,    -1,   523,   568,    -1,    -1,    -1,    -1,    -1,    -1,
     569,    -1,    -1,   534,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   549,    -1,
      70,    71,    72,    73,    74,    75,    76,    77,    78,    79,
      80,   562,    -1,    83,    84,    -1,    -1,   568,    88,    89,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    97,    98,    99,
     100,   101,   102,   103,   104,   105,   106,   107,   108,   109,
     110,   111,    -1,   113,   114,    -1,    -1,    -1,   118,   119,
     120,    -1,    -1,    -1,    -1,   125,   126,    -1,    -1,    -1,
      -1,    -1,    -1,   133,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   141,   142,   143,    -1,    -1,    -1,    -1,    -1,   149,
     150,   151,   152,   153,   154,   155,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   192,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   214
};

/* YYSTOS[STATE-NUM] -- The symbol kind of the accessing symbol of
   state STATE-NUM.  */
static const yytype_int16 yystos[] =
{
       0,    54,    55,    56,    57,    58,    59,    61,   156,   158,
     172,   192,   220,   221,   222,   223,   224,   225,   226,   227,
     228,   229,   230,   264,   265,   266,   267,   270,   272,   283,
     186,   189,   299,   299,   299,   299,   299,   309,   333,   327,
     299,   299,   299,     0,   217,   313,   213,   213,   213,   213,
     325,   213,   186,   268,   271,   273,   213,   313,   221,   231,
     321,   240,   243,   245,   319,   213,    70,    74,    75,    76,
      77,    78,    79,    80,    84,    88,    97,    99,   100,   101,
     102,   103,   106,   113,   114,   118,   119,   120,   125,   126,
     133,   141,   142,   143,   149,   192,   288,   289,   290,   291,
     292,   293,   294,   186,   213,   186,   187,   188,   279,   280,
     299,   279,   244,   214,    58,    63,    68,   192,   232,   233,
     234,   235,   258,   214,   214,   214,   192,   246,   247,   248,
     258,    54,    55,    56,    57,    62,    64,    67,   146,   172,
     249,   250,   251,   255,   259,   260,   261,   215,   215,   215,
     215,   215,   215,   215,   215,   215,   215,   215,   215,   215,
     215,   215,   215,   215,   215,   215,   215,   215,   215,   215,
     215,   215,   215,   215,   215,   215,   214,   313,   116,   117,
     132,   134,   135,   157,   209,   318,    98,   104,   105,   107,
     316,    71,    72,    73,    83,    89,   295,   108,   109,   110,
     111,   298,   150,   151,   152,   153,   154,   155,   317,   215,
     269,   215,   214,   309,   309,   215,   322,   313,   313,   320,
     313,   313,   213,   215,   213,   215,   213,   215,   213,   215,
     213,   213,   215,   213,   215,   213,   215,   256,   257,   258,
     313,    65,    66,   214,   187,   304,   305,   305,   305,   187,
     306,   307,   307,   299,   299,    68,   299,   307,   175,   176,
     187,   300,   301,   301,   301,   301,   299,   299,   301,   299,
     301,   301,   307,   307,   307,   301,   301,   299,   307,   305,
     305,   301,   334,   288,   215,   215,   215,   215,   215,   215,
     215,   215,   215,   215,   215,   215,   215,   215,   215,   215,
     215,   215,   215,   215,   215,   215,   215,   215,   215,   215,
     284,   274,   275,   187,   188,   299,   308,   213,   213,   236,
     237,   232,   232,   246,   246,   231,   299,   240,   299,   243,
     299,   245,   299,   257,   261,   240,   241,   323,   252,   244,
     299,   130,   262,   313,   249,   213,   213,   215,   326,   216,
     216,   216,   216,   216,   216,   216,   216,   216,   216,   216,
     216,   216,   216,   216,   216,   216,   216,   216,   216,   216,
     216,   216,   216,   216,   216,   216,   216,   216,   216,   299,
     305,   299,   299,   299,   301,   299,   301,   112,   301,   303,
     301,   301,   305,   305,   307,   305,    90,    91,    92,    93,
      94,    95,   296,   297,   307,   307,   307,   299,   216,   308,
     216,   308,   187,   216,   216,   308,   216,   308,   187,   216,
     186,   285,   286,   287,   214,   156,   157,   277,   216,   261,
     261,   216,    97,    99,   103,   118,   120,   121,   122,   123,
     128,   129,   170,   238,   239,   314,   315,   214,   216,   214,
     216,   214,   216,   214,   216,   214,   214,   216,   214,   242,
     144,   145,   253,   254,   214,   216,   215,   257,   261,   261,
     240,   216,   216,   216,   216,   216,   216,   216,   216,   216,
     216,   216,   216,   216,   216,   216,   215,   215,   215,   215,
     215,   215,   216,   296,   216,   216,   216,   216,   216,   216,
     216,   216,   216,   216,   331,   216,   181,   286,   215,   215,
     313,   214,   214,   215,   215,   215,   215,   215,   215,   215,
     215,   215,   215,   215,   238,   316,   213,   324,   215,   215,
     216,   253,   263,   299,   310,   214,   214,   216,   305,   305,
     307,   305,   175,   176,   177,   302,   305,   191,   329,   278,
     301,   276,   301,   301,   301,   307,   307,   299,   299,   299,
     301,   301,   299,   311,   312,   261,   305,   281,   282,   216,
     263,   213,   216,   216,   216,   216,   216,   216,   332,   191,
     279,   216,   274,   216,   216,   216,   216,   216,   216,   216,
     216,   216,   216,   312,   216,   214,   216,   216,   279,   313,
     261,   330,   216,   214,   328
};

/* YYR1[RULE-NUM] -- Symbol kind of the left-hand side of rule RULE-NUM.  */
static const yytype_int16 yyr1[] =
{
       0,   219,   220,   221,   221,   222,   222,   222,   222,   222,
     223,   223,   223,   223,   223,   223,   224,   225,   226,   227,
     228,   229,   230,   231,   232,   232,   232,   233,   233,   234,
     235,   237,   236,   238,   238,   239,   239,   240,   242,   241,
     243,   244,   245,   246,   246,   246,   247,   248,   249,   249,
     250,   250,   250,   250,   250,   250,   250,   250,   250,   250,
     250,   250,   250,   250,   252,   251,   253,   253,   254,   254,
     255,   256,   257,   257,   258,   258,   259,   259,   260,   260,
     260,   260,   261,   262,   262,   263,   263,   264,   265,   265,
     266,   266,   268,   269,   267,   271,   270,   273,   272,   275,
     276,   274,   274,   278,   277,   277,   279,   279,   279,   279,
     280,   282,   281,   284,   283,   285,   285,   286,   286,   287,
     288,   288,   289,   289,   289,   289,   289,   289,   289,   289,
     289,   289,   289,   289,   289,   289,   289,   289,   289,   289,
     289,   289,   289,   289,   289,   289,   289,   289,   289,   289,
     289,   289,   290,   289,   291,   289,   292,   289,   293,   289,
     294,   289,   289,   295,   295,   295,   295,   295,   296,   296,
     297,   297,   297,   297,   297,   297,   298,   298,   298,   298,
     299,   299,   300,   300,   301,   301,   302,   302,   302,   303,
     303,   304,   305,   306,   307,   308,   308,   308,   309,   309,
     310,   311,   312,   312,   313,   313,   314,   314,   314,   314,
     314,   314,   314,   314,   314,   314,   315,   314,   316,   316,
     316,   316,   317,   317,   317,   317,   317,   317,   317,   317,
     317,   317,   317,   317,   318,   318,   318,   318,   318,   318,
     318,   319,   320,   321,   322,   323,   324,   325,   326,   327,
     328,   329,   330,   331,   332,   333,   334
};

/* YYR2[RULE-NUM] -- Number of symbols on the right-hand side of rule RULE-NUM.  */
static const yytype_int8 yyr2[] =
{
       0,     2,     1,     3,     0,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     5,     5,     5,     5,
       5,     7,     1,     3,     3,     3,     0,     1,     1,     1,
       4,     0,     2,     2,     0,     4,     1,     0,     0,     3,
       0,     0,     3,     3,     3,     0,     1,     1,     3,     0,
       4,     4,     4,     4,     4,     4,     4,     4,     4,     4,
       4,     1,     1,     1,     0,     5,     2,     0,     4,     4,
       4,     1,     3,     0,     5,     5,     1,     5,     7,     4,
       8,     5,     3,     5,     0,     2,     0,     6,     1,     1,
       1,     1,     0,     0,     7,     0,     4,     0,     4,     0,
       0,     5,     0,     0,     5,     4,     1,     4,     1,     1,
       1,     0,     2,     0,    12,     1,     2,     2,     0,     4,
       3,     0,     4,     4,     4,     4,     4,     4,     4,     4,
       4,     4,     4,     4,     4,     4,     4,     4,     4,     4,
       4,     4,     4,     4,     4,     4,     4,     4,     4,     4,
       4,     4,     0,     2,     0,     2,     0,     2,     0,     2,
       0,     2,     1,     4,     4,     4,     4,     4,     2,     0,
       4,     4,     4,     4,     4,     4,     4,     4,     4,     4,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     0,
       1,     1,     2,     0,     1,     2,     4,     4,     4,     4,
       4,     4,     4,     4,     4,     4,     0,     2,     4,     4,
       4,     4,     4,     3,     4,     3,     4,     3,     4,     3,
       4,     3,     4,     3,     4,     4,     4,     4,     4,     4,
       4,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0
};


enum { YYENOMEM = -2 };

#define yyerrok         (yyerrstatus = 0)
#define yyclearin       (yychar = MAIN_EMPTY)

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab
#define YYNOMEM         goto yyexhaustedlab


#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)                                    \
  do                                                              \
    if (yychar == MAIN_EMPTY)                                        \
      {                                                           \
        yychar = (Token);                                         \
        yylval = (Value);                                         \
        YYPOPSTACK (yylen);                                       \
        yystate = *yyssp;                                         \
        goto yybackup;                                            \
      }                                                           \
    else                                                          \
      {                                                           \
        yyerror (&yylloc, lexer, dummy, arg, YY_("syntax error: cannot back up")); \
        YYERROR;                                                  \
      }                                                           \
  while (0)

/* Backward compatibility with an undocumented macro.
   Use MAIN_error or MAIN_UNDEF. */
#define YYERRCODE MAIN_UNDEF

/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)                                \
    do                                                                  \
      if (N)                                                            \
        {                                                               \
          (Current).first_line   = YYRHSLOC (Rhs, 1).first_line;        \
          (Current).first_column = YYRHSLOC (Rhs, 1).first_column;      \
          (Current).last_line    = YYRHSLOC (Rhs, N).last_line;         \
          (Current).last_column  = YYRHSLOC (Rhs, N).last_column;       \
        }                                                               \
      else                                                              \
        {                                                               \
          (Current).first_line   = (Current).last_line   =              \
            YYRHSLOC (Rhs, 0).last_line;                                \
          (Current).first_column = (Current).last_column =              \
            YYRHSLOC (Rhs, 0).last_column;                              \
        }                                                               \
    while (0)
#endif

#define YYRHSLOC(Rhs, K) ((Rhs)[K])


/* Enable debugging if requested.  */
#if MAIN_DEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)                        \
do {                                            \
  if (yydebug)                                  \
    YYFPRINTF Args;                             \
} while (0)


/* YYLOCATION_PRINT -- Print the location on the stream.
   This macro was not mandated originally: define only if we know
   we won't break user code: when these are the locations we know.  */

# ifndef YYLOCATION_PRINT

#  if defined YY_LOCATION_PRINT

   /* Temporary convenience wrapper in case some people defined the
      undocumented and private YY_LOCATION_PRINT macros.  */
#   define YYLOCATION_PRINT(File, Loc)  YY_LOCATION_PRINT(File, *(Loc))

#  elif defined MAIN_LTYPE_IS_TRIVIAL && MAIN_LTYPE_IS_TRIVIAL

/* Print *YYLOCP on YYO.  Private, do not rely on its existence. */

YY_ATTRIBUTE_UNUSED
static int
yy_location_print_ (FILE *yyo, YYLTYPE const * const yylocp)
{
  int res = 0;
  int end_col = 0 != yylocp->last_column ? yylocp->last_column - 1 : 0;
  if (0 <= yylocp->first_line)
    {
      res += YYFPRINTF (yyo, "%d", yylocp->first_line);
      if (0 <= yylocp->first_column)
        res += YYFPRINTF (yyo, ".%d", yylocp->first_column);
    }
  if (0 <= yylocp->last_line)
    {
      if (yylocp->first_line < yylocp->last_line)
        {
          res += YYFPRINTF (yyo, "-%d", yylocp->last_line);
          if (0 <= end_col)
            res += YYFPRINTF (yyo, ".%d", end_col);
        }
      else if (0 <= end_col && yylocp->first_column < end_col)
        res += YYFPRINTF (yyo, "-%d", end_col);
    }
  return res;
}

#   define YYLOCATION_PRINT  yy_location_print_

    /* Temporary convenience wrapper in case some people defined the
       undocumented and private YY_LOCATION_PRINT macros.  */
#   define YY_LOCATION_PRINT(File, Loc)  YYLOCATION_PRINT(File, &(Loc))

#  else

#   define YYLOCATION_PRINT(File, Loc) ((void) 0)
    /* Temporary convenience wrapper in case some people defined the
       undocumented and private YY_LOCATION_PRINT macros.  */
#   define YY_LOCATION_PRINT  YYLOCATION_PRINT

#  endif
# endif /* !defined YYLOCATION_PRINT */


# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)                    \
do {                                                                      \
  if (yydebug)                                                            \
    {                                                                     \
      YYFPRINTF (stderr, "%s ", Title);                                   \
      yy_symbol_print (stderr,                                            \
                  Kind, Value, Location, lexer, dummy, arg); \
      YYFPRINTF (stderr, "\n");                                           \
    }                                                                     \
} while (0)


/*-----------------------------------.
| Print this symbol's value on YYO.  |
`-----------------------------------*/

static void
yy_symbol_value_print (FILE *yyo,
                       yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep, YYLTYPE const * const yylocationp, CfgLexer *lexer, gpointer *dummy, gpointer arg)
{
  FILE *yyoutput = yyo;
  YY_USE (yyoutput);
  YY_USE (yylocationp);
  YY_USE (lexer);
  YY_USE (dummy);
  YY_USE (arg);
  if (!yyvaluep)
    return;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YY_USE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}


/*---------------------------.
| Print this symbol on YYO.  |
`---------------------------*/

static void
yy_symbol_print (FILE *yyo,
                 yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep, YYLTYPE const * const yylocationp, CfgLexer *lexer, gpointer *dummy, gpointer arg)
{
  YYFPRINTF (yyo, "%s %s (",
             yykind < YYNTOKENS ? "token" : "nterm", yysymbol_name (yykind));

  YYLOCATION_PRINT (yyo, yylocationp);
  YYFPRINTF (yyo, ": ");
  yy_symbol_value_print (yyo, yykind, yyvaluep, yylocationp, lexer, dummy, arg);
  YYFPRINTF (yyo, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

static void
yy_stack_print (yy_state_t *yybottom, yy_state_t *yytop)
{
  YYFPRINTF (stderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (stderr, " %d", yybot);
    }
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)                            \
do {                                                            \
  if (yydebug)                                                  \
    yy_stack_print ((Bottom), (Top));                           \
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

static void
yy_reduce_print (yy_state_t *yyssp, YYSTYPE *yyvsp, YYLTYPE *yylsp,
                 int yyrule, CfgLexer *lexer, gpointer *dummy, gpointer arg)
{
  int yylno = yyrline[yyrule];
  int yynrhs = yyr2[yyrule];
  int yyi;
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %d):\n",
             yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr,
                       YY_ACCESSING_SYMBOL (+yyssp[yyi + 1 - yynrhs]),
                       &yyvsp[(yyi + 1) - (yynrhs)],
                       &(yylsp[(yyi + 1) - (yynrhs)]), lexer, dummy, arg);
      YYFPRINTF (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)          \
do {                                    \
  if (yydebug)                          \
    yy_reduce_print (yyssp, yyvsp, yylsp, Rule, lexer, dummy, arg); \
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !MAIN_DEBUG */
# define YYDPRINTF(Args) ((void) 0)
# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !MAIN_DEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif


/* Context of a parse error.  */
typedef struct
{
  yy_state_t *yyssp;
  yysymbol_kind_t yytoken;
  YYLTYPE *yylloc;
} yypcontext_t;

/* Put in YYARG at most YYARGN of the expected tokens given the
   current YYCTX, and return the number of tokens stored in YYARG.  If
   YYARG is null, return the number of expected tokens (guaranteed to
   be less than YYNTOKENS).  Return YYENOMEM on memory exhaustion.
   Return 0 if there are more than YYARGN expected tokens, yet fill
   YYARG up to YYARGN. */
static int
yypcontext_expected_tokens (const yypcontext_t *yyctx,
                            yysymbol_kind_t yyarg[], int yyargn)
{
  /* Actual size of YYARG. */
  int yycount = 0;
  int yyn = yypact[+*yyctx->yyssp];
  if (!yypact_value_is_default (yyn))
    {
      /* Start YYX at -YYN if negative to avoid negative indexes in
         YYCHECK.  In other words, skip the first -YYN actions for
         this state because they are default actions.  */
      int yyxbegin = yyn < 0 ? -yyn : 0;
      /* Stay within bounds of both yycheck and yytname.  */
      int yychecklim = YYLAST - yyn + 1;
      int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
      int yyx;
      for (yyx = yyxbegin; yyx < yyxend; ++yyx)
        if (yycheck[yyx + yyn] == yyx && yyx != YYSYMBOL_YYerror
            && !yytable_value_is_error (yytable[yyx + yyn]))
          {
            if (!yyarg)
              ++yycount;
            else if (yycount == yyargn)
              return 0;
            else
              yyarg[yycount++] = YY_CAST (yysymbol_kind_t, yyx);
          }
    }
  if (yyarg && yycount == 0 && 0 < yyargn)
    yyarg[0] = YYSYMBOL_YYEMPTY;
  return yycount;
}




#ifndef yystrlen
# if defined __GLIBC__ && defined _STRING_H
#  define yystrlen(S) (YY_CAST (YYPTRDIFF_T, strlen (S)))
# else
/* Return the length of YYSTR.  */
static YYPTRDIFF_T
yystrlen (const char *yystr)
{
  YYPTRDIFF_T yylen;
  for (yylen = 0; yystr[yylen]; yylen++)
    continue;
  return yylen;
}
# endif
#endif

#ifndef yystpcpy
# if defined __GLIBC__ && defined _STRING_H && defined _GNU_SOURCE
#  define yystpcpy stpcpy
# else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
static char *
yystpcpy (char *yydest, const char *yysrc)
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
# endif
#endif

#ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYPTRDIFF_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      YYPTRDIFF_T yyn = 0;
      char const *yyp = yystr;
      for (;;)
        switch (*++yyp)
          {
          case '\'':
          case ',':
            goto do_not_strip_quotes;

          case '\\':
            if (*++yyp != '\\')
              goto do_not_strip_quotes;
            else
              goto append;

          append:
          default:
            if (yyres)
              yyres[yyn] = *yyp;
            yyn++;
            break;

          case '"':
            if (yyres)
              yyres[yyn] = '\0';
            return yyn;
          }
    do_not_strip_quotes: ;
    }

  if (yyres)
    return yystpcpy (yyres, yystr) - yyres;
  else
    return yystrlen (yystr);
}
#endif


static int
yy_syntax_error_arguments (const yypcontext_t *yyctx,
                           yysymbol_kind_t yyarg[], int yyargn)
{
  /* Actual size of YYARG. */
  int yycount = 0;
  /* There are many possibilities here to consider:
     - If this state is a consistent state with a default action, then
       the only way this function was invoked is if the default action
       is an error action.  In that case, don't check for expected
       tokens because there are none.
     - The only way there can be no lookahead present (in yychar) is if
       this state is a consistent state with a default action.  Thus,
       detecting the absence of a lookahead is sufficient to determine
       that there is no unexpected or expected token to report.  In that
       case, just report a simple "syntax error".
     - Don't assume there isn't a lookahead just because this state is a
       consistent state with a default action.  There might have been a
       previous inconsistent state, consistent state with a non-default
       action, or user semantic action that manipulated yychar.
     - Of course, the expected token list depends on states to have
       correct lookahead information, and it depends on the parser not
       to perform extra reductions after fetching a lookahead from the
       scanner and before detecting a syntax error.  Thus, state merging
       (from LALR or IELR) and default reductions corrupt the expected
       token list.  However, the list is correct for canonical LR with
       one exception: it will still contain any token that will not be
       accepted due to an error action in a later state.
  */
  if (yyctx->yytoken != YYSYMBOL_YYEMPTY)
    {
      int yyn;
      if (yyarg)
        yyarg[yycount] = yyctx->yytoken;
      ++yycount;
      yyn = yypcontext_expected_tokens (yyctx,
                                        yyarg ? yyarg + 1 : yyarg, yyargn - 1);
      if (yyn == YYENOMEM)
        return YYENOMEM;
      else
        yycount += yyn;
    }
  return yycount;
}

/* Copy into *YYMSG, which is of size *YYMSG_ALLOC, an error message
   about the unexpected token YYTOKEN for the state stack whose top is
   YYSSP.

   Return 0 if *YYMSG was successfully written.  Return -1 if *YYMSG is
   not large enough to hold the message.  In that case, also set
   *YYMSG_ALLOC to the required number of bytes.  Return YYENOMEM if the
   required number of bytes is too large to store.  */
static int
yysyntax_error (YYPTRDIFF_T *yymsg_alloc, char **yymsg,
                const yypcontext_t *yyctx)
{
  enum { YYARGS_MAX = 5 };
  /* Internationalized format string. */
  const char *yyformat = YY_NULLPTR;
  /* Arguments of yyformat: reported tokens (one for the "unexpected",
     one per "expected"). */
  yysymbol_kind_t yyarg[YYARGS_MAX];
  /* Cumulated lengths of YYARG.  */
  YYPTRDIFF_T yysize = 0;

  /* Actual size of YYARG. */
  int yycount = yy_syntax_error_arguments (yyctx, yyarg, YYARGS_MAX);
  if (yycount == YYENOMEM)
    return YYENOMEM;

  switch (yycount)
    {
#define YYCASE_(N, S)                       \
      case N:                               \
        yyformat = S;                       \
        break
    default: /* Avoid compiler warnings. */
      YYCASE_(0, YY_("syntax error"));
      YYCASE_(1, YY_("syntax error, unexpected %s"));
      YYCASE_(2, YY_("syntax error, unexpected %s, expecting %s"));
      YYCASE_(3, YY_("syntax error, unexpected %s, expecting %s or %s"));
      YYCASE_(4, YY_("syntax error, unexpected %s, expecting %s or %s or %s"));
      YYCASE_(5, YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s"));
#undef YYCASE_
    }

  /* Compute error message size.  Don't count the "%s"s, but reserve
     room for the terminator.  */
  yysize = yystrlen (yyformat) - 2 * yycount + 1;
  {
    int yyi;
    for (yyi = 0; yyi < yycount; ++yyi)
      {
        YYPTRDIFF_T yysize1
          = yysize + yytnamerr (YY_NULLPTR, yytname[yyarg[yyi]]);
        if (yysize <= yysize1 && yysize1 <= YYSTACK_ALLOC_MAXIMUM)
          yysize = yysize1;
        else
          return YYENOMEM;
      }
  }

  if (*yymsg_alloc < yysize)
    {
      *yymsg_alloc = 2 * yysize;
      if (! (yysize <= *yymsg_alloc
             && *yymsg_alloc <= YYSTACK_ALLOC_MAXIMUM))
        *yymsg_alloc = YYSTACK_ALLOC_MAXIMUM;
      return -1;
    }

  /* Avoid sprintf, as that infringes on the user's name space.
     Don't have undefined behavior even if the translation
     produced a string with the wrong number of "%s"s.  */
  {
    char *yyp = *yymsg;
    int yyi = 0;
    while ((*yyp = *yyformat) != '\0')
      if (*yyp == '%' && yyformat[1] == 's' && yyi < yycount)
        {
          yyp += yytnamerr (yyp, yytname[yyarg[yyi++]]);
          yyformat += 2;
        }
      else
        {
          ++yyp;
          ++yyformat;
        }
  }
  return 0;
}


/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

static void
yydestruct (const char *yymsg,
            yysymbol_kind_t yykind, YYSTYPE *yyvaluep, YYLTYPE *yylocationp, CfgLexer *lexer, gpointer *dummy, gpointer arg)
{
  YY_USE (yyvaluep);
  YY_USE (yylocationp);
  YY_USE (lexer);
  YY_USE (dummy);
  YY_USE (arg);
  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yykind, yyvaluep, yylocationp);

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  switch (yykind)
    {
    case YYSYMBOL_LL_IDENTIFIER: /* LL_IDENTIFIER  */
#line 363 "/source/lib/cfg-grammar.y"
            { free(((*yyvaluep).cptr)); }
#line 3566 "lib/cfg-grammar.c"
        break;

    case YYSYMBOL_LL_STRING: /* LL_STRING  */
#line 363 "/source/lib/cfg-grammar.y"
            { free(((*yyvaluep).cptr)); }
#line 3572 "lib/cfg-grammar.c"
        break;

    case YYSYMBOL_LL_BLOCK: /* LL_BLOCK  */
#line 363 "/source/lib/cfg-grammar.y"
            { free(((*yyvaluep).cptr)); }
#line 3578 "lib/cfg-grammar.c"
        break;

    case YYSYMBOL_LL_PLUGIN: /* LL_PLUGIN  */
#line 363 "/source/lib/cfg-grammar.y"
            { free(((*yyvaluep).cptr)); }
#line 3584 "lib/cfg-grammar.c"
        break;

    case YYSYMBOL_LL_TEMPLATE_REF: /* LL_TEMPLATE_REF  */
#line 363 "/source/lib/cfg-grammar.y"
            { free(((*yyvaluep).cptr)); }
#line 3590 "lib/cfg-grammar.c"
        break;

    case YYSYMBOL_LL_MESSAGE_REF: /* LL_MESSAGE_REF  */
#line 363 "/source/lib/cfg-grammar.y"
            { free(((*yyvaluep).cptr)); }
#line 3596 "lib/cfg-grammar.c"
        break;

    case YYSYMBOL_string: /* string  */
#line 363 "/source/lib/cfg-grammar.y"
            { free(((*yyvaluep).cptr)); }
#line 3602 "lib/cfg-grammar.c"
        break;

    case YYSYMBOL_string_or_number: /* string_or_number  */
#line 363 "/source/lib/cfg-grammar.y"
            { free(((*yyvaluep).cptr)); }
#line 3608 "lib/cfg-grammar.c"
        break;

    case YYSYMBOL_optional_string: /* optional_string  */
#line 363 "/source/lib/cfg-grammar.y"
            { free(((*yyvaluep).cptr)); }
#line 3614 "lib/cfg-grammar.c"
        break;

    case YYSYMBOL_normalized_flag: /* normalized_flag  */
#line 363 "/source/lib/cfg-grammar.y"
            { free(((*yyvaluep).cptr)); }
#line 3620 "lib/cfg-grammar.c"
        break;

      default:
        break;
    }
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}






/*----------.
| yyparse.  |
`----------*/

int
yyparse (CfgLexer *lexer, gpointer *dummy, gpointer arg)
{
/* Lookahead token kind.  */
int yychar;


/* The semantic value of the lookahead symbol.  */
/* Default value used for initialization, for pacifying older GCCs
   or non-GCC compilers.  */
YY_INITIAL_VALUE (static YYSTYPE yyval_default;)
YYSTYPE yylval YY_INITIAL_VALUE (= yyval_default);

/* Location data for the lookahead symbol.  */
static YYLTYPE yyloc_default
# if defined MAIN_LTYPE_IS_TRIVIAL && MAIN_LTYPE_IS_TRIVIAL
  = { 1, 1, 1, 1 }
# endif
;
YYLTYPE yylloc = yyloc_default;

    /* Number of syntax errors so far.  */
    int yynerrs = 0;

    yy_state_fast_t yystate = 0;
    /* Number of tokens to shift before error messages enabled.  */
    int yyerrstatus = 0;

    /* Refer to the stacks through separate pointers, to allow yyoverflow
       to reallocate them elsewhere.  */

    /* Their size.  */
    YYPTRDIFF_T yystacksize = YYINITDEPTH;

    /* The state stack: array, bottom, top.  */
    yy_state_t yyssa[YYINITDEPTH];
    yy_state_t *yyss = yyssa;
    yy_state_t *yyssp = yyss;

    /* The semantic value stack: array, bottom, top.  */
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs = yyvsa;
    YYSTYPE *yyvsp = yyvs;

    /* The location stack: array, bottom, top.  */
    YYLTYPE yylsa[YYINITDEPTH];
    YYLTYPE *yyls = yylsa;
    YYLTYPE *yylsp = yyls;

  int yyn;
  /* The return value of yyparse.  */
  int yyresult;
  /* Lookahead symbol kind.  */
  yysymbol_kind_t yytoken = YYSYMBOL_YYEMPTY;
  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;
  YYLTYPE yyloc;

  /* The locations where the error started and ended.  */
  YYLTYPE yyerror_range[3];

  /* Buffer for error messages, and its allocated size.  */
  char yymsgbuf[128];
  char *yymsg = yymsgbuf;
  YYPTRDIFF_T yymsg_alloc = sizeof yymsgbuf;

#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N), yylsp -= (N))

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yychar = MAIN_EMPTY; /* Cause a token to be read.  */

  yylsp[0] = yylloc;
  goto yysetstate;


/*------------------------------------------------------------.
| yynewstate -- push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;


/*--------------------------------------------------------------------.
| yysetstate -- set current state (the top of the stack) to yystate.  |
`--------------------------------------------------------------------*/
yysetstate:
  YYDPRINTF ((stderr, "Entering state %d\n", yystate));
  YY_ASSERT (0 <= yystate && yystate < YYNSTATES);
  YY_IGNORE_USELESS_CAST_BEGIN
  *yyssp = YY_CAST (yy_state_t, yystate);
  YY_IGNORE_USELESS_CAST_END
  YY_STACK_PRINT (yyss, yyssp);

  if (yyss + yystacksize - 1 <= yyssp)
#if !defined yyoverflow && !defined YYSTACK_RELOCATE
    YYNOMEM;
#else
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYPTRDIFF_T yysize = yyssp - yyss + 1;

# if defined yyoverflow
      {
        /* Give user a chance to reallocate the stack.  Use copies of
           these so that the &'s don't force the real ones into
           memory.  */
        yy_state_t *yyss1 = yyss;
        YYSTYPE *yyvs1 = yyvs;
        YYLTYPE *yyls1 = yyls;

        /* Each stack pointer address is followed by the size of the
           data in use in that stack, in bytes.  This used to be a
           conditional around just the two extra args, but that might
           be undefined if yyoverflow is a macro.  */
        yyoverflow (YY_("memory exhausted"),
                    &yyss1, yysize * YYSIZEOF (*yyssp),
                    &yyvs1, yysize * YYSIZEOF (*yyvsp),
                    &yyls1, yysize * YYSIZEOF (*yylsp),
                    &yystacksize);
        yyss = yyss1;
        yyvs = yyvs1;
        yyls = yyls1;
      }
# else /* defined YYSTACK_RELOCATE */
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
        YYNOMEM;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
        yystacksize = YYMAXDEPTH;

      {
        yy_state_t *yyss1 = yyss;
        union yyalloc *yyptr =
          YY_CAST (union yyalloc *,
                   YYSTACK_ALLOC (YY_CAST (YYSIZE_T, YYSTACK_BYTES (yystacksize))));
        if (! yyptr)
          YYNOMEM;
        YYSTACK_RELOCATE (yyss_alloc, yyss);
        YYSTACK_RELOCATE (yyvs_alloc, yyvs);
        YYSTACK_RELOCATE (yyls_alloc, yyls);
#  undef YYSTACK_RELOCATE
        if (yyss1 != yyssa)
          YYSTACK_FREE (yyss1);
      }
# endif

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;
      yylsp = yyls + yysize - 1;

      YY_IGNORE_USELESS_CAST_BEGIN
      YYDPRINTF ((stderr, "Stack size increased to %ld\n",
                  YY_CAST (long, yystacksize)));
      YY_IGNORE_USELESS_CAST_END

      if (yyss + yystacksize - 1 <= yyssp)
        YYABORT;
    }
#endif /* !defined yyoverflow && !defined YYSTACK_RELOCATE */


  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;


/*-----------.
| yybackup.  |
`-----------*/
yybackup:
  /* Do appropriate processing given the current state.  Read a
     lookahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to lookahead token.  */
  yyn = yypact[yystate];
  if (yypact_value_is_default (yyn))
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either empty, or end-of-input, or a valid lookahead.  */
  if (yychar == MAIN_EMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token\n"));
      yychar = yylex (&yylval, &yylloc, lexer);
    }

  if (yychar <= MAIN_EOF)
    {
      yychar = MAIN_EOF;
      yytoken = YYSYMBOL_YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else if (yychar == MAIN_error)
    {
      /* The scanner already issued an error message, process directly
         to error recovery.  But do not keep the error token as
         lookahead, it is too special and may lead us to an endless
         loop in error recovery. */
      yychar = MAIN_UNDEF;
      yytoken = YYSYMBOL_YYerror;
      yyerror_range[1] = yylloc;
      goto yyerrlab1;
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yytable_value_is_error (yyn))
        goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the lookahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);
  yystate = yyn;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END
  *++yylsp = yylloc;

  /* Discard the shifted token.  */
  yychar = MAIN_EMPTY;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     '$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];

  /* Default location. */
  YYLLOC_DEFAULT (yyloc, (yylsp - yylen), yylen);
  yyerror_range[1] = yyloc;
  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
  case 5: /* stmt: expr_stmt  */
#line 493 "/source/lib/cfg-grammar.y"
          {
            CHECK_ERROR(cfg_tree_add_object(&configuration->tree, (yyvsp[0].ptr)) || cfg_allow_config_dups(configuration), (yylsp[0]), "duplicate %s definition", log_expr_node_get_content_name(((LogExprNode *) (yyvsp[0].ptr))->content));
          }
#line 3928 "lib/cfg-grammar.c"
    break;

  case 16: /* source_stmt: KW_SOURCE string '{' source_content '}'  */
#line 513 "/source/lib/cfg-grammar.y"
          {
            (yyval.ptr) = log_expr_node_new_source((yyvsp[-3].cptr), (yyvsp[-1].ptr), &(yylsp[-4]));
            free((yyvsp[-3].cptr));
          }
#line 3937 "lib/cfg-grammar.c"
    break;

  case 17: /* dest_stmt: KW_DESTINATION string '{' dest_content '}'  */
#line 520 "/source/lib/cfg-grammar.y"
          {
            (yyval.ptr) = log_expr_node_new_destination((yyvsp[-3].cptr), (yyvsp[-1].ptr), &(yylsp[-4]));
            free((yyvsp[-3].cptr));
          }
#line 3946 "lib/cfg-grammar.c"
    break;

  case 18: /* filter_stmt: KW_FILTER string '{' filter_content '}'  */
#line 529 "/source/lib/cfg-grammar.y"
          {
            /* NOTE: the filter() subexpression (e.g. the one that invokes
             * one filter expression from another) depends on the layout
             * parsed into the cfg-tree when looking up the referenced
             * filter expression.  So when changing how a filter statement
             * is transformed into the cfg-tree, make sure you check
             * filter-call.c, especially filter_call_init() function as
             * well.
             */

            (yyval.ptr) = log_expr_node_new_filter((yyvsp[-3].cptr), (yyvsp[-1].ptr), &(yylsp[-4]));
            free((yyvsp[-3].cptr));
          }
#line 3964 "lib/cfg-grammar.c"
    break;

  case 19: /* parser_stmt: KW_PARSER string '{' parser_content '}'  */
#line 546 "/source/lib/cfg-grammar.y"
          {
            (yyval.ptr) = log_expr_node_new_parser((yyvsp[-3].cptr), (yyvsp[-1].ptr), &(yylsp[-4]));
            free((yyvsp[-3].cptr));
          }
#line 3973 "lib/cfg-grammar.c"
    break;

  case 20: /* rewrite_stmt: KW_REWRITE string '{' rewrite_content '}'  */
#line 554 "/source/lib/cfg-grammar.y"
          {
            (yyval.ptr) = log_expr_node_new_rewrite((yyvsp[-3].cptr), (yyvsp[-1].ptr), &(yylsp[-4]));
            free((yyvsp[-3].cptr));
          }
#line 3982 "lib/cfg-grammar.c"
    break;

  case 21: /* log_stmt: KW_LOG optional_string _log_context_push '{' log_content '}' _log_context_pop  */
#line 561 "/source/lib/cfg-grammar.y"
          {
            if ((yyvsp[-5].cptr))
              {
                log_expr_node_set_name((yyvsp[-2].ptr), (yyvsp[-5].cptr));
                free((yyvsp[-5].cptr));
              }
            (yyval.ptr) = (yyvsp[-2].ptr);
          }
#line 3995 "lib/cfg-grammar.c"
    break;

  case 22: /* plugin_stmt: LL_PLUGIN  */
#line 574 "/source/lib/cfg-grammar.y"
          {
            Plugin *p;
            gint context = LL_CONTEXT_ROOT;
            gpointer result;

            p = cfg_find_plugin(configuration, context, (yyvsp[0].cptr));
            CHECK_ERROR(p, (yylsp[0]), "%s plugin %s not found", cfg_lexer_lookup_context_name_by_type(context), (yyvsp[0].cptr));

            result = cfg_parse_plugin(configuration, p, &(yylsp[0]), NULL);
            free((yyvsp[0].cptr));
            if (!result)
              YYERROR;
            (yyval.ptr) = NULL;
          }
#line 4014 "lib/cfg-grammar.c"
    break;

  case 23: /* source_content: _source_context_push source_items _source_context_pop  */
#line 592 "/source/lib/cfg-grammar.y"
                                                                  { (yyval.ptr) = log_expr_node_new_source_junction((yyvsp[-1].ptr), &(yyloc)); }
#line 4020 "lib/cfg-grammar.c"
    break;

  case 24: /* source_items: source_item semicolons source_items  */
#line 596 "/source/lib/cfg-grammar.y"
                                                { (yyval.ptr) = log_expr_node_append_tail(log_expr_node_new_pipe((yyvsp[-2].ptr), &(yylsp[-2])), (yyvsp[0].ptr)); }
#line 4026 "lib/cfg-grammar.c"
    break;

  case 25: /* source_items: log_fork semicolons source_items  */
#line 597 "/source/lib/cfg-grammar.y"
                                                { (yyval.ptr) = log_expr_node_append_tail((yyvsp[-2].ptr),  (yyvsp[0].ptr)); }
#line 4032 "lib/cfg-grammar.c"
    break;

  case 26: /* source_items: %empty  */
#line 598 "/source/lib/cfg-grammar.y"
                                                { (yyval.ptr) = NULL; }
#line 4038 "lib/cfg-grammar.c"
    break;

  case 27: /* source_item: source_afinter  */
#line 602 "/source/lib/cfg-grammar.y"
                                                { (yyval.ptr) = (yyvsp[0].ptr); }
#line 4044 "lib/cfg-grammar.c"
    break;

  case 28: /* source_item: source_plugin  */
#line 603 "/source/lib/cfg-grammar.y"
                                                { (yyval.ptr) = (yyvsp[0].ptr); }
#line 4050 "lib/cfg-grammar.c"
    break;

  case 29: /* source_plugin: LL_PLUGIN  */
#line 608 "/source/lib/cfg-grammar.y"
          {
            Plugin *p;
            gint context = LL_CONTEXT_SOURCE;

            p = cfg_find_plugin(configuration, context, (yyvsp[0].cptr));
            CHECK_ERROR(p, (yylsp[0]), "%s plugin %s not found", cfg_lexer_lookup_context_name_by_type(context), (yyvsp[0].cptr));

            last_driver = (LogDriver *) cfg_parse_plugin(configuration, p, &(yylsp[0]), NULL);
            free((yyvsp[0].cptr));
            if (!last_driver)
              {
                YYERROR;
              }
            (yyval.ptr) = last_driver;
          }
#line 4070 "lib/cfg-grammar.c"
    break;

  case 30: /* source_afinter: KW_INTERNAL '(' source_afinter_params ')'  */
#line 626 "/source/lib/cfg-grammar.y"
                                                                        { (yyval.ptr) = (yyvsp[-1].ptr); }
#line 4076 "lib/cfg-grammar.c"
    break;

  case 31: /* $@1: %empty  */
#line 630 "/source/lib/cfg-grammar.y"
          {
            last_driver = afinter_sd_new(configuration);
            last_source_options = &((AFInterSourceDriver *) last_driver)->source_options.super;
          }
#line 4085 "lib/cfg-grammar.c"
    break;

  case 32: /* source_afinter_params: $@1 source_afinter_options  */
#line 634 "/source/lib/cfg-grammar.y"
                                 { (yyval.ptr) = last_driver; }
#line 4091 "lib/cfg-grammar.c"
    break;

  case 35: /* source_afinter_option: KW_LOG_FIFO_SIZE '(' positive_integer ')'  */
#line 643 "/source/lib/cfg-grammar.y"
                                                        { ((AFInterSourceOptions *) last_source_options)->queue_capacity = (yyvsp[-1].num); }
#line 4097 "lib/cfg-grammar.c"
    break;

  case 37: /* filter_content: %empty  */
#line 649 "/source/lib/cfg-grammar.y"
          {
            FilterExprNode *filter_expr = NULL;

	    CHECK_ERROR_WITHOUT_MESSAGE(cfg_parser_parse(&filter_expr_parser, lexer, (gpointer *) &filter_expr, NULL), (yyloc));

            (yyval.ptr) = log_expr_node_new_pipe(log_filter_pipe_new(filter_expr, configuration), &(yyloc));
	  }
#line 4109 "lib/cfg-grammar.c"
    break;

  case 38: /* @2: %empty  */
#line 659 "/source/lib/cfg-grammar.y"
                                     {
            GList *filterx_stmts = NULL;

	    CHECK_ERROR_WITHOUT_MESSAGE(cfg_parser_parse(&filterx_parser, lexer, (gpointer *) &filterx_stmts, NULL), (yyloc));

            (yyval.ptr) = log_expr_node_new_pipe(log_filterx_pipe_new(filterx_stmts, configuration), &(yyloc));
	  }
#line 4121 "lib/cfg-grammar.c"
    break;

  case 39: /* filterx_content: _filterx_context_push @2 _filterx_context_pop  */
#line 665 "/source/lib/cfg-grammar.y"
                                                        { (yyval.ptr) = (yyvsp[-1].ptr); }
#line 4127 "lib/cfg-grammar.c"
    break;

  case 40: /* parser_content: %empty  */
#line 670 "/source/lib/cfg-grammar.y"
          {
            LogExprNode *last_parser_expr = NULL;

            CHECK_ERROR_WITHOUT_MESSAGE(cfg_parser_parse(&parser_expr_parser, lexer, (gpointer *) &last_parser_expr, NULL), (yyloc));
            (yyval.ptr) = last_parser_expr;
          }
#line 4138 "lib/cfg-grammar.c"
    break;

  case 41: /* rewrite_content: %empty  */
#line 680 "/source/lib/cfg-grammar.y"
          {
            LogExprNode *last_rewrite_expr = NULL;

            CHECK_ERROR_WITHOUT_MESSAGE(cfg_parser_parse(&rewrite_expr_parser, lexer, (gpointer *) &last_rewrite_expr, NULL), (yyloc));
            (yyval.ptr) = last_rewrite_expr;
          }
#line 4149 "lib/cfg-grammar.c"
    break;

  case 42: /* dest_content: _destination_context_push dest_items _destination_context_pop  */
#line 689 "/source/lib/cfg-grammar.y"
                                                                                       { (yyval.ptr) = log_expr_node_new_destination_junction((yyvsp[-1].ptr), &(yyloc)); }
#line 4155 "lib/cfg-grammar.c"
    break;

  case 43: /* dest_items: dest_item semicolons dest_items  */
#line 695 "/source/lib/cfg-grammar.y"
                                                { (yyval.ptr) = log_expr_node_append_tail(log_expr_node_new_pipe((yyvsp[-2].ptr), &(yylsp[-2])), (yyvsp[0].ptr)); }
#line 4161 "lib/cfg-grammar.c"
    break;

  case 44: /* dest_items: log_fork semicolons dest_items  */
#line 696 "/source/lib/cfg-grammar.y"
                                                { (yyval.ptr) = log_expr_node_append_tail((yyvsp[-2].ptr),  (yyvsp[0].ptr)); }
#line 4167 "lib/cfg-grammar.c"
    break;

  case 45: /* dest_items: %empty  */
#line 697 "/source/lib/cfg-grammar.y"
                                                { (yyval.ptr) = NULL; }
#line 4173 "lib/cfg-grammar.c"
    break;

  case 46: /* dest_item: dest_plugin  */
#line 701 "/source/lib/cfg-grammar.y"
                                                { (yyval.ptr) = (yyvsp[0].ptr); }
#line 4179 "lib/cfg-grammar.c"
    break;

  case 47: /* dest_plugin: LL_PLUGIN  */
#line 706 "/source/lib/cfg-grammar.y"
          {
            Plugin *p;
            gint context = LL_CONTEXT_DESTINATION;

            p = cfg_find_plugin(configuration, context, (yyvsp[0].cptr));
            CHECK_ERROR(p, (yylsp[0]), "%s plugin %s not found", cfg_lexer_lookup_context_name_by_type(context), (yyvsp[0].cptr));

            last_driver = (LogDriver *) cfg_parse_plugin(configuration, p, &(yylsp[0]), NULL);
            free((yyvsp[0].cptr));
            if (!last_driver)
              {
                YYERROR;
              }
            (yyval.ptr) = last_driver;
          }
#line 4199 "lib/cfg-grammar.c"
    break;

  case 48: /* log_items: log_item semicolons log_items  */
#line 724 "/source/lib/cfg-grammar.y"
                                                { log_expr_node_append_tail((yyvsp[-2].ptr), (yyvsp[0].ptr)); (yyval.ptr) = (yyvsp[-2].ptr); }
#line 4205 "lib/cfg-grammar.c"
    break;

  case 49: /* log_items: %empty  */
#line 725 "/source/lib/cfg-grammar.y"
                                                { (yyval.ptr) = NULL; }
#line 4211 "lib/cfg-grammar.c"
    break;

  case 50: /* log_item: KW_SOURCE '(' string ')'  */
#line 729 "/source/lib/cfg-grammar.y"
                                                { (yyval.ptr) = log_expr_node_new_source_reference((yyvsp[-1].cptr), &(yyloc)); free((yyvsp[-1].cptr)); }
#line 4217 "lib/cfg-grammar.c"
    break;

  case 51: /* log_item: KW_SOURCE '{' source_content '}'  */
#line 730 "/source/lib/cfg-grammar.y"
                                                { (yyval.ptr) = log_expr_node_new_source(NULL, (yyvsp[-1].ptr), &(yyloc)); }
#line 4223 "lib/cfg-grammar.c"
    break;

  case 52: /* log_item: KW_FILTER '(' string ')'  */
#line 731 "/source/lib/cfg-grammar.y"
                                                { (yyval.ptr) = log_expr_node_new_filter_reference((yyvsp[-1].cptr), &(yyloc)); free((yyvsp[-1].cptr)); }
#line 4229 "lib/cfg-grammar.c"
    break;

  case 53: /* log_item: KW_FILTER '{' filter_content '}'  */
#line 732 "/source/lib/cfg-grammar.y"
                                                { (yyval.ptr) = log_expr_node_new_filter(NULL, (yyvsp[-1].ptr), &(yyloc)); }
#line 4235 "lib/cfg-grammar.c"
    break;

  case 54: /* log_item: KW_FILTERX '{' filterx_content '}'  */
#line 733 "/source/lib/cfg-grammar.y"
                                                { (yyval.ptr) = log_expr_node_new_filter(NULL, (yyvsp[-1].ptr), &(yyloc)); }
#line 4241 "lib/cfg-grammar.c"
    break;

  case 55: /* log_item: KW_PARSER '(' string ')'  */
#line 734 "/source/lib/cfg-grammar.y"
                                                { (yyval.ptr) = log_expr_node_new_parser_reference((yyvsp[-1].cptr), &(yyloc)); free((yyvsp[-1].cptr)); }
#line 4247 "lib/cfg-grammar.c"
    break;

  case 56: /* log_item: KW_PARSER '{' parser_content '}'  */
#line 735 "/source/lib/cfg-grammar.y"
                                                { (yyval.ptr) = log_expr_node_new_parser(NULL, (yyvsp[-1].ptr), &(yyloc)); }
#line 4253 "lib/cfg-grammar.c"
    break;

  case 57: /* log_item: KW_REWRITE '(' string ')'  */
#line 736 "/source/lib/cfg-grammar.y"
                                                { (yyval.ptr) = log_expr_node_new_rewrite_reference((yyvsp[-1].cptr), &(yyloc)); free((yyvsp[-1].cptr)); }
#line 4259 "lib/cfg-grammar.c"
    break;

  case 58: /* log_item: KW_REWRITE '{' rewrite_content '}'  */
#line 737 "/source/lib/cfg-grammar.y"
                                                { (yyval.ptr) = log_expr_node_new_rewrite(NULL, (yyvsp[-1].ptr), &(yyloc)); }
#line 4265 "lib/cfg-grammar.c"
    break;

  case 59: /* log_item: KW_DESTINATION '(' string ')'  */
#line 738 "/source/lib/cfg-grammar.y"
                                                { (yyval.ptr) = log_expr_node_new_destination_reference((yyvsp[-1].cptr), &(yyloc)); free((yyvsp[-1].cptr)); }
#line 4271 "lib/cfg-grammar.c"
    break;

  case 60: /* log_item: KW_DESTINATION '{' dest_content '}'  */
#line 739 "/source/lib/cfg-grammar.y"
                                                { (yyval.ptr) = log_expr_node_new_destination(NULL, (yyvsp[-1].ptr), &(yyloc)); }
#line 4277 "lib/cfg-grammar.c"
    break;

  case 61: /* log_item: log_scheduler  */
#line 740 "/source/lib/cfg-grammar.y"
                                                { (yyval.ptr) = (yyvsp[0].ptr); }
#line 4283 "lib/cfg-grammar.c"
    break;

  case 62: /* log_item: log_conditional  */
#line 741 "/source/lib/cfg-grammar.y"
                                                { (yyval.ptr) = (yyvsp[0].ptr); }
#line 4289 "lib/cfg-grammar.c"
    break;

  case 63: /* log_item: log_junction  */
#line 742 "/source/lib/cfg-grammar.y"
                                                { (yyval.ptr) = (yyvsp[0].ptr); }
#line 4295 "lib/cfg-grammar.c"
    break;

  case 64: /* @3: %empty  */
#line 747 "/source/lib/cfg-grammar.y"
          {
            LogPipe *scheduler_pipe = log_scheduler_pipe_new(configuration);
            last_scheduler_options = log_scheduler_pipe_get_scheduler_options(scheduler_pipe);
            (yyval.ptr) = scheduler_pipe;
          }
#line 4305 "lib/cfg-grammar.c"
    break;

  case 65: /* log_scheduler: KW_PARALLELIZE '(' @3 log_scheduler_options ')'  */
#line 752 "/source/lib/cfg-grammar.y"
                                                { (yyval.ptr) = log_expr_node_new_pipe((yyvsp[-2].ptr), &(yyloc)); }
#line 4311 "lib/cfg-grammar.c"
    break;

  case 68: /* log_scheduler_option: KW_PARTITIONS '(' nonnegative_integer ')'  */
#line 762 "/source/lib/cfg-grammar.y"
          {
            last_scheduler_options->num_partitions = (yyvsp[-1].num);
          }
#line 4319 "lib/cfg-grammar.c"
    break;

  case 69: /* log_scheduler_option: KW_PARTITION_KEY '(' template_content ')'  */
#line 766 "/source/lib/cfg-grammar.y"
          {
            log_scheduler_options_set_partition_key_ref(last_scheduler_options, (yyvsp[-1].ptr));
          }
#line 4327 "lib/cfg-grammar.c"
    break;

  case 70: /* log_junction: KW_JUNCTION '{' log_forks '}'  */
#line 773 "/source/lib/cfg-grammar.y"
                                                { (yyval.ptr) = log_expr_node_new_junction((yyvsp[-1].ptr), &(yyloc)); }
#line 4333 "lib/cfg-grammar.c"
    break;

  case 71: /* log_last_junction: log_forks  */
#line 785 "/source/lib/cfg-grammar.y"
                                                { (yyval.ptr) = (yyvsp[0].ptr) ? log_expr_node_new_junction((yyvsp[0].ptr), &(yylsp[0])) :  NULL; }
#line 4339 "lib/cfg-grammar.c"
    break;

  case 72: /* log_forks: log_fork semicolons log_forks  */
#line 790 "/source/lib/cfg-grammar.y"
                                                { log_expr_node_append_tail((yyvsp[-2].ptr), (yyvsp[0].ptr)); (yyval.ptr) = (yyvsp[-2].ptr); }
#line 4345 "lib/cfg-grammar.c"
    break;

  case 73: /* log_forks: %empty  */
#line 791 "/source/lib/cfg-grammar.y"
                                                { (yyval.ptr) = NULL; }
#line 4351 "lib/cfg-grammar.c"
    break;

  case 74: /* log_fork: KW_LOG optional_string '{' log_content '}'  */
#line 796 "/source/lib/cfg-grammar.y"
          {
            if ((yyvsp[-3].cptr))
              {
                log_expr_node_set_name((yyvsp[-1].ptr), (yyvsp[-3].cptr));
                free((yyvsp[-3].cptr));
              }
            (yyval.ptr) = (yyvsp[-1].ptr);
          }
#line 4364 "lib/cfg-grammar.c"
    break;

  case 75: /* log_fork: KW_CHANNEL optional_string '{' log_content '}'  */
#line 805 "/source/lib/cfg-grammar.y"
          {
            if ((yyvsp[-3].cptr))
              {
                log_expr_node_set_name((yyvsp[-1].ptr), (yyvsp[-3].cptr));
                free((yyvsp[-3].cptr));
              }
            (yyval.ptr) = (yyvsp[-1].ptr);
          }
#line 4377 "lib/cfg-grammar.c"
    break;

  case 76: /* log_conditional: log_if  */
#line 816 "/source/lib/cfg-grammar.y"
                                                { (yyval.ptr) = (yyvsp[0].ptr); }
#line 4383 "lib/cfg-grammar.c"
    break;

  case 77: /* log_conditional: log_if KW_ELSE '{' log_content '}'  */
#line 818 "/source/lib/cfg-grammar.y"
          {
            log_expr_node_conditional_set_false_branch_of_the_last_if((yyvsp[-4].ptr), (yyvsp[-1].ptr));
            (yyval.ptr) = (yyvsp[-4].ptr);
          }
#line 4392 "lib/cfg-grammar.c"
    break;

  case 78: /* log_if: KW_IF '(' filter_content ')' '{' log_content '}'  */
#line 826 "/source/lib/cfg-grammar.y"
          {
            (yyval.ptr) = log_expr_node_new_simple_conditional((yyvsp[-4].ptr), (yyvsp[-1].ptr), &(yyloc));
          }
#line 4400 "lib/cfg-grammar.c"
    break;

  case 79: /* log_if: KW_IF '{' log_content '}'  */
#line 830 "/source/lib/cfg-grammar.y"
          {
            (yyval.ptr) = log_expr_node_new_compound_conditional((yyvsp[-1].ptr), &(yyloc));
          }
#line 4408 "lib/cfg-grammar.c"
    break;

  case 80: /* log_if: log_if KW_ELIF '(' filter_content ')' '{' log_content '}'  */
#line 834 "/source/lib/cfg-grammar.y"
          {
            LogExprNode *false_branch;

            false_branch = log_expr_node_new_simple_conditional((yyvsp[-4].ptr), (yyvsp[-1].ptr), &(yyloc));
            log_expr_node_conditional_set_false_branch_of_the_last_if((yyvsp[-7].ptr), false_branch);
            (yyval.ptr) = (yyvsp[-7].ptr);
          }
#line 4420 "lib/cfg-grammar.c"
    break;

  case 81: /* log_if: log_if KW_ELIF '{' log_content '}'  */
#line 842 "/source/lib/cfg-grammar.y"
          {
            LogExprNode *false_branch;

            false_branch = log_expr_node_new_compound_conditional((yyvsp[-1].ptr), &(yyloc));
            log_expr_node_conditional_set_false_branch_of_the_last_if((yyvsp[-4].ptr), false_branch);
            (yyval.ptr) = (yyvsp[-4].ptr);
          }
#line 4432 "lib/cfg-grammar.c"
    break;

  case 82: /* log_content: log_items log_last_junction log_flags  */
#line 852 "/source/lib/cfg-grammar.y"
                                                               { (yyval.ptr) = log_expr_node_new_log(log_expr_node_append_tail((yyvsp[-2].ptr), (yyvsp[-1].ptr)), (yyvsp[0].num), &(yyloc)); }
#line 4438 "lib/cfg-grammar.c"
    break;

  case 83: /* log_flags: KW_FLAGS '(' log_flags_items ')' semicolons  */
#line 856 "/source/lib/cfg-grammar.y"
                                                        { (yyval.num) = (yyvsp[-2].num); }
#line 4444 "lib/cfg-grammar.c"
    break;

  case 84: /* log_flags: %empty  */
#line 857 "/source/lib/cfg-grammar.y"
                                                { (yyval.num) = 0; }
#line 4450 "lib/cfg-grammar.c"
    break;

  case 85: /* log_flags_items: normalized_flag log_flags_items  */
#line 861 "/source/lib/cfg-grammar.y"
                                                { (yyval.num) = log_expr_node_lookup_flag((yyvsp[-1].cptr)) | (yyvsp[0].num); free((yyvsp[-1].cptr)); }
#line 4456 "lib/cfg-grammar.c"
    break;

  case 86: /* log_flags_items: %empty  */
#line 862 "/source/lib/cfg-grammar.y"
                                                { (yyval.num) = 0; }
#line 4462 "lib/cfg-grammar.c"
    break;

  case 88: /* template_stmt: template_def  */
#line 873 "/source/lib/cfg-grammar.y"
          {
            CHECK_ERROR(cfg_tree_add_template(&configuration->tree, (yyvsp[0].ptr)) || cfg_allow_config_dups(configuration), (yylsp[0]), "duplicate template");
          }
#line 4470 "lib/cfg-grammar.c"
    break;

  case 89: /* template_stmt: template_fn  */
#line 877 "/source/lib/cfg-grammar.y"
          {
            LogTemplate *template = (yyvsp[0].ptr);
            user_template_function_register(configuration, template->name, template);
            log_template_unref(template);
          }
#line 4480 "lib/cfg-grammar.c"
    break;

  case 92: /* @4: %empty  */
#line 891 "/source/lib/cfg-grammar.y"
               {
	    (yyval.ptr) = log_template_new(configuration, (yyvsp[0].cptr));
	  }
#line 4488 "lib/cfg-grammar.c"
    break;

  case 93: /* @5: %empty  */
#line 894 "/source/lib/cfg-grammar.y"
              { (yyval.ptr) = (yyvsp[-1].ptr); }
#line 4494 "lib/cfg-grammar.c"
    break;

  case 94: /* template_block: KW_TEMPLATE string @4 '{' @5 template_items '}'  */
#line 894 "/source/lib/cfg-grammar.y"
                                                                                { (yyval.ptr) = (yyvsp[-4].ptr); free((yyvsp[-5].cptr)); }
#line 4500 "lib/cfg-grammar.c"
    break;

  case 95: /* @6: %empty  */
#line 899 "/source/lib/cfg-grammar.y"
               {
	    (yyval.ptr) = log_template_new(configuration, (yyvsp[0].cptr));
          }
#line 4508 "lib/cfg-grammar.c"
    break;

  case 96: /* template_simple: KW_TEMPLATE string @6 template_content_inner  */
#line 902 "/source/lib/cfg-grammar.y"
                                                                                { (yyval.ptr) = (yyvsp[-1].ptr); free((yyvsp[-2].cptr)); }
#line 4514 "lib/cfg-grammar.c"
    break;

  case 97: /* @7: %empty  */
#line 907 "/source/lib/cfg-grammar.y"
               {
	    (yyval.ptr) = log_template_new(configuration, (yyvsp[0].cptr));
          }
#line 4522 "lib/cfg-grammar.c"
    break;

  case 98: /* template_fn: KW_TEMPLATE_FUNCTION string @7 template_content_inner  */
#line 910 "/source/lib/cfg-grammar.y"
                                                                                { (yyval.ptr) = (yyvsp[-1].ptr); free((yyvsp[-2].cptr)); }
#line 4528 "lib/cfg-grammar.c"
    break;

  case 99: /* @8: %empty  */
#line 914 "/source/lib/cfg-grammar.y"
          { (yyval.ptr) = (yyvsp[0].ptr); }
#line 4534 "lib/cfg-grammar.c"
    break;

  case 100: /* @9: %empty  */
#line 914 "/source/lib/cfg-grammar.y"
                                                          { (yyval.ptr) = (yyvsp[-3].ptr); }
#line 4540 "lib/cfg-grammar.c"
    break;

  case 103: /* @10: %empty  */
#line 919 "/source/lib/cfg-grammar.y"
                          { (yyval.ptr) = (yyvsp[-2].ptr); }
#line 4546 "lib/cfg-grammar.c"
    break;

  case 105: /* template_item: KW_TEMPLATE_ESCAPE '(' yesno ')'  */
#line 920 "/source/lib/cfg-grammar.y"
                                                { log_template_set_escape((yyvsp[-4].ptr), (yyvsp[-1].num)); }
#line 4552 "lib/cfg-grammar.c"
    break;

  case 106: /* template_content_inner: string  */
#line 928 "/source/lib/cfg-grammar.y"
        {
          GError *error = NULL;

          CHECK_ERROR_GERROR(log_template_compile((yyvsp[-1].ptr), (yyvsp[0].cptr), &error), (yylsp[0]), error, "Error compiling template");
          free((yyvsp[0].cptr));
        }
#line 4563 "lib/cfg-grammar.c"
    break;

  case 107: /* template_content_inner: type_hint '(' string_or_number ')'  */
#line 935 "/source/lib/cfg-grammar.y"
        {
          GError *error = NULL;

          CHECK_ERROR_GERROR(log_template_compile((yyvsp[-4].ptr), (yyvsp[-1].cptr), &error), (yylsp[-1]), error, "Error compiling template");
          free((yyvsp[-1].cptr));

          log_template_set_type_hint_value((yyvsp[-4].ptr), (yyvsp[-3].num));
        }
#line 4576 "lib/cfg-grammar.c"
    break;

  case 108: /* template_content_inner: LL_NUMBER  */
#line 944 "/source/lib/cfg-grammar.y"
        {
          gchar decimal[32];

          g_snprintf(decimal, sizeof(decimal), "%" G_GINT64_FORMAT, (yyvsp[0].num));
          log_template_compile_literal_string((yyvsp[-1].ptr), decimal);
          log_template_set_type_hint((yyvsp[-1].ptr), "int64", NULL);
        }
#line 4588 "lib/cfg-grammar.c"
    break;

  case 109: /* template_content_inner: LL_FLOAT  */
#line 952 "/source/lib/cfg-grammar.y"
        {
          log_template_compile_literal_string((yyvsp[-1].ptr), lexer->token_text->str);
          log_template_set_type_hint((yyvsp[-1].ptr), "float", NULL);
        }
#line 4597 "lib/cfg-grammar.c"
    break;

  case 110: /* type_hint: LL_IDENTIFIER  */
#line 960 "/source/lib/cfg-grammar.y"
          {
            LogMessageValueType type;
            GError *error = NULL;

            CHECK_ERROR_GERROR(type_hint_parse((yyvsp[0].cptr), &type, &error), (yylsp[0]), error, "Unknown type hint");
            free((yyvsp[0].cptr));
            (yyval.num) = type;
          }
#line 4610 "lib/cfg-grammar.c"
    break;

  case 111: /* @11: %empty  */
#line 970 "/source/lib/cfg-grammar.y"
               {
            (yyval.ptr) = log_template_new(configuration, NULL);
          }
#line 4618 "lib/cfg-grammar.c"
    break;

  case 112: /* template_content: @11 template_content_inner  */
#line 972 "/source/lib/cfg-grammar.y"
                                                                            { (yyval.ptr) = (yyvsp[-1].ptr); }
#line 4624 "lib/cfg-grammar.c"
    break;

  case 113: /* $@12: %empty  */
#line 997 "/source/lib/cfg-grammar.y"
              { last_block_args = cfg_args_new(); }
#line 4630 "lib/cfg-grammar.c"
    break;

  case 114: /* block_stmt: KW_BLOCK _block_def_context_push LL_IDENTIFIER LL_IDENTIFIER '(' $@12 block_definition ')' _block_content_context_push LL_BLOCK _block_content_context_pop _block_def_context_pop  */
#line 1002 "/source/lib/cfg-grammar.y"
          {
            CfgBlockGenerator *block;

            gint context_type = cfg_lexer_lookup_context_type_by_name((yyvsp[-9].cptr));
            CHECK_ERROR(context_type, (yylsp[-9]), "unknown context \"%s\"", (yyvsp[-9].cptr));

            block = cfg_block_new(context_type, (yyvsp[-8].cptr), (yyvsp[-2].cptr), last_block_args, &(yylsp[-2]));
            cfg_lexer_register_generator_plugin(&configuration->plugin_context, block);
            free((yyvsp[-9].cptr));
            free((yyvsp[-8].cptr));
            free((yyvsp[-2].cptr));
            last_block_args = NULL;
          }
#line 4648 "lib/cfg-grammar.c"
    break;

  case 116: /* block_definition: block_args LL_DOTDOTDOT  */
#line 1019 "/source/lib/cfg-grammar.y"
                                                        { cfg_args_accept_varargs(last_block_args); }
#line 4654 "lib/cfg-grammar.c"
    break;

  case 119: /* block_arg: LL_IDENTIFIER _block_arg_context_push LL_BLOCK _block_arg_context_pop  */
#line 1028 "/source/lib/cfg-grammar.y"
                                                                                     { cfg_args_set(last_block_args, (yyvsp[-3].cptr), (yyvsp[-1].cptr)); free((yyvsp[-3].cptr)); free((yyvsp[-1].cptr)); }
#line 4660 "lib/cfg-grammar.c"
    break;

  case 122: /* options_item: KW_MARK_FREQ '(' nonnegative_integer ')'  */
#line 1037 "/source/lib/cfg-grammar.y"
                                                                { configuration->mark_freq = (yyvsp[-1].num); }
#line 4666 "lib/cfg-grammar.c"
    break;

  case 123: /* options_item: KW_FLUSH_LINES '(' nonnegative_integer ')'  */
#line 1038 "/source/lib/cfg-grammar.y"
                                                                { configuration->flush_lines = (yyvsp[-1].num); }
#line 4672 "lib/cfg-grammar.c"
    break;

  case 124: /* options_item: KW_MARK_MODE '(' KW_INTERNAL ')'  */
#line 1039 "/source/lib/cfg-grammar.y"
                                                   { cfg_set_mark_mode(configuration, "internal"); }
#line 4678 "lib/cfg-grammar.c"
    break;

  case 125: /* options_item: KW_MARK_MODE '(' string ')'  */
#line 1041 "/source/lib/cfg-grammar.y"
          {
            CHECK_ERROR(cfg_lookup_mark_mode((yyvsp[-1].cptr)) > 0 && cfg_lookup_mark_mode((yyvsp[-1].cptr)) != MM_GLOBAL, (yylsp[-1]), "illegal global mark-mode \"%s\"", (yyvsp[-1].cptr));
            cfg_set_mark_mode(configuration, (yyvsp[-1].cptr));
            free((yyvsp[-1].cptr));
          }
#line 4688 "lib/cfg-grammar.c"
    break;

  case 126: /* options_item: KW_FLUSH_TIMEOUT '(' positive_integer ')'  */
#line 1046 "/source/lib/cfg-grammar.y"
                                                        { }
#line 4694 "lib/cfg-grammar.c"
    break;

  case 127: /* options_item: KW_CHAIN_HOSTNAMES '(' yesno ')'  */
#line 1047 "/source/lib/cfg-grammar.y"
                                                { configuration->chain_hostnames = (yyvsp[-1].num); }
#line 4700 "lib/cfg-grammar.c"
    break;

  case 128: /* options_item: KW_KEEP_HOSTNAME '(' yesno ')'  */
#line 1048 "/source/lib/cfg-grammar.y"
                                                { configuration->keep_hostname = (yyvsp[-1].num); }
#line 4706 "lib/cfg-grammar.c"
    break;

  case 129: /* options_item: KW_CHECK_HOSTNAME '(' yesno ')'  */
#line 1049 "/source/lib/cfg-grammar.y"
                                                { configuration->check_hostname = (yyvsp[-1].num); }
#line 4712 "lib/cfg-grammar.c"
    break;

  case 130: /* options_item: KW_BAD_HOSTNAME '(' string ')'  */
#line 1050 "/source/lib/cfg-grammar.y"
                                                { cfg_bad_hostname_set(configuration, (yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 4718 "lib/cfg-grammar.c"
    break;

  case 131: /* options_item: KW_TIME_REOPEN '(' positive_integer ')'  */
#line 1051 "/source/lib/cfg-grammar.y"
                                                                { configuration->time_reopen = (yyvsp[-1].num); }
#line 4724 "lib/cfg-grammar.c"
    break;

  case 132: /* options_item: KW_TIME_REAP '(' nonnegative_integer ')'  */
#line 1052 "/source/lib/cfg-grammar.y"
                                                                { configuration->time_reap = (yyvsp[-1].num); }
#line 4730 "lib/cfg-grammar.c"
    break;

  case 133: /* options_item: KW_TIME_SLEEP '(' nonnegative_integer ')'  */
#line 1053 "/source/lib/cfg-grammar.y"
                                                        {}
#line 4736 "lib/cfg-grammar.c"
    break;

  case 134: /* options_item: KW_SUPPRESS '(' nonnegative_integer ')'  */
#line 1054 "/source/lib/cfg-grammar.y"
                                                                { configuration->suppress = (yyvsp[-1].num); }
#line 4742 "lib/cfg-grammar.c"
    break;

  case 135: /* options_item: KW_THREADED '(' yesno ')'  */
#line 1055 "/source/lib/cfg-grammar.y"
                                                { configuration->threaded = (yyvsp[-1].num); }
#line 4748 "lib/cfg-grammar.c"
    break;

  case 136: /* options_item: KW_PASS_UNIX_CREDENTIALS '(' yesno ')'  */
#line 1056 "/source/lib/cfg-grammar.y"
                                                 { configuration->pass_unix_credentials = (yyvsp[-1].num); }
#line 4754 "lib/cfg-grammar.c"
    break;

  case 137: /* options_item: KW_USE_RCPTID '(' yesno ')'  */
#line 1057 "/source/lib/cfg-grammar.y"
                                                { cfg_set_use_uniqid((yyvsp[-1].num)); }
#line 4760 "lib/cfg-grammar.c"
    break;

  case 138: /* options_item: KW_USE_UNIQID '(' yesno ')'  */
#line 1058 "/source/lib/cfg-grammar.y"
                                                { cfg_set_use_uniqid((yyvsp[-1].num)); }
#line 4766 "lib/cfg-grammar.c"
    break;

  case 139: /* options_item: KW_LOG_FIFO_SIZE '(' positive_integer ')'  */
#line 1059 "/source/lib/cfg-grammar.y"
                                                        { configuration->log_fifo_size = (yyvsp[-1].num); }
#line 4772 "lib/cfg-grammar.c"
    break;

  case 140: /* options_item: KW_LOG_IW_SIZE '(' positive_integer ')'  */
#line 1060 "/source/lib/cfg-grammar.y"
                                                        { msg_warning("WARNING: Support for the global log-iw-size() option was removed, please use a per-source log-iw-size()", cfg_lexer_format_location_tag(lexer, &(yylsp[-3]))); }
#line 4778 "lib/cfg-grammar.c"
    break;

  case 141: /* options_item: KW_LOG_FETCH_LIMIT '(' positive_integer ')'  */
#line 1061 "/source/lib/cfg-grammar.y"
                                                        { msg_warning("WARNING: Support for the global log-fetch-limit() option was removed, please use a per-source log-fetch-limit()", cfg_lexer_format_location_tag(lexer, &(yylsp[-3]))); }
#line 4784 "lib/cfg-grammar.c"
    break;

  case 142: /* options_item: KW_LOG_MSG_SIZE '(' positive_integer ')'  */
#line 1062 "/source/lib/cfg-grammar.y"
                                                        { configuration->log_msg_size = (yyvsp[-1].num); }
#line 4790 "lib/cfg-grammar.c"
    break;

  case 143: /* options_item: KW_TRIM_LARGE_MESSAGES '(' yesno ')'  */
#line 1063 "/source/lib/cfg-grammar.y"
                                                { configuration->trim_large_messages = (yyvsp[-1].num); }
#line 4796 "lib/cfg-grammar.c"
    break;

  case 144: /* options_item: KW_KEEP_TIMESTAMP '(' yesno ')'  */
#line 1064 "/source/lib/cfg-grammar.y"
                                                { configuration->keep_timestamp = (yyvsp[-1].num); }
#line 4802 "lib/cfg-grammar.c"
    break;

  case 145: /* options_item: KW_CREATE_DIRS '(' yesno ')'  */
#line 1065 "/source/lib/cfg-grammar.y"
                                                { configuration->create_dirs = (yyvsp[-1].num); }
#line 4808 "lib/cfg-grammar.c"
    break;

  case 146: /* options_item: KW_CUSTOM_DOMAIN '(' string ')'  */
#line 1066 "/source/lib/cfg-grammar.y"
                                                { configuration->custom_domain = g_strdup((yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 4814 "lib/cfg-grammar.c"
    break;

  case 147: /* options_item: KW_FILE_TEMPLATE '(' string ')'  */
#line 1067 "/source/lib/cfg-grammar.y"
                                                { configuration->file_template_name = g_strdup((yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 4820 "lib/cfg-grammar.c"
    break;

  case 148: /* options_item: KW_PROTO_TEMPLATE '(' string ')'  */
#line 1068 "/source/lib/cfg-grammar.y"
                                                { configuration->proto_template_name = g_strdup((yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 4826 "lib/cfg-grammar.c"
    break;

  case 149: /* options_item: KW_RECV_TIME_ZONE '(' string ')'  */
#line 1069 "/source/lib/cfg-grammar.y"
                                                { configuration->recv_time_zone = g_strdup((yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 4832 "lib/cfg-grammar.c"
    break;

  case 150: /* options_item: KW_MIN_IW_SIZE_PER_READER '(' positive_integer ')'  */
#line 1070 "/source/lib/cfg-grammar.y"
                                                             { configuration->min_iw_size_per_reader = (yyvsp[-1].num); }
#line 4838 "lib/cfg-grammar.c"
    break;

  case 151: /* options_item: KW_LOG_LEVEL '(' string ')'  */
#line 1071 "/source/lib/cfg-grammar.y"
                                                { CHECK_ERROR(cfg_set_log_level(configuration, (yyvsp[-1].cptr)), (yylsp[-1]), "Unknown log-level() option"); free((yyvsp[-1].cptr)); }
#line 4844 "lib/cfg-grammar.c"
    break;

  case 152: /* $@13: %empty  */
#line 1072 "/source/lib/cfg-grammar.y"
          { last_template_options = &configuration->template_options; }
#line 4850 "lib/cfg-grammar.c"
    break;

  case 154: /* $@14: %empty  */
#line 1073 "/source/lib/cfg-grammar.y"
          { last_host_resolve_options = &configuration->host_resolve_options; }
#line 4856 "lib/cfg-grammar.c"
    break;

  case 156: /* $@15: %empty  */
#line 1074 "/source/lib/cfg-grammar.y"
          { last_stats_options = &configuration->stats_options; last_healthcheck_options = &configuration->healthcheck_options; }
#line 4862 "lib/cfg-grammar.c"
    break;

  case 158: /* $@16: %empty  */
#line 1075 "/source/lib/cfg-grammar.y"
          { last_dns_cache_options = &configuration->dns_cache_options; }
#line 4868 "lib/cfg-grammar.c"
    break;

  case 160: /* $@17: %empty  */
#line 1076 "/source/lib/cfg-grammar.y"
          { last_file_perm_options = &configuration->file_perm_options; }
#line 4874 "lib/cfg-grammar.c"
    break;

  case 162: /* options_item: LL_PLUGIN  */
#line 1078 "/source/lib/cfg-grammar.y"
          {
            Plugin *p;
            gint context = LL_CONTEXT_OPTIONS;

            p = cfg_find_plugin(configuration, context, (yyvsp[0].cptr));
            CHECK_ERROR(p, (yylsp[0]), "%s plugin %s not found", cfg_lexer_lookup_context_name_by_type(context), (yyvsp[0].cptr));

            cfg_parse_plugin(configuration, p, &(yylsp[0]), NULL);
            free((yyvsp[0].cptr));
          }
#line 4889 "lib/cfg-grammar.c"
    break;

  case 163: /* stat_option: KW_STATS_FREQ '(' nonnegative_integer ')'  */
#line 1091 "/source/lib/cfg-grammar.y"
                                                             { last_stats_options->log_freq = (yyvsp[-1].num); }
#line 4895 "lib/cfg-grammar.c"
    break;

  case 164: /* stat_option: KW_STATS_LEVEL '(' nonnegative_integer ')'  */
#line 1092 "/source/lib/cfg-grammar.y"
                                                             { last_stats_options->level = (yyvsp[-1].num); }
#line 4901 "lib/cfg-grammar.c"
    break;

  case 165: /* stat_option: KW_STATS_LIFETIME '(' positive_integer ')'  */
#line 1093 "/source/lib/cfg-grammar.y"
                                                          { last_stats_options->lifetime = (yyvsp[-1].num); }
#line 4907 "lib/cfg-grammar.c"
    break;

  case 166: /* stat_option: KW_STATS_MAX_DYNAMIC '(' nonnegative_integer ')'  */
#line 1094 "/source/lib/cfg-grammar.y"
                                                       { last_stats_options->max_dynamic = (yyvsp[-1].num); }
#line 4913 "lib/cfg-grammar.c"
    break;

  case 170: /* stats_group_option: KW_FREQ '(' nonnegative_integer ')'  */
#line 1104 "/source/lib/cfg-grammar.y"
                                                       { last_stats_options->log_freq = (yyvsp[-1].num); }
#line 4919 "lib/cfg-grammar.c"
    break;

  case 171: /* stats_group_option: KW_LEVEL '(' nonnegative_integer ')'  */
#line 1105 "/source/lib/cfg-grammar.y"
                                                       { last_stats_options->level = (yyvsp[-1].num); }
#line 4925 "lib/cfg-grammar.c"
    break;

  case 172: /* stats_group_option: KW_LIFETIME '(' positive_integer ')'  */
#line 1106 "/source/lib/cfg-grammar.y"
                                                    { last_stats_options->lifetime = (yyvsp[-1].num); }
#line 4931 "lib/cfg-grammar.c"
    break;

  case 173: /* stats_group_option: KW_MAX_DYNAMIC '(' nonnegative_integer ')'  */
#line 1107 "/source/lib/cfg-grammar.y"
                                                       { last_stats_options->max_dynamic = (yyvsp[-1].num); }
#line 4937 "lib/cfg-grammar.c"
    break;

  case 174: /* stats_group_option: KW_SYSLOG_STATS '(' yesnoauto ')'  */
#line 1108 "/source/lib/cfg-grammar.y"
                                                { last_stats_options->syslog_stats = (yyvsp[-1].num); }
#line 4943 "lib/cfg-grammar.c"
    break;

  case 175: /* stats_group_option: KW_HEALTHCHECK_FREQ '(' nonnegative_integer ')'  */
#line 1109 "/source/lib/cfg-grammar.y"
                                                          { last_healthcheck_options->freq = (yyvsp[-1].num); }
#line 4949 "lib/cfg-grammar.c"
    break;

  case 176: /* dns_cache_option: KW_DNS_CACHE_SIZE '(' positive_integer ')'  */
#line 1113 "/source/lib/cfg-grammar.y"
                                                        { last_dns_cache_options->cache_size = (yyvsp[-1].num); }
#line 4955 "lib/cfg-grammar.c"
    break;

  case 177: /* dns_cache_option: KW_DNS_CACHE_EXPIRE '(' positive_integer ')'  */
#line 1114 "/source/lib/cfg-grammar.y"
                                                        { last_dns_cache_options->expire = (yyvsp[-1].num); }
#line 4961 "lib/cfg-grammar.c"
    break;

  case 178: /* dns_cache_option: KW_DNS_CACHE_EXPIRE_FAILED '(' positive_integer ')'  */
#line 1116 "/source/lib/cfg-grammar.y"
                                                { last_dns_cache_options->expire_failed = (yyvsp[-1].num); }
#line 4967 "lib/cfg-grammar.c"
    break;

  case 179: /* dns_cache_option: KW_DNS_CACHE_HOSTS '(' string ')'  */
#line 1117 "/source/lib/cfg-grammar.y"
                                                { last_dns_cache_options->hosts = g_strdup((yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 4973 "lib/cfg-grammar.c"
    break;

  case 182: /* yesno_strict: KW_YES  */
#line 1130 "/source/lib/cfg-grammar.y"
                                                { (yyval.num) = 1; }
#line 4979 "lib/cfg-grammar.c"
    break;

  case 183: /* yesno_strict: KW_NO  */
#line 1131 "/source/lib/cfg-grammar.y"
                                                { (yyval.num) = 0; }
#line 4985 "lib/cfg-grammar.c"
    break;

  case 185: /* yesno: LL_NUMBER  */
#line 1136 "/source/lib/cfg-grammar.y"
                                                { (yyval.num) = (yyvsp[0].num); }
#line 4991 "lib/cfg-grammar.c"
    break;

  case 186: /* yesnoauto: KW_YES  */
#line 1140 "/source/lib/cfg-grammar.y"
                  { (yyval.num) = CYNA_YES; }
#line 4997 "lib/cfg-grammar.c"
    break;

  case 187: /* yesnoauto: KW_NO  */
#line 1141 "/source/lib/cfg-grammar.y"
                  { (yyval.num) = CYNA_NO; }
#line 5003 "lib/cfg-grammar.c"
    break;

  case 188: /* yesnoauto: KW_AUTO  */
#line 1142 "/source/lib/cfg-grammar.y"
                  { (yyval.num) = CYNA_AUTO; }
#line 5009 "lib/cfg-grammar.c"
    break;

  case 189: /* dnsmode: yesno  */
#line 1146 "/source/lib/cfg-grammar.y"
                                                { (yyval.num) = (yyvsp[0].num); }
#line 5015 "lib/cfg-grammar.c"
    break;

  case 190: /* dnsmode: KW_PERSIST_ONLY  */
#line 1147 "/source/lib/cfg-grammar.y"
                                                { (yyval.num) = 2; }
#line 5021 "lib/cfg-grammar.c"
    break;

  case 191: /* nonnegative_integer64: LL_NUMBER  */
#line 1152 "/source/lib/cfg-grammar.y"
          {
            CHECK_ERROR(((yyvsp[0].num) >= 0), (yylsp[0]), "It cannot be negative");
          }
#line 5029 "lib/cfg-grammar.c"
    break;

  case 192: /* nonnegative_integer: nonnegative_integer64  */
#line 1159 "/source/lib/cfg-grammar.y"
          {
            CHECK_ERROR(((yyvsp[0].num) <= G_MAXINT32), (yylsp[0]), "Must be smaller than 2^31");
          }
#line 5037 "lib/cfg-grammar.c"
    break;

  case 193: /* positive_integer64: LL_NUMBER  */
#line 1166 "/source/lib/cfg-grammar.y"
          {
            CHECK_ERROR(((yyvsp[0].num) > 0), (yylsp[0]), "Must be positive");
          }
#line 5045 "lib/cfg-grammar.c"
    break;

  case 194: /* positive_integer: positive_integer64  */
#line 1173 "/source/lib/cfg-grammar.y"
          {
            CHECK_ERROR(((yyvsp[0].num) <= G_MAXINT32), (yylsp[0]), "Must be smaller than 2^31");
          }
#line 5053 "lib/cfg-grammar.c"
    break;

  case 195: /* string_or_number: string  */
#line 1201 "/source/lib/cfg-grammar.y"
                                                { (yyval.cptr) = (yyvsp[0].cptr); }
#line 5059 "lib/cfg-grammar.c"
    break;

  case 196: /* string_or_number: LL_NUMBER  */
#line 1202 "/source/lib/cfg-grammar.y"
                                                { (yyval.cptr) = strdup(lexer->token_text->str); }
#line 5065 "lib/cfg-grammar.c"
    break;

  case 197: /* string_or_number: LL_FLOAT  */
#line 1203 "/source/lib/cfg-grammar.y"
                                                { (yyval.cptr) = strdup(lexer->token_text->str); }
#line 5071 "lib/cfg-grammar.c"
    break;

  case 198: /* optional_string: string  */
#line 1207 "/source/lib/cfg-grammar.y"
                                                { (yyval.cptr) = (yyvsp[0].cptr); }
#line 5077 "lib/cfg-grammar.c"
    break;

  case 199: /* optional_string: %empty  */
#line 1208 "/source/lib/cfg-grammar.y"
                                                { (yyval.cptr) = NULL; }
#line 5083 "lib/cfg-grammar.c"
    break;

  case 200: /* normalized_flag: string  */
#line 1234 "/source/lib/cfg-grammar.y"
                                                { (yyval.cptr) = normalize_flag((yyvsp[0].cptr)); free((yyvsp[0].cptr)); }
#line 5089 "lib/cfg-grammar.c"
    break;

  case 201: /* string_list: string_list_build  */
#line 1238 "/source/lib/cfg-grammar.y"
                                                { (yyval.ptr) = (yyvsp[0].ptr); }
#line 5095 "lib/cfg-grammar.c"
    break;

  case 202: /* string_list_build: string string_list_build  */
#line 1242 "/source/lib/cfg-grammar.y"
                                                { (yyval.ptr) = g_list_prepend((yyvsp[0].ptr), g_strdup((yyvsp[-1].cptr))); free((yyvsp[-1].cptr)); }
#line 5101 "lib/cfg-grammar.c"
    break;

  case 203: /* string_list_build: %empty  */
#line 1243 "/source/lib/cfg-grammar.y"
                                                { (yyval.ptr) = NULL; }
#line 5107 "lib/cfg-grammar.c"
    break;

  case 206: /* source_option: KW_LOG_IW_SIZE '(' positive_integer ')'  */
#line 1415 "/source/lib/cfg-grammar.y"
                                                        { last_source_options->init_window_size = (yyvsp[-1].num); }
#line 5113 "lib/cfg-grammar.c"
    break;

  case 207: /* source_option: KW_CHAIN_HOSTNAMES '(' yesno ')'  */
#line 1416 "/source/lib/cfg-grammar.y"
                                                { last_source_options->chain_hostnames = (yyvsp[-1].num); }
#line 5119 "lib/cfg-grammar.c"
    break;

  case 208: /* source_option: KW_KEEP_HOSTNAME '(' yesno ')'  */
#line 1417 "/source/lib/cfg-grammar.y"
                                                { last_source_options->keep_hostname = (yyvsp[-1].num); }
#line 5125 "lib/cfg-grammar.c"
    break;

  case 209: /* source_option: KW_PROGRAM_OVERRIDE '(' string ')'  */
#line 1418 "/source/lib/cfg-grammar.y"
                                                { last_source_options->program_override = g_strdup((yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 5131 "lib/cfg-grammar.c"
    break;

  case 210: /* source_option: KW_HOST_OVERRIDE '(' string ')'  */
#line 1419 "/source/lib/cfg-grammar.y"
                                                { last_source_options->host_override = g_strdup((yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 5137 "lib/cfg-grammar.c"
    break;

  case 211: /* source_option: KW_LOG_PREFIX '(' string ')'  */
#line 1420 "/source/lib/cfg-grammar.y"
                                                { gchar *p = strrchr((yyvsp[-1].cptr), ':'); if (p) *p = 0; last_source_options->program_override = g_strdup((yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 5143 "lib/cfg-grammar.c"
    break;

  case 212: /* source_option: KW_KEEP_TIMESTAMP '(' yesno ')'  */
#line 1421 "/source/lib/cfg-grammar.y"
                                                { last_source_options->keep_timestamp = (yyvsp[-1].num); }
#line 5149 "lib/cfg-grammar.c"
    break;

  case 213: /* source_option: KW_READ_OLD_RECORDS '(' yesno ')'  */
#line 1422 "/source/lib/cfg-grammar.y"
                                                { last_source_options->read_old_records = (yyvsp[-1].num); }
#line 5155 "lib/cfg-grammar.c"
    break;

  case 214: /* source_option: KW_USE_SYSLOGNG_PID '(' yesno ')'  */
#line 1423 "/source/lib/cfg-grammar.y"
                                                { last_source_options->use_syslogng_pid = (yyvsp[-1].num); }
#line 5161 "lib/cfg-grammar.c"
    break;

  case 215: /* source_option: KW_TAGS '(' string_list ')'  */
#line 1424 "/source/lib/cfg-grammar.y"
                                                { log_source_options_set_tags(last_source_options, (yyvsp[-1].ptr)); }
#line 5167 "lib/cfg-grammar.c"
    break;

  case 216: /* $@20: %empty  */
#line 1425 "/source/lib/cfg-grammar.y"
          { last_host_resolve_options = &last_source_options->host_resolve_options; }
#line 5173 "lib/cfg-grammar.c"
    break;

  case 218: /* host_resolve_option: KW_USE_FQDN '(' yesno ')'  */
#line 1461 "/source/lib/cfg-grammar.y"
                                                { last_host_resolve_options->use_fqdn = (yyvsp[-1].num); }
#line 5179 "lib/cfg-grammar.c"
    break;

  case 219: /* host_resolve_option: KW_USE_DNS '(' dnsmode ')'  */
#line 1462 "/source/lib/cfg-grammar.y"
                                                { last_host_resolve_options->use_dns = (yyvsp[-1].num); }
#line 5185 "lib/cfg-grammar.c"
    break;

  case 220: /* host_resolve_option: KW_DNS_CACHE '(' yesno ')'  */
#line 1463 "/source/lib/cfg-grammar.y"
                                                { last_host_resolve_options->use_dns_cache = (yyvsp[-1].num); }
#line 5191 "lib/cfg-grammar.c"
    break;

  case 221: /* host_resolve_option: KW_NORMALIZE_HOSTNAMES '(' yesno ')'  */
#line 1464 "/source/lib/cfg-grammar.y"
                                                { last_host_resolve_options->normalize_hostnames = (yyvsp[-1].num); }
#line 5197 "lib/cfg-grammar.c"
    break;

  case 222: /* file_perm_option: KW_OWNER '(' string_or_number ')'  */
#line 1521 "/source/lib/cfg-grammar.y"
                                                { file_perm_options_set_file_uid(last_file_perm_options, (yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 5203 "lib/cfg-grammar.c"
    break;

  case 223: /* file_perm_option: KW_OWNER '(' ')'  */
#line 1522 "/source/lib/cfg-grammar.y"
                                                { file_perm_options_dont_change_file_uid(last_file_perm_options); }
#line 5209 "lib/cfg-grammar.c"
    break;

  case 224: /* file_perm_option: KW_GROUP '(' string_or_number ')'  */
#line 1523 "/source/lib/cfg-grammar.y"
                                                { file_perm_options_set_file_gid(last_file_perm_options, (yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 5215 "lib/cfg-grammar.c"
    break;

  case 225: /* file_perm_option: KW_GROUP '(' ')'  */
#line 1524 "/source/lib/cfg-grammar.y"
                                                { file_perm_options_dont_change_file_gid(last_file_perm_options); }
#line 5221 "lib/cfg-grammar.c"
    break;

  case 226: /* file_perm_option: KW_PERM '(' LL_NUMBER ')'  */
#line 1525 "/source/lib/cfg-grammar.y"
                                                { file_perm_options_set_file_perm(last_file_perm_options, (yyvsp[-1].num)); }
#line 5227 "lib/cfg-grammar.c"
    break;

  case 227: /* file_perm_option: KW_PERM '(' ')'  */
#line 1526 "/source/lib/cfg-grammar.y"
                                                { file_perm_options_dont_change_file_perm(last_file_perm_options); }
#line 5233 "lib/cfg-grammar.c"
    break;

  case 228: /* file_perm_option: KW_DIR_OWNER '(' string_or_number ')'  */
#line 1527 "/source/lib/cfg-grammar.y"
                                                { file_perm_options_set_dir_uid(last_file_perm_options, (yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 5239 "lib/cfg-grammar.c"
    break;

  case 229: /* file_perm_option: KW_DIR_OWNER '(' ')'  */
#line 1528 "/source/lib/cfg-grammar.y"
                                                { file_perm_options_dont_change_dir_uid(last_file_perm_options); }
#line 5245 "lib/cfg-grammar.c"
    break;

  case 230: /* file_perm_option: KW_DIR_GROUP '(' string_or_number ')'  */
#line 1529 "/source/lib/cfg-grammar.y"
                                                { file_perm_options_set_dir_gid(last_file_perm_options, (yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 5251 "lib/cfg-grammar.c"
    break;

  case 231: /* file_perm_option: KW_DIR_GROUP '(' ')'  */
#line 1530 "/source/lib/cfg-grammar.y"
                                                { file_perm_options_dont_change_dir_gid(last_file_perm_options); }
#line 5257 "lib/cfg-grammar.c"
    break;

  case 232: /* file_perm_option: KW_DIR_PERM '(' LL_NUMBER ')'  */
#line 1531 "/source/lib/cfg-grammar.y"
                                                { file_perm_options_set_dir_perm(last_file_perm_options, (yyvsp[-1].num)); }
#line 5263 "lib/cfg-grammar.c"
    break;

  case 233: /* file_perm_option: KW_DIR_PERM '(' ')'  */
#line 1532 "/source/lib/cfg-grammar.y"
                                                { file_perm_options_dont_change_dir_perm(last_file_perm_options); }
#line 5269 "lib/cfg-grammar.c"
    break;

  case 234: /* template_option: KW_TS_FORMAT '(' string ')'  */
#line 1536 "/source/lib/cfg-grammar.y"
                                                { last_template_options->ts_format = cfg_ts_format_value((yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 5275 "lib/cfg-grammar.c"
    break;

  case 235: /* template_option: KW_FRAC_DIGITS '(' nonnegative_integer ')'  */
#line 1537 "/source/lib/cfg-grammar.y"
                                                        { last_template_options->frac_digits = (yyvsp[-1].num); }
#line 5281 "lib/cfg-grammar.c"
    break;

  case 236: /* template_option: KW_TIME_ZONE '(' string ')'  */
#line 1538 "/source/lib/cfg-grammar.y"
                                                { last_template_options->time_zone[LTZ_SEND] = g_strdup((yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 5287 "lib/cfg-grammar.c"
    break;

  case 237: /* template_option: KW_SEND_TIME_ZONE '(' string ')'  */
#line 1539 "/source/lib/cfg-grammar.y"
                                                { last_template_options->time_zone[LTZ_SEND] = g_strdup((yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 5293 "lib/cfg-grammar.c"
    break;

  case 238: /* template_option: KW_LOCAL_TIME_ZONE '(' string ')'  */
#line 1540 "/source/lib/cfg-grammar.y"
                                                { last_template_options->time_zone[LTZ_LOCAL] = g_strdup((yyvsp[-1].cptr)); free((yyvsp[-1].cptr)); }
#line 5299 "lib/cfg-grammar.c"
    break;

  case 239: /* template_option: KW_TEMPLATE_ESCAPE '(' yesno ')'  */
#line 1541 "/source/lib/cfg-grammar.y"
                                                { last_template_options->escape = (yyvsp[-1].num); }
#line 5305 "lib/cfg-grammar.c"
    break;

  case 240: /* template_option: KW_ON_ERROR '(' string ')'  */
#line 1543 "/source/lib/cfg-grammar.y"
        {
          gint on_error;

          CHECK_ERROR(log_template_on_error_parse((yyvsp[-1].cptr), &on_error), (yylsp[-1]), "Invalid on-error() setting \"%s\"", (yyvsp[-1].cptr));
          free((yyvsp[-1].cptr));

          log_template_options_set_on_error(last_template_options, on_error);
        }
#line 5318 "lib/cfg-grammar.c"
    break;

  case 241: /* _destination_context_push: %empty  */
#line 1705 "/source/lib/cfg-grammar.y"
                           { cfg_lexer_push_context(lexer, LL_CONTEXT_DESTINATION, NULL, "destination statement"); }
#line 5324 "lib/cfg-grammar.c"
    break;

  case 242: /* _destination_context_pop: %empty  */
#line 1706 "/source/lib/cfg-grammar.y"
                          { cfg_lexer_pop_context(lexer); }
#line 5330 "lib/cfg-grammar.c"
    break;

  case 243: /* _source_context_push: %empty  */
#line 1707 "/source/lib/cfg-grammar.y"
                      { cfg_lexer_push_context(lexer, LL_CONTEXT_SOURCE, NULL, "source statement"); }
#line 5336 "lib/cfg-grammar.c"
    break;

  case 244: /* _source_context_pop: %empty  */
#line 1708 "/source/lib/cfg-grammar.y"
                      { cfg_lexer_pop_context(lexer); }
#line 5342 "lib/cfg-grammar.c"
    break;

  case 245: /* _filterx_context_push: %empty  */
#line 1715 "/source/lib/cfg-grammar.y"
                       { cfg_lexer_push_context(lexer, LL_CONTEXT_FILTERX, NULL, "filterx statement"); }
#line 5348 "lib/cfg-grammar.c"
    break;

  case 246: /* _filterx_context_pop: %empty  */
#line 1716 "/source/lib/cfg-grammar.y"
                      { cfg_lexer_pop_context(lexer); }
#line 5354 "lib/cfg-grammar.c"
    break;

  case 247: /* _log_context_push: %empty  */
#line 1717 "/source/lib/cfg-grammar.y"
                   { cfg_lexer_push_context(lexer, LL_CONTEXT_LOG, NULL, "log statement"); }
#line 5360 "lib/cfg-grammar.c"
    break;

  case 248: /* _log_context_pop: %empty  */
#line 1718 "/source/lib/cfg-grammar.y"
                  { cfg_lexer_pop_context(lexer); }
#line 5366 "lib/cfg-grammar.c"
    break;

  case 249: /* _block_def_context_push: %empty  */
#line 1719 "/source/lib/cfg-grammar.y"
                         { cfg_lexer_push_context(lexer, LL_CONTEXT_BLOCK_DEF, block_def_keywords, "block definition"); }
#line 5372 "lib/cfg-grammar.c"
    break;

  case 250: /* _block_def_context_pop: %empty  */
#line 1720 "/source/lib/cfg-grammar.y"
                        { cfg_lexer_pop_context(lexer); }
#line 5378 "lib/cfg-grammar.c"
    break;

  case 251: /* _block_content_context_push: %empty  */
#line 1723 "/source/lib/cfg-grammar.y"
                             { cfg_lexer_push_context(lexer, LL_CONTEXT_BLOCK_CONTENT, NULL, "block content"); }
#line 5384 "lib/cfg-grammar.c"
    break;

  case 252: /* _block_content_context_pop: %empty  */
#line 1724 "/source/lib/cfg-grammar.y"
                            { cfg_lexer_pop_context(lexer); }
#line 5390 "lib/cfg-grammar.c"
    break;

  case 253: /* _block_arg_context_push: %empty  */
#line 1725 "/source/lib/cfg-grammar.y"
                         { cfg_lexer_push_context(lexer, LL_CONTEXT_BLOCK_ARG, NULL, "block argument"); }
#line 5396 "lib/cfg-grammar.c"
    break;

  case 254: /* _block_arg_context_pop: %empty  */
#line 1726 "/source/lib/cfg-grammar.y"
                        { cfg_lexer_pop_context(lexer); }
#line 5402 "lib/cfg-grammar.c"
    break;

  case 255: /* _options_context_push: %empty  */
#line 1732 "/source/lib/cfg-grammar.y"
                       { cfg_lexer_push_context(lexer, LL_CONTEXT_OPTIONS, NULL, "options statement"); }
#line 5408 "lib/cfg-grammar.c"
    break;

  case 256: /* _options_context_pop: %empty  */
#line 1733 "/source/lib/cfg-grammar.y"
                      { cfg_lexer_pop_context(lexer); }
#line 5414 "lib/cfg-grammar.c"
    break;


#line 5418 "lib/cfg-grammar.c"

      default: break;
    }
  /* User semantic actions sometimes alter yychar, and that requires
     that yytoken be updated with the new translation.  We take the
     approach of translating immediately before every use of yytoken.
     One alternative is translating here after every semantic action,
     but that translation would be missed if the semantic action invokes
     YYABORT, YYACCEPT, or YYERROR immediately after altering yychar or
     if it invokes YYBACKUP.  In the case of YYABORT or YYACCEPT, an
     incorrect destructor might then be invoked immediately.  In the
     case of YYERROR or YYBACKUP, subsequent parser actions might lead
     to an incorrect destructor call or verbose syntax error message
     before the lookahead is translated.  */
  YY_SYMBOL_PRINT ("-> $$ =", YY_CAST (yysymbol_kind_t, yyr1[yyn]), &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;

  *++yyvsp = yyval;
  *++yylsp = yyloc;

  /* Now 'shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */
  {
    const int yylhs = yyr1[yyn] - YYNTOKENS;
    const int yyi = yypgoto[yylhs] + *yyssp;
    yystate = (0 <= yyi && yyi <= YYLAST && yycheck[yyi] == *yyssp
               ? yytable[yyi]
               : yydefgoto[yylhs]);
  }

  goto yynewstate;


/*--------------------------------------.
| yyerrlab -- here on detecting error.  |
`--------------------------------------*/
yyerrlab:
  /* Make sure we have latest lookahead translation.  See comments at
     user semantic actions for why this is necessary.  */
  yytoken = yychar == MAIN_EMPTY ? YYSYMBOL_YYEMPTY : YYTRANSLATE (yychar);
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
      {
        yypcontext_t yyctx
          = {yyssp, yytoken, &yylloc};
        char const *yymsgp = YY_("syntax error");
        int yysyntax_error_status;
        yysyntax_error_status = yysyntax_error (&yymsg_alloc, &yymsg, &yyctx);
        if (yysyntax_error_status == 0)
          yymsgp = yymsg;
        else if (yysyntax_error_status == -1)
          {
            if (yymsg != yymsgbuf)
              YYSTACK_FREE (yymsg);
            yymsg = YY_CAST (char *,
                             YYSTACK_ALLOC (YY_CAST (YYSIZE_T, yymsg_alloc)));
            if (yymsg)
              {
                yysyntax_error_status
                  = yysyntax_error (&yymsg_alloc, &yymsg, &yyctx);
                yymsgp = yymsg;
              }
            else
              {
                yymsg = yymsgbuf;
                yymsg_alloc = sizeof yymsgbuf;
                yysyntax_error_status = YYENOMEM;
              }
          }
        yyerror (&yylloc, lexer, dummy, arg, yymsgp);
        if (yysyntax_error_status == YYENOMEM)
          YYNOMEM;
      }
    }

  yyerror_range[1] = yylloc;
  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
         error, discard it.  */

      if (yychar <= MAIN_EOF)
        {
          /* Return failure if at end of input.  */
          if (yychar == MAIN_EOF)
            YYABORT;
        }
      else
        {
          yydestruct ("Error: discarding",
                      yytoken, &yylval, &yylloc, lexer, dummy, arg);
          yychar = MAIN_EMPTY;
        }
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:
  /* Pacify compilers when the user code never invokes YYERROR and the
     label yyerrorlab therefore never appears in user code.  */
  if (0)
    YYERROR;
  ++yynerrs;

  /* Do not reclaim the symbols of the rule whose action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;      /* Each real token shifted decrements this.  */

  /* Pop stack until we find a state that shifts the error token.  */
  for (;;)
    {
      yyn = yypact[yystate];
      if (!yypact_value_is_default (yyn))
        {
          yyn += YYSYMBOL_YYerror;
          if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYSYMBOL_YYerror)
            {
              yyn = yytable[yyn];
              if (0 < yyn)
                break;
            }
        }

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
        YYABORT;

      yyerror_range[1] = *yylsp;
      yydestruct ("Error: popping",
                  YY_ACCESSING_SYMBOL (yystate), yyvsp, yylsp, lexer, dummy, arg);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END

  yyerror_range[2] = yylloc;
  ++yylsp;
  YYLLOC_DEFAULT (*yylsp, yyerror_range, 2);

  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", YY_ACCESSING_SYMBOL (yyn), yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturnlab;


/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturnlab;


/*-----------------------------------------------------------.
| yyexhaustedlab -- YYNOMEM (memory exhaustion) comes here.  |
`-----------------------------------------------------------*/
yyexhaustedlab:
  yyerror (&yylloc, lexer, dummy, arg, YY_("memory exhausted"));
  yyresult = 2;
  goto yyreturnlab;


/*----------------------------------------------------------.
| yyreturnlab -- parsing is finished, clean up and return.  |
`----------------------------------------------------------*/
yyreturnlab:
  if (yychar != MAIN_EMPTY)
    {
      /* Make sure we have latest lookahead translation.  See comments at
         user semantic actions for why this is necessary.  */
      yytoken = YYTRANSLATE (yychar);
      yydestruct ("Cleanup: discarding lookahead",
                  yytoken, &yylval, &yylloc, lexer, dummy, arg);
    }
  /* Do not reclaim the symbols of the rule whose action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
                  YY_ACCESSING_SYMBOL (+*yyssp), yyvsp, yylsp, lexer, dummy, arg);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
  if (yymsg != yymsgbuf)
    YYSTACK_FREE (yymsg);
  return yyresult;
}

#line 1738 "/source/lib/cfg-grammar.y"

